package Interface;

public interface CentralTraffic {
	
	public void PedestrainSymbol();

}
