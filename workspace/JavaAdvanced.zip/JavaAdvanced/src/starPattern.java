
public class starPattern {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,j;
		int my_input=8;
	/*	for (i = 1; i <= 8; i++){
	         for (j = 1; j <= i ; j++)
	            System.out.print("*");
	         System.out.print("\n");
	      }
		 for (i = 1; i < 8; i++){
	         for (j = i; j < 8; j++)
	            System.out.print("*");
	         System.out.print("\n");
	      }
*/
		/*
		 for (i=1; i<=my_input; i++){
	         for (j=my_input-i; j>=1; j--){
	            System.out.print(" ");
	         }
	         for (j=1; j<=i; j++ ){
	            System.out.print("* ");
	         }
	         System.out.println();
	      }
	      */
	}

}
