package JavaIO;
import java.io.*;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class FileWriter1 {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		try
		{
		FileOutputStream fos= new FileOutputStream("C:\\Users\\SH20204415\\eclipse-workspace\\Selenium\\JAVADemo\\src\\JavaIO\\FileIOstream.txt");
		BufferedOutputStream bos= new BufferedOutputStream(fos);
		
		String str="Hi this is first line...";
		byte[] b=str.getBytes();
		bos.write(b);
		bos.flush();									//if not flushed the data must not reach from buffer to stream
	//	bos.close();
	//	fos.close();									
		
		System.out.println("Written to file...");
		
		FileInputStream fis= new FileInputStream("C:\\\\Users\\\\SH20204415\\\\eclipse-workspace\\\\Selenium\\\\JAVADemo\\\\src\\\\JavaIO\\\\FileIOstream.txt");
		BufferedInputStream bis= new BufferedInputStream(fis);
		int s=0;
		while( (s=bis.read())!=-1 )
		{
			System.out.print((char)s);
		}
		bis.close();
		fis.close();
		}
		catch(Exception e)
			{System.out.println("Access denied to open the file...");
			
			}

	}

}
