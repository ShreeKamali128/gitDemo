package Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

public class Hashmap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		HashMap<Integer,String> hm= new HashMap<Integer,String>();
		hm.put(0, "hi");
		hm.put(1, "good");
		hm.put(2, "morning");
		
		
		/*
		//traversing
		//normal iteration---converting to set and then using iterator method
		
		
		Set st=hm.entrySet();
		Iterator itr=st.iterator();
		
		while(itr.hasNext())
		{
			Map.Entry mpe=(Map.Entry)itr.next();
			System.out.println(mpe.getKey() + " "+ mpe.getValue());  
			
		}
		
		//alitter:
		for(Map.Entry mp : hm.entrySet() )
			System.out.println(mp.getKey() + " " + mp.getValue());
		*/
		
		
		
		/*
		 //different ways of iteration
		//iterate over keys and values----getting only key or only values
		for(Integer i:hm.keySet())
			System.out.println(i);
		for(String s: hm.values())
			System.out.println(s);
		
		//using forEach
		hm.forEach((k,v)-> System.out.println(k+ "    "+ v));
		
		//using keySet.iterator------cause using iterator on keys and then iterating k,v
		Iterator<Integer> itr=hm.keySet().iterator();
		while(itr.hasNext())
		{
			int key= (int)itr.next();
			System.out.println(key + "    "+ hm.get(key));
		}
		*/
		
		
		
		/*		
		//entrySet() --  return a collection view of the mappings contained in this map.
		//keySet() --  return a set view of the keys contained in this map.
		//values() -- returns a collection view of the values contained in the map.
		
		//different methods in hasMap
		System.out.println(hm);
		System.out.println(hm.get(2));
		hm.remove(0);
		System.out.println(hm.toString());
		
		//hm.remove(1);
		//System.out.println(hm);
		//hm.remove(1,"good");
		//System.out.println(hm);
		hm.replace(1, "sweet");
		System.out.println(hm);
		hm.replace(1,"sweet" ,"sweeeet");                        //return type boolean so cant be printed in sysout directly
		System.out.println(hm);
		hm.replaceAll((k,v)->"good");
		//sort by key and then print
		hm.entrySet().stream().sorted(Map.Entry.comparingByKey()).forEach(s->System.out.println(s));
		*/
		
		
		
		
		//1. sorting using streams--both forward/reverse order
	
		//hm.entrySet().stream().sorted(Map.Entry.comparingByKey()).forEach(System.out::println); 			 //0=hi  1=good 2=morning
		
		  hm.entrySet().stream().sorted(Map.Entry.comparingByKey()).forEach(s->System.out.println(s));
		  hm.entrySet().stream().sorted(Map.Entry.comparingByKey(Comparator.reverseOrder())).forEach(s->System.out.println(s)); 
		  hm.entrySet().stream().sorted(Map.Entry.comparingByValue()).forEach(s->System.out.println(s));
		  hm.entrySet().stream().sorted(Map.Entry.comparingByValue(Comparator.reverseOrder())).forEach(s->System.out.println(s));
		 
		 
		
		/*
		//2. sorting hash map by converting it to tree map 
		TreeMap<Integer,String> tmp= new TreeMap<Integer, String>(hm);
				
		Iterator<Integer> it=hm.keySet().iterator();
		while(it.hasNext())
		{
			int key=(int)it.next();
			System.out.println(key +  "    "+  hm.get(key));
		}
		*/
		 
	}
	

}
