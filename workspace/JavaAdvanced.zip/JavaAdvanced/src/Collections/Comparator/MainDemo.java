package Collections.Comparator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class MainDemo {

	public static void main(String[] args) {

		ArrayList<Movie> al = new ArrayList<Movie>();
		al.add(new Movie("Shri", 34));
		al.add(new Movie("Hamesh", 93));
		al.add(new Movie("Shri", 23));
		al.add(new Movie("Hamesh", 74));

		//sort by name alone
		Collections.sort(al, new Namecompare());
		System.out.println("sorting by name: ");
		
		Iterator<Movie> itr = al.iterator();
		while (itr.hasNext()) {
			Movie c = (Movie) itr.next();
			System.out.println(c.getName() + "   " + c.getRating());
		}

		//sort by rating alone
		Collections.sort(al, new RatingCompare());
		System.out.println("sorting by rating: ");
		
		for(Movie m: al)
			System.out.println(m.getName() + "  "+ m.getRating());
		
		//sort by name and rating
		Collections.sort(al, new NameRatingCompare());
		System.out.println("sorting by name & rating: ");
		
		for(Movie m: al)
			System.out.println(m.getName() + "  "+ m.getRating());
		
	}
}
