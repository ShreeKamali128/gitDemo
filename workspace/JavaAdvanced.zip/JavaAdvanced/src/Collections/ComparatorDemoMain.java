package Collections;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class ComparatorDemoMain {
	public static void main(String[] args)
	{
		List<ComparatorDemo> listOfBooks = new ArrayList<>();
		
		listOfBooks.add(new ComparatorDemo("Effective Java", "Joshua Bloch", 32));
		listOfBooks.add(new ComparatorDemo("Java Puzzlers", "Jushua Bloch", 22));
		listOfBooks.add(new ComparatorDemo("Java Concurrency in Practice", "Brian Goetz", 42));
		listOfBooks.add(new ComparatorDemo("Java SE 8 for Really Impatient", "Cay S. Horstmann", 34));
		listOfBooks.add(new ComparatorDemo("Core Java", "Cey S. Horstmann",32));
		
		
		//1. Writing Comparator using Lambda Expression
		Comparator<ComparatorDemo> byAuthor = (b1, b2) -> b1.getAuthor().compareTo(b2.getAuthor());
		
//		 Comparator<ComparatorDemo> byAuthorOldWay = new Comparator<ComparatorDemo>() {
//		      public int compare(ComparatorDemo b1, ComparatorDemo b2) {
//		        return b1.getAuthor().compareTo(b2.getAuthor());
//		      }
//		    };

		listOfBooks.sort(byAuthor);
		for(ComparatorDemo x: listOfBooks)
			System.out.println( x);

		/*
		//2. Writing Comparator using Method Reference
		//Comparator<ComparatorDemo> byAuthor = Comparator.comparing(ComparatorDemo::getAuthor);
		Comparator<ComparatorDemo> byTitle = Comparator.comparing(ComparatorDemo::getTitle);
		Comparator<ComparatorDemo> byPrice = Comparator.comparing(ComparatorDemo::getPrice);
		
		listOfBooks.sort(Comparator.comparing(ComparatorDemo::getPrice)); 
		System.out.println("list of books after sorting by price: " + listOfBooks);
		
		//3. Chaining Comparators to compare multiple fields of Objects
		Comparator<ComparatorDemo> byAuthorThenByPrice = Comparator.comparing(ComparatorDemo::getAuthor).thenComparing(ComparatorDemo::getPrice);
		listOfBooks.sort(byAuthorThenByPrice);
		
		//4. Sorting List of objects in reverse order of Comparator
		listOfBooks.sort(Comparator.comparing(ComparatorDemo::getAuthor).reversed());
		
		//5. Sorting objects by the natural order
		listOfBooks.sort(Comparator.naturalOrder());		
		
		//6. Null-safe Sorting using nullsFirst() and nullsLast() Comparator
		Comparator<ComparatorDemo> byAuthors = (b1, b2) -> b1.getAuthor().compareTo(b2.getAuthor()); 
		listOfBooks.sort(Comparator.nullsFirst(byAuthors)); 
		System.out.println("sorting list of books with nulls first " + listOfBooks);
		*/
		 
	}

}
