package Collections;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Objects;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Queue.*;

public class QueueDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Queue<String> q= new ArrayDeque<String>();
		q.add("Hi");
		q.add("How");
		q.add("Are");
		q.add("You?");
		
		//methods in queue class
		System.out.println("Peek: " + q.peek());
		System.out.println("Poll: " + q.poll());
		
		Iterator<String> itr =q.iterator();
		while(itr.hasNext())
			System.out.println(itr.next());
		
		
		//1. sorted by converting q to array
		/*
		Object[] obj=q.toArray();
		Arrays.sort(obj);
		System.out.println(Arrays.toString(obj));
		
		
		//2. converting queue to array ----by default follows insertion order
		String[] sarr= new String[q.size()];
		String[] sar=q.toArray(sarr);     //String[] sar=q.toArray(new String[q.size()]);
		for(String s: sar)
			System.out.println(s);
		*/
	}

}
