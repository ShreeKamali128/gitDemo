package Collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.TreeSet;

public class Set {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet<String> set=new HashSet<String>();  
        set.add("Ravi");  
        set.add("Vijay");  
        set.add("Arun");  
        set.add("Sumit");  
        System.out.println("An initial list of elements: "+set); 
        
        
        /*
        //Removing specific element from HashSet  
        set.remove("Ravi");  
        System.out.println("After invoking remove(object) method: "+set);  
        
        
        //adding 2 sets
        HashSet<String> set1=new HashSet<String>();  
        set1.add("Ajay");  
        set1.add("Gaurav"); 
        
        set.addAll(set1);  
        System.out.println("Updated List: "+set);  
        
        
        //Removing (all the new elements from HashSet) one set of elements from another 
        set.removeAll(set1);  
        System.out.println("After invoking removeAll() method: "+set);  
        
        //Removing elements on the basis of specified condition  
        set.removeIf(str->str.contains("Vijay"));    
        System.out.println("After invoking removeIf() method: "+set); 
        
        //Removing all the elements available in the set  
        set.clear();  
        System.out.println("After invoking clear() method: "+set);  
  		*/
        
        //sorting set
        //1. converting set to array list and sorting
        //2. using tree set
        //3. using streams
        
        //1
        ArrayList<String> al = new ArrayList<String>();
        for(String s: set)
        {
        	al.add(s);
        }
        
        System.out.println("set converted to list: ");
        al.forEach(x-> System.out.println(x));
        
       // al.sort(null); 				//here need to pass comparator to know in what way to sort
       // System.out.println("al.sort():	 " + al);
        
        Collections.sort(al);
        System.out.println("Collections.sort():		" + al);
        
        for(String s: al)
        {
        	System.out.println(s);
        }
        
        
        //tree set
        TreeSet<String> ts = new TreeSet<>();
        ts.addAll(set);
        
        System.out.println("Treeset is:  ");
        for(String s: ts)
        {
        	System.out.println(ts.ceiling(s));
        	//System.out.println(ts.floor(s));
        }
	}
}
