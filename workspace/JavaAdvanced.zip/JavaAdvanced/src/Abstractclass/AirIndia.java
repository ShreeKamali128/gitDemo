package Abstractclass;
public class AirIndia extends AirCraft{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
AirIndia ai= new AirIndia();
ai.color();
	}

	@Override
	public void color() {
		// TODO Auto-generated method stub
		System.out.println("Red color on it");
	}

}
