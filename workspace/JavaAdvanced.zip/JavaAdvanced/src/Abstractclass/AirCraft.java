package Abstractclass;

public abstract class AirCraft {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	public void engine()
	{
		System.out.println("engine par");
	}
	
	public void brake()
	{
		System.out.println("brake par");
	}
	
	public abstract void color();

}
