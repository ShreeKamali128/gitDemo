package Inheritance;
public class ChildClass extends ParentClass {

	String name="child class property";
	//constructor
	public ChildClass()
	{
		super();    //should be the first line
		System.out.println("Child constr");
	}
	
	//function overriden or method overridden or runtime polymorphism
	public void Engine()
	{
		System.out.println("engine child");
	}
	
	public void Brakes()
	{
		super.Brakes();
		System.out.println("Brakes child");
	}
	
	//function overloading
	public void getData(int a)
	{
	System.out.println(a);	
	}
	
	public void getData(String s)
	{
	System.out.println(s);	
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ChildClass cc= new ChildClass();
		ParentClass pc = new ChildClass();
		//pc.Engine();   //no engine par because its overridden already so only that method only outputted
		//pc.Brakes();
		
		System.out.println(pc.name);
		System.out.println(cc.name); 
		
		cc.RPM();      //not overridden method just a inherited method
		cc.Engine();   //overridden methods
		cc.Brakes();   //overridden methods
		cc.getData(2);  //class's own method
		cc.getData("Hello"); //class's own method
		
	}
	

}
