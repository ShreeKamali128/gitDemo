package Inheritance;

public class ParentClass {

	protected String name="parent class property";
	
	public ParentClass()
	{
		System.out.println("parent default const");
	}
	
	public void Engine()
	{
		System.out.println("engine par");
	}
	
	public void Brakes()
	{
		System.out.println("Brakes par");
	}
	
	public void RPM()
	{
		System.out.println("rpm par");
	}

}
