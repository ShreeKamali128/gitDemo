package Tests;

import org.junit.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import DriverInit.BaseTest;
import GiftCard._GiftCardPO;
import Hair._HairPO;
import Home._HomePO;

public class HairTest extends BaseTest {

	private _HomePO home;
	private _HairPO hr;

	@BeforeTest
	public void setUpPages() {
		this.home = new _HomePO(driver);
		this.hr = new _HairPO(driver);
	}

	@Test
	public void HairWorkFlow() throws Exception

	{
		SoftAssert ass= new SoftAssert();
		this.driver.manage().deleteAllCookies();
		
		ass.assertTrue(home.getSubHeaderBar().isDisplayed());
		home.getSubHeaderBar().goToHairCategory();
		home.getSubHeaderBar().goToHairCare();
		
		ass.assertTrue(hr.getFilters().isDisplayed());
		hr.getFilters().sortByDropDowns();
		hr.getFilters().selectFilters();
		ass.assertTrue(hr.getFilters().verifyFilterApplied());
		
		ass.assertTrue(hr.getProductListing().isDisplayed());
		hr.getProductListing().productClick();
		
		ass.assertTrue(hr.getSingleProduct().isDisplayed());
		String s1 =hr.getSingleProduct().topRatedProduct();
		hr.getSingleProduct().addToBagClick();
		
		home.getHeaderBar().viewBagClick();
		
		hr.getCartProducts().switchFrame();
		ass.assertTrue(hr.getCartProducts().isDisplayed());
		
		String s2=hr.getCartProducts().cartProduct();
		ass.assertEquals(s1,s2);
		hr.getCartProducts().coupons();
		hr.getCartProducts().chargeFees();
		hr.getCartProducts().closeFrame();	
	}
	
	
}
