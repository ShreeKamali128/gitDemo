package Tests;

import org.junit.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import DriverInit.BaseTest;
import GiftCard._GiftCardPO;
import Home._HomePO;

public class GiftCardsTest extends BaseTest {

	private _HomePO home;
	private _GiftCardPO gc;

	@BeforeTest
	public void setUpPages() {
		this.home = new _HomePO(driver);
		this.gc = new _GiftCardPO(driver);
	}

	@Test
	public void giftCardsWorkFlow() throws Exception

	{
		SoftAssert ass= new SoftAssert();
		this.driver.manage().deleteAllCookies();
		
		ass.assertTrue(home.getOfferTopBar().isDisplayed());
		home.getOfferTopBar().goToGiftCards();
		
		ass.assertTrue(gc.getgiftCardContainer().isDisplayed());
		gc.getgiftCardContainer().nykaaForCorporatesClick();
		Assert.assertTrue(gc.getgiftCardContainer().verifyNykaaForCorporates());
		
		ass.assertTrue(gc.getMail().isDisplayed());
		gc.getMail().goToFooterTitle();
		gc.getMail().inputMailClick();
		gc.getMail().sendMailClick();
		ass.assertTrue(gc.getMail().validateResponse());
		
	}
	
	
}
