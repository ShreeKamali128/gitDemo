package DriverInit;

import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import com.google.common.util.concurrent.Uninterruptibles;

import utils.ReusableMethod;

public class BaseTest {
	
	protected WebDriver driver;
	protected Properties prop;
	protected ReusableMethod rm;

	@BeforeTest
	public void setUpDriver() throws Exception
	{
		if(driver==null)
		{
		System.setProperty("webdriver.edge.driver", System.getProperty("user.dir")+"\\src\\test\\java\\resources\\edgedriverN");
		this.driver = new EdgeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		rm = new ReusableMethod(driver);
		prop=rm.propInit(prop);
		String url=prop.getProperty("url");	
		driver.get(url);
		}
	}
	
	@AfterTest
	public void stopDriver()
	{
		Uninterruptibles.sleepUninterruptibly(Duration.ofSeconds(3));
		this.driver.quit();
	}
	

}
