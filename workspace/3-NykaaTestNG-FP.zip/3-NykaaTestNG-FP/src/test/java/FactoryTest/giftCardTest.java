package FactoryTest;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import DriverInit.BaseTest;
import FactoryPattern._Factory;
import common.AbstractComponent;

public class giftCardTest extends BaseTest{
	
	private AbstractComponent ac;
	
	@Test(dataProvider="factoryGet")
	public void giftCardTests(String scenario, String keyword)
	{
		 this.ac=_Factory.get(scenario, this.driver);
		 this.ac.isDisplayed();
	}
	
	
	@DataProvider
	public Object[][] factoryGet()
	{
		return new Object[][]
				{
			//Factory
			{"gc","gcard"},
			{"ml","mail"},
			
				};
	}
}
