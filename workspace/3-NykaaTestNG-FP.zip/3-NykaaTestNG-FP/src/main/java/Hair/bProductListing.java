package Hair;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import common.AbstractComponent;

public class bProductListing extends AbstractComponent{



	
	@FindBy(css = "[class*='productWrapper']:nth-child(1) a")
	WebElement product;
	
	
	public bProductListing(WebDriver driver) {
		super(driver);
	}

	
	public void productClick() throws InterruptedException
	{
		product.click();
		rm.switchChild();
		rm.sleepMethod();
	}
	
	
	@Override
	public boolean isDisplayed() {
		return this.w.until((d)-> product.isDisplayed());
	}
	
	

}
