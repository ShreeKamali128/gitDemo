package Hair;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import common.AbstractComponent;

public class dCartProducts extends AbstractComponent {

	
	public String proddInCart=null;
	public ArrayList<String> wins= null;
	
	
	By prod = By.xpath("(//div[@class='product-name'])[last()]");
	public WebElement prodInCart() {
		return driver.findElement(prod);
	}

	@FindBy(css="[src*='Cart']")
	public WebElement cartiFrame;
	

	@FindBy(css = "[class='page-info'] span:nth-child(1)")
	WebElement shoppingBag;

	
	@FindBy(css =".payment-tbl-data")
	WebElement payBackDrop;
	
	
	@FindBy(css = " button[class*='coupon'] span")  //    [data-test-id='coupon_card']
	WebElement viewCoupons;


	@FindBy(css = "[class*='scrollable'] span:nth-child(1)")
	WebElement noCoupon;


	@FindBy(css = ".back-btn")
	WebElement backButton;


	@FindBy(css = ".payment-tbl-data div:nth-child(3) .value")
	WebElement subtotal;

	@FindBy(xpath = "//*[text()='Shipping Charge']/parent::div/following-sibling::div/i/*[name()='svg']")
	WebElement shippingCharge;
	
	@FindBy(xpath ="//span[text()='Payment Details']")
	WebElement paymentHeading;

	
	@FindBy(xpath="following-sibling::div/div")
	public WebElement shippingText;

	@FindBy(css = ".payment-tbl-data div:nth-child(4) ")
	WebElement grandTotal;

	
	public dCartProducts(WebDriver driver) {
		super(driver);
		
	}
	
	
	
	public void switchFrame()
	{
		rm.explicitWait(this.w,cartiFrame);
		rm.switchFrame(cartiFrame);
		System.out.println("switched...");
	}
	
	public String cartProduct() throws Exception
	{
		rm.implicitWait(driver);
		rm.sleepMethod();
		proddInCart = prodInCart().getText().split(" ")[3];
		//Assert.assertEquals(proddInCart,topRatedProduct);
		return proddInCart;
		
	}
	
	public void coupons() throws Exception
	{
		
		rm.moveToElement_ClickAction(act, payBackDrop);
		rm.KeyAction(act, Keys.ARROW_DOWN);
		
		rm.sleepMethod();
		rm.moveToElementAction(act, viewCoupons);
		
		rm.sleepMethod();
		rm.moveToElement_ClickAction(act, paymentHeading);
		
		rm.KeyAction(act, Keys.ARROW_DOWN);
		
		rm.moveToElement_ClickAction(act, viewCoupons);
		
		rm.implicitWait(driver);
		System.out.println(noCoupon.getText());

		rm.sleepMethod();
		backButton.click();
	}
	

	
	
	public void chargeFees() throws InterruptedException
	{		
		rm.implicitWait(driver);
		rm.sleepMethod();
		
		rm.moveToElement_ClickAction(act, shippingCharge);
		
		rm.sleepMethod();
	
		rm.moveToElement_ClickAction(act, shippingCharge);
		
		rm.sleepMethod();
		//System.out.println("SubTotal:  " + subtotal.getText()+ "\n" + "ShippingCharge:  " + shippingText().getText() + "\n" + "GrandTotal:  " + grandTotal.getText());
	}
	
	
	public void closeFrame() throws InterruptedException
	{		
		driver.close();
		rm.switchParent();
		System.out.println("BACK IN: " + driver.getTitle().split(" - ")[0].toUpperCase().toString());
		
	}


	@Override
	public boolean isDisplayed() {
		
		return this.w.until((d) -> prodInCart().isDisplayed());
	}

}
