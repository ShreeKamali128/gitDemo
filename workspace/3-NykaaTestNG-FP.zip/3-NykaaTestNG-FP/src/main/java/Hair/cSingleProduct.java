package Hair;

import java.util.ArrayList;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import common.AbstractComponent;

public class cSingleProduct extends AbstractComponent
{
	
	public static String topRatedProduct =null;
	
	
	@FindBy(css = ".css-1gc4x7i")
	WebElement prodh1;


	@FindBy(xpath = "(//span[@class='btn-text'])[1]")
	WebElement addToBag;
	
	
	
	public cSingleProduct(WebDriver driver) {
		super(driver);
	}
	
	
	public String topRatedProduct()
	{
		topRatedProduct = prodh1.getText().split(" ")[3];
		return topRatedProduct;
	}
	public void addToBagClick() throws Exception
	{
		//rm.sleepMethod();
		//topRatedProduct = prodh1.getText().split(" ")[3];
	
		addToBag.click();
		rm.implicitWait(driver);
		//return topRatedProduct;
		
	}
	
	@Override
	public boolean isDisplayed() {
		return this.w.until((d)-> prodh1.isDisplayed());
	}
	
	

}
