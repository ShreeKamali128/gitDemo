package FactoryPattern;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import common.AbstractComponent;

public class aGiftCards extends AbstractComponent{
	
	
	@FindBy(xpath="//div[@class='giftcard-container']//div[contains(@class,'tabs-container')]/ul")
	public WebElement giftCardsHeader;
	
	@FindBy(css="#nykaaforCorporates span")
	public WebElement nykaforCorporates;
	

	@FindBy(xpath="//h2[text()='Nykaa for Corporates']")
	public WebElement textNykaaForCorporates;
	
	
	public aGiftCards(final WebDriver driver)
	{
		super(driver);
	}
	
	public void nykaaForCorporatesClick()
	{
		nykaforCorporates.click();
		this.rm.implicitWait(driver);
	}
	
	public boolean verifyNykaaForCorporates()
	{
		return this.textNykaaForCorporates.getText().toLowerCase().contains("nykaa for corporates");
		
	}
		

	@Override
	public boolean isDisplayed() {
		return this.w.until(d-> this.giftCardsHeader.isDisplayed());
	}
	
	
	

}
