package FactoryPattern;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

import org.openqa.selenium.WebDriver;

import GiftCard.aGiftCards;
import GiftCard.bMail;
import common.AbstractComponent;


public class _Factory {
	
	public WebDriver driver;
	
	public _Factory(WebDriver driver)
	{
		this.driver=driver;
	}

	
	private static final Function<WebDriver,AbstractComponent> gc = d -> new aGiftCards(d);
	private static final Function<WebDriver,AbstractComponent> ml = d -> new bMail(d);
	
	
	private static final  Map<String,Function<WebDriver, AbstractComponent>> map=new HashMap<>();
	
	static {
		map.put("gcard", gc);
		map.put("mail", ml);
		   }
	
	
	public static AbstractComponent get(String scenario, WebDriver driver)
	{
		return map.get(scenario).apply(driver);
		
//		if(scenario.equalsIgnoreCase("gcard"))
//		{	return new aGiftCards(driver); }
//		else if(scenario.equalsIgnoreCase("mail"))
//			return new bMail(driver);
	}
}
