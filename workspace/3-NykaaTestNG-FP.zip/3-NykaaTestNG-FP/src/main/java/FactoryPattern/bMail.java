package FactoryPattern;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import common.AbstractComponent;

public class bMail extends AbstractComponent{

	@FindBy(css=".footer__newsletter")
	public WebElement footerContainer;
	
	@FindBy(css="[class*='newsletter'] input")
	public WebElement mailInput;
	
	
	@FindBy(xpath="(//*[contains(@class,'send')]) [2]")
	public WebElement sendMail;
	
	
	@FindBy(css="[class='glyphicon glyphicon-ok-circle mm-icon'] span")
	public WebElement thanksForSubscribing;
	
	public bMail(final WebDriver driver)
	{
		super(driver);
	}
	
	public void goToFooterTitle()
	{
		this.rm.moveToElementAction(act, footerContainer);
	}
	
	public void inputMailClick() throws Exception
	{
		prop=this.rm.propInit(prop);
		mailInput.click();	
		mailInput.sendKeys(prop.getProperty("mail"));
	}
	
	public void sendMailClick()
	{
		sendMail.click();	
	}
	
	public boolean validateResponse() 
	{
		return this.driver.getPageSource().contains("Thanks for subscribing");
	}

	@Override
	public boolean isDisplayed() {
		
		return this.w.until(d-> this.footerContainer.isDisplayed());
	}

	
}
