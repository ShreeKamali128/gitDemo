package common;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class cSubHeaderBar extends AbstractComponent {
	
	//public WebDriver driver;
	
	
	@FindBy(css="#category_navigation")
	public WebElement subHeaderMenu;
	
	@FindBy(xpath="(//div[@id='my-menu']//a[text()='hair'])[1]")
	public WebElement hairCategory;
	
	
	@FindBy(xpath="(//a[text()='hair care'])[1]")
	public WebElement hairCare;
	

	@FindBy(xpath="(//a[text()='skin'])[2]")
	public WebElement skinCategory;
	
	
	@FindBy(xpath="//a[text()='Cleansers']")
	WebElement cleansers;
	
	
	public cSubHeaderBar(WebDriver driver) {
		super(driver);
	}

	
	public void goToHairCategory()
	{
		this.rm.moveToElementAction(this.act,hairCategory);
	}
	
	public void goToHairCare() throws Exception
	{
		this.rm.explicitWait(this.w, hairCare);
		hairCare.click();
		this.rm.switchWindow();
	}
	
	public void goToSkinCategory()
	{
		this.rm.moveToHomeAction(act);
		this.rm.explicitWait(this.w, skinCategory);
		this.rm.moveToElementAction(this.act,skinCategory);
	}
	
	public void goTocleansers() throws Exception
	{
		cleansers.click();
		this.rm.switchWindow();
	}
	
	
	
	@Override
	public boolean isDisplayed() {
		 return this.w.until(d-> this.subHeaderMenu.isDisplayed());
	}

}
