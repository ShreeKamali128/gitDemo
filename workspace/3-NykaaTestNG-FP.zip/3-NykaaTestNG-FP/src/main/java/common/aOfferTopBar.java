package common;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class aOfferTopBar extends AbstractComponent {
	
	// public WebDriver driver;
	
	@FindBy(xpath="//div[@id='offer-banner']//div[contains(@class,'rightDiv')]")
	public WebElement offerBar; 
	
	@FindBy(css="[class*='rightDiv ts-wrap-r'] li:nth-child(2) a")
	public WebElement storesEvents;
	
	
	@FindBy(css="[class*='rightDiv ts-wrap-r'] li:nth-child(3) a")
	public WebElement giftCards;
	
	
	
	public aOfferTopBar(WebDriver driver) {
		super(driver);
	}

	public void goToStoresEvents()
	{
		this.rm.explicitWait(this.w, storesEvents);
		storesEvents.click();
	}
	
	public void goToGiftCards() throws Exception
	{
		this.rm.explicitWait(this.w, giftCards);
		giftCards.click();	
		this.rm.switchWindow();
	}

	
	
	@Override
	public boolean isDisplayed() {
		 return this.w.until(d-> this.offerBar.isDisplayed());
	}

}
