package GiftCard;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import common.bHeaderBar;
import common.aOfferTopBar;
import common.cSubHeaderBar;

public class _GiftCardPO {
	
	private WebDriver driver;
	private aGiftCards gc;
	private bMail mail;
	
	
	public _GiftCardPO(final WebDriver driver)
	{
		this.driver=driver;
		this.gc = PageFactory.initElements(driver, aGiftCards.class);
		this.mail= PageFactory.initElements(driver, bMail.class);
		
	}
	
	public aGiftCards getgiftCardContainer()
	{ return gc;}

	public bMail getMail()
	{
		return mail;
	}
}
