package framework;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Demo3 {
 
	@Test(groups= {"smoke"})
	public void demo1()
	{
		System.out.println("Demo1--3");
	}
	@Parameters({"Key","Value"})
	@Test
	public void demo2(String key,String val)
	{
		System.out.println("Demo2--3");
		System.out.println(key);
		System.out.println(val);
	}
	@Test
	public void demo3()
	{
		System.out.println("Demo3--3");
	}
	@BeforeSuite
	public void Bsuite()
	{
		System.out.println("Before suite..");
	}
	@BeforeMethod
	public void Bmethod()
	{
		System.out.println("I will execute before any method in Demo3 class file..");
	}
	@AfterMethod
	public void Amethod()
	{
		System.out.println("I will execute after any method in Demo3 class file..");
	}
	
}
