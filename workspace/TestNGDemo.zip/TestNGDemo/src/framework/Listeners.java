package framework;

import org.testng.ITestListener;
import org.testng.ITestResult;

public class Listeners implements ITestListener {
	@Override
	public void onTestSuccess(ITestResult result)
	{
		System.out.println("Successfully completed...");
	}

	@Override
	public void onTestFailure(ITestResult result)
	{
		System.out.println("I failed on executing assert.. for TC named "+ result.getName());
		
	}

}
