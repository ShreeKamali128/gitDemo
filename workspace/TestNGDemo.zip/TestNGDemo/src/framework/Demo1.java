package framework;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Demo1 {

	@AfterClass
	public void Afterclass()
	{
		System.out.println("After Class ");
	}
	@Test(groups= {"smoke"})
	public void demo1()
	{
		System.out.println("Demo1--1 smoke");
	}
	@Parameters({"URL"})
	@Test
	public void  demo2(String urlname)
	{
		System.out.println("Demo2--1");
		System.out.println(urlname);
	}
	@AfterSuite
	public void Asuite()
	{
		System.out.println("after Suite..");
	}
	@BeforeClass
	public void B4class()
	{
		System.out.println("Before Class");
	}
	@Test
	public void sample()
	{
		System.out.println("testfailure");
		Assert.assertTrue(false);
	}
	
	

}
