package Test;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;

import java.io.File;
import java.io.FileInputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;

import org.testng.annotations.Test;

import pageObjects1.*;
import resources1.*;

public class Test1 extends DriverInit{
	
	public WebDriver driver=null;
	
	@Test
	public void myWipro() throws Throwable {
		
		Home hm=new Home(driver);
		Appstore as= new Appstore(driver);
		EffortsHolidays eh= new EffortsHolidays(driver);
		MedclaimFinder mcf= new MedclaimFinder(driver);
		ImarketDashboardLogout idl= new ImarketDashboardLogout(driver);
		ReusableMeths rm= new ReusableMeths(driver);
		
		driver=rm.init(driver);
		rm.getUrl(driver);
		
	//	hm.slider(driver);
	//	hm.noOftasks(driver);
		hm.noOfRequests(driver);
		hm.wiproOnAir(driver); 
		hm.helpline(driver);							
		rm.implicitWait(driver);
		
		as.performSearch(driver);
		as.favourites(driver);
		
     	eh.efforts(driver);
		mcf.medicalClaim(driver);
		mcf.finder(driver);
		
		idl.iMarketScape(driver);
		idl.dashboard(driver);
		idl.logout(driver);	
		
		//rm.close(driver);
		
	}
}
