package pageObjects1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import resources1.*;

public class MedclaimFinder {
	
	public JavascriptExecutor js = null;
	public Properties prop=null;
	public WebDriver driver;    											 //driver object created
	
	public MedclaimFinder(WebDriver driver)
	{
		this.driver=driver;                						//life for driver is only given here or else null exception thrown
		PageFactory.initElements(driver, this);
	}
	
	By insurance= By.xpath("//div[@id='dvMainMenu']//li[@id='liInsurance']");
	WebElement insuranceClaim;
	public WebElement insuranceClaim()
	{
		insuranceClaim=driver.findElement(insurance);
		return insuranceClaim;
	}
	
	By st=By.xpath("//h3[@class='hthree']/following-sibling::ul/li/span");//(//ul//li//span[@class='pull-left txt1'])[1]
	List<WebElement> stepsToclaim;
	public List<WebElement> stepsToclaim()
	{ 
		stepsToclaim= driver.findElements(st);
		return stepsToclaim;
	}
	
	
	@FindBy(xpath="(//span[@class='col-lg-12 pull-left txt1 weight no-pad mrgbt4'])[1]")
	WebElement step2;
	public WebElement step2()
	{
		return step2;
	}
	
	
	@FindBy(css="#homelogo")
	WebElement mwMed;
	public WebElement mwMed()
	{
		return mwMed;
	}
	
	
	
	
	
	
	
	@FindBy(css="#txtFind")
	WebElement enterName;
	public WebElement enterName()
	{
		return enterName;
	}
	
	
	@FindBy(css="[title='Search']")
	WebElement searchName;
	public WebElement searchName()
	{
		return searchName;
	}
	
	
	@FindBy(css="#spMobNo a")
	WebElement mobileNum;
	public WebElement mobileNum()
	{
		return mobileNum;
	}
	
	
	@FindBy(css="#spName")
	WebElement verifyName;
	public WebElement verifyName()
	{
		return verifyName;
	}
	
	@FindBy(css="#myWurl")
	WebElement finderMW;
	public WebElement finderMW()
	{
		return finderMW;
	}
	
	
	
	
	public  WebDriver medicalClaim(WebDriver driver) throws Throwable
	{
		Home hm=new Home(driver);
		Appstore as= new Appstore(driver);
		ReusableMeths rm= new ReusableMeths(driver);
		MedclaimFinder mcf= new MedclaimFinder(driver);
		WebDriverWait w=rm.explicitWait(driver);
		w.until(ExpectedConditions.visibilityOfElementLocated(hm.store));
		
		hm.appStore().click();
		Thread.sleep(5000);
		
		rm.scrollWin5(js);
		
		as.finance().click();
		as.medicalClaim().click();
		
		w.until(ExpectedConditions.visibilityOfElementLocated(hm.iframe));
		rm.iFrameSwitch(driver);
		
		rm.switchChild(driver);
		w.until(ExpectedConditions.visibilityOfElementLocated(mcf.insurance));
		
		mcf.insuranceClaim().click();
		rm.implicitWait(driver);
		
		System.out.println("In: "+ driver.getTitle() +"...");
		
	/*	StringBuilder sb = new StringBuilder();
		List<WebElement> listOfSteps=mcf.stepsToclaim();
		
		for(WebElement i: listOfSteps)
		{
			System.out.println(i.getText());	
			
			sb.append(i.getText());
			sb.append("\n");
		}
	
		String[] str= {"Kamali", "Ram","Janani"};
	  	for(String i: str)
		{
			sb.append(i);
			sb.append("\n");
		}
	*/	
	//	System.out.println(sb.toString());
		
	//	rm.exceldata(sb.toString());
		
		mcf.mwMed().click();
		Thread.sleep(3000);
		
		return driver;
	}
	
	
	
	

	public  WebDriver finder(WebDriver driver) throws Throwable
	{
		Home hm=new Home(driver);
		Appstore as= new Appstore(driver);
		ReusableMeths rm= new ReusableMeths(driver);
		MedclaimFinder mcf= new MedclaimFinder(driver);
		WebDriverWait w=rm.explicitWait(driver);
		prop=rm.propInit(prop);	
		w.until(ExpectedConditions.visibilityOfElementLocated(hm.store));
		
		hm.appStore().click();
		Thread.sleep(3000);
		
		rm.scrollWin5(js);
		Thread.sleep(3000);
		
		as.information().click();
		Thread.sleep(3000);
		
		as.finder().click();
		Thread.sleep(10000);
		
		rm.iFrameSwitch(driver);
		rm.switchChild(driver);
	
		System.out.println("In :"+ driver.getTitle() + "...");
		Assert.assertTrue(driver.getTitle().contains("Finder"));
		
		mcf.enterName().click();
		mcf.enterName().sendKeys(prop.getProperty("name"));
		
		mcf.searchName().click();
		
		rm.implicitWait(driver);
		Thread.sleep(5000);
		

		StringBuilder sb = new StringBuilder();
		List<WebElement> list=new ArrayList<WebElement>();
		list.add(mcf.verifyName());
		list.add(mcf.mobileNum());
		
		for(WebElement i: list)
		{
			System.out.println(i.getText());	
			
			sb.append(i.getText());
			sb.append("\n");
		}
		
		rm.exceldata(sb.toString());
		
		Assert.assertEquals(mcf.verifyName().getText(),prop.getProperty("name"));
		Assert.assertEquals(mcf.mobileNum().getText(),prop.getProperty("mobile"),"Finder asserted");
		
		
		mcf.finderMW().click();
		Thread.sleep(3000);
		
		return driver;
	}
	
}
