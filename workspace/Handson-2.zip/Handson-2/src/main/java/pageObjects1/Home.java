package pageObjects1;


import java.util.List;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;


import resources1.*;

public class Home {
	
	     												   //driver object created
	public WebDriver driver;
	public JavascriptExecutor js = null;
	public Properties prop=null;
	
	public Home(WebDriver driver)
	{
		this.driver=driver;                						//life for driver is only given here or else null exception thrown
		PageFactory.initElements(driver, this);
	}
	
	
	
	By iframe= By.cssSelector("[class*='iframeStyle']");
	WebElement iFrame;
	public WebElement iFrame()
	{
		iFrame= driver.findElement(iframe);
		return iFrame;
	}
	
	
	@FindBy(xpath="//*[@class='icon-search']/following-sibling::span")
	WebElement searchHome;
	public WebElement searchHome()
	{
		return searchHome;
	}
	
	
	
	By listOfSliders=By.cssSelector(".bannerStyle.item");
	List<WebElement> sliders;
	public List<WebElement> sliders()
	{
		sliders=driver.findElements(listOfSliders);
		return sliders;
	}
	
	@FindBy(css="[class='col-xs-12 no_pad banner_cls'] [class='bannerStyle item']:nth-child(3)")
	WebElement slider2;
	public WebElement slider2()
	{
		return slider2;
	}
	
	
	@FindBy(css="h1[class*='article'] ")
	WebElement sliderPageTitle;
	public WebElement sliderPageHeading()
	{
		return sliderPageTitle;
	}
	
	
	@FindBy(xpath="//div[@class='col-xs-12 no_pad rgtsection_in rgtsection_top task_cls overflowVis'] //button[text()='View']")
	WebElement viewTasks;
	public WebElement viewTasks()
	{
		return viewTasks;
	}
	
	@FindBy(css="[title='Helpline']")
	WebElement myHelpline;
	public WebElement  myHelpLine()
	{
		return  myHelpline;
	}
	
	
	@FindBy(css="[title='Settings']")
	WebElement settings;
	public WebElement settings()
	{
		return settings;
	}
	
	
	@FindBy(css="[class='pull-right app_num task_num']")
	WebElement insideTasksCount;
	public WebElement insideTasksCount()
	{
		return insideTasksCount;
	}
	
	@FindBy(css="[title='close']")
	WebElement close;
	public WebElement close()
	{
		return close;
	}

	@FindBy(xpath="//div[@class='col-xs-12 no_pad rgtsection_in rgtsection_top task_cls overflowVis'] //div[@class='pull-right app_num']")
	WebElement tasksCount;
	public WebElement tasksCount()
	{
		return tasksCount;
	}
	
	@FindBy(xpath="//div[@class='col-xs-12 no_pad newstatus_cls rgtsection_top'] //button[@title='View']")
	WebElement viewRequests;
	public WebElement viewRequests()
	{
		return viewRequests;
	}
	
	By reqCount= By.cssSelector("[class='col-xs-12 col-sm-12 col-md-12 col-lg-12 nopad'] [class='pull-right ptop25']");
	WebElement insideReqCount;
	public WebElement  insideReqCount()
	{
		insideReqCount=driver.findElement(reqCount);
		return  insideReqCount;
	}
	
	
	@FindBy(xpath="//div[@class='col-xs-12 no_pad newstatus_cls rgtsection_top'] //div[@class='pull-right app_num']")
	WebElement requestsCount;
	public WebElement requestsCount()
	{
		return requestsCount;
	}
	
	
	@FindBy(css="[class='mw']")
	WebElement mw;
	public WebElement mw()
	{
		return mw;
	}
	
	
	@FindBy(css="[aria-label='View archives']")
	WebElement viewArchives;
	public WebElement viewArchives()
	{
		return viewArchives;
	}
	
	
	@FindBy(css="[class='playMusic'] ul li:nth-child(4) div")
	WebElement playBtn;
	public WebElement playBtn()
	{
		return playBtn;
	}
	
	
	@FindBy(xpath="//ul[@class='nav navbar-nav']//li[@id='two']")
	WebElement archiveBtn;
	public WebElement archiveBtn()
	{
		return archiveBtn;
	}
	
	
	By c=By.cssSelector("[class='row dvArchive'] [class='col-md-6']");
	List<WebElement> archiveCount;
	public List<WebElement> archiveCount()
	{
		archiveCount=driver.findElements(c);
		return archiveCount;
	}
	
	
	@FindBy(css="#home_logo")
	WebElement mwOnAir;
	public WebElement mwOnAir()
	{
		return mwOnAir;
	}
	
	By store=By.cssSelector("[class='mt10 col-xs-4 col-sm-4 col-md-4 col-lg-4 no_pad fav_circle animate_fav  fav_nine icon_text_hover'] button");
	WebElement appStore;
	public WebElement appStore()
	{
		appStore=driver.findElement(store);
		return appStore;
	}
	
	
	By status=By.xpath("//div[contains(@class,'fav_circle')]//div[contains(@class,'fav_link')]");
	List<WebElement> verifyMyStatus;
	public List<WebElement> verifyMyStatus()
	{
		verifyMyStatus=driver.findElements(status);
		return verifyMyStatus;
	}
	
	
	By homeTitle=By.cssSelector(".home_title");
	WebElement servicePgTitle;
	public WebElement servicePgTitle()
	{
		servicePgTitle=driver.findElement(homeTitle);
		return servicePgTitle;
	}
	
	
	
	public WebDriver slider(WebDriver driver) throws Exception
	{
		Home hm=new Home(driver);
		
		ReusableMeths rm= new ReusableMeths(driver);
		
		
		List<WebElement> sliders=hm.sliders();
		for(WebElement i: sliders)
		{
		if(i.equals(hm.slider2()))
			{ i.click();
			break;
			}	
		}
		rm.switchTab(driver);	
		return driver;
	}
	
	
	public  WebDriver noOftasks(WebDriver driver) throws Exception
	{	
		Home hm=new Home(driver);
		
		ReusableMeths rm= new ReusableMeths(driver);
		WebDriverWait w=rm.explicitWait(driver);
		
		w.until(ExpectedConditions.visibilityOfElementLocated(this.store));
		
		rm.scrollWin2(js);
		
		this.viewTasks().click();
		rm.implicitWait(driver);
		String inner=this.insideTasksCount().getText();
		
		this.close().click();
		String outter=this.tasksCount().getText();
		
		String outterArr=outter.split("0")[1].toString();
		System.out.println("No. of Tasks: "+outterArr);
		//Assert.assertEquals(inner,outterArr);   //(actual,expected)[2,2]
		
		return driver;
	}
	
	
	public  WebDriver noOfRequests(WebDriver driver) throws Exception
	{
		
		Home hm=new Home(driver);
		ReusableMeths rm= new ReusableMeths(driver);
		WebDriverWait w=rm.explicitWait(driver);
		
		w.until(ExpectedConditions.visibilityOfElementLocated(hm.store));
		
		rm.scrollWin2(js);
		
		hm.viewRequests().click();
		Thread.sleep(9000);
		w.until(ExpectedConditions.visibilityOfElementLocated(hm.iframe));
		driver.switchTo().frame(hm.iFrame());
		
		w.until(ExpectedConditions.visibilityOfElementLocated(hm.reqCount));
		String in=hm.insideReqCount().getText();
		String inArr=in.split(" ")[0].toString();
		System.out.println("No. of Requests: "+ inArr);
		rm.implicitWait(driver);
		
		hm.mw().click();
		
		driver.switchTo().defaultContent();
	
		rm.implicitWait(driver);
		String out=hm.requestsCount().getText();
		String outArr=out.split("0")[1].toString();
		
		Assert.assertEquals(outArr, inArr);
		
		return driver;
	}
	
	public  WebDriver wiproOnAir(WebDriver driver) throws Exception
	{
		Home hm=new Home(driver);
		ReusableMeths rm= new ReusableMeths(driver);
		WebDriverWait w=rm.explicitWait(driver);
		
		w.until(ExpectedConditions.visibilityOfElementLocated(hm.store));
		
		rm.scrollWin5(js);
		
		hm.viewArchives().click();
		//Thread.sleep(7000);
		rm.implicitWait(driver);
		rm.iFrameSwitch(driver);
		rm.switchChild(driver);
		
		//Thread.sleep(5000);
		rm.implicitWait(driver);
	
		hm.playBtn().click();   //start
		Thread.sleep(5000);
		hm.playBtn().click();     //stop
		
		hm.archiveBtn().click();
		//Thread.sleep(5000);
		
		rm.scrollWin5(js);
		
		int size=hm.archiveCount().size();
		System.out.println("Number of Archive items is: "+ size);
		
		hm.mwOnAir().click();
		
		return driver;
	}
	
	
	public  WebDriver helpline(WebDriver driver) throws Exception
	{
		Home hm=new Home(driver);
		ReusableMeths rm= new ReusableMeths(driver);
		WebDriverWait w=rm.explicitWait(driver);
		prop=rm.propInit(prop);
		
		
		w.until(ExpectedConditions.visibilityOfElementLocated(hm.store));
		rm.implicitWait(driver);
		
		hm.myHelpLine().click();
		Thread.sleep(9000);
		
		rm.implicitWait(driver);
		rm.winHandles(driver);
		Thread.sleep(9000);
		
		//w.until(ExpectedConditions.visibilityOfElementLocated(hm.homeTitle));
		Assert.assertTrue(driver.getTitle().toLowerCase().contains("self service"));
		
		rm.switchParent(driver);
		return driver;
	}
	
	
	
	
	/*
	public  WebDriver (WebDriver driver) throws Exception
	{
		
		Home hm=new Home(driver);
		Appstore as= new Appstore(driver);
		ReusableMeths rm= new ReusableMeths(driver);
		WebDriverWait w=rm.explicitWait(driver);
		prop=rm.propInit(prop);
		
		return driver;
	}
	*/

	
	

}
