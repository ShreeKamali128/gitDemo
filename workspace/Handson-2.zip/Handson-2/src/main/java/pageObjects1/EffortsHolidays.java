package pageObjects1;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import resources1.*;

public class EffortsHolidays {
	
	public JavascriptExecutor js = null;
	public Properties prop=null;
	public WebDriver driver;    											 //driver object created
	
	public EffortsHolidays(WebDriver driver)
	{
		this.driver=driver;                						//life for driver is only given here or else null exception thrown
		PageFactory.initElements(driver, this);
	}

	
	@FindBy(xpath="//a[@class='tms_home']")
	WebElement timesMw;
	public WebElement timesMw()
	{
		return timesMw;
	}
	
	@FindBy(xpath="//nav[@id='headerToolTip']/a[1]")
	WebElement efforts;
	public WebElement efforts()
	{
		return efforts;
	}

	
	By yes=By.xpath("parent::div/parent::div/parent::div//button[@class='btnYesApply']");
	public By doYouYesBtn()
	{
		return yes;
	}
	
	By learn=By.xpath("parent::div/parent::div/parent::div//input[contains(@aria-label,'Efforts for LEARNING OR DEVELOPMENT')]");
	public By learn()
	{
		return learn;
	}
	
	By leave=By.xpath("//ul/li[2]");
	WebElement leaveOptn;
	public WebElement leaveOptn()
	{
		leaveOptn=driver.findElement(leave);
		return leaveOptn;
	}
	
	By holiday=By.cssSelector(".holiday_Id");
	WebElement holidayCalendar;
	public WebElement holidayCalendar()
	{
		holidayCalendar=driver.findElement(holiday);
		return holidayCalendar;
	}
	
	
	By lvls=By.cssSelector("#holidaysDisplay li");
	List<WebElement>leaveCount;
	public List<WebElement> leaveCount()
	{
		leaveCount=driver.findElements(lvls);
		return leaveCount;
	}
	
	
	By dt=By.xpath("//span[@class='dates_head commo_btn']");
	List<WebElement> currentDate;
	public List<WebElement> currentDate()
	{
		currentDate=driver.findElements(dt);
		return currentDate;
	}
	
	
	@FindBy(xpath="//span[@class='dates_head commo_btn']/parent::div/parent::div/parent::div//button[@class='btnYesApply']")
	WebElement yesBtn;
	public WebElement yesBtn()
	{
		return yesBtn;
	}
	
	@FindBy(css=".rdbtncls")
	WebElement workFromHome;
	public WebElement workFromHome()
	{
		return workFromHome;
	}
	
	@FindBy(css=".pop_submit_btn")
	WebElement doneBtn;
	public WebElement doneBtn()
	{
		return doneBtn;
	}
	
	
	public  WebDriver myTime(WebDriver driver) throws Exception
	{
		Home hm=new Home(driver);
		Appstore as= new Appstore(driver);
		ReusableMeths rm= new ReusableMeths(driver);
		EffortsHolidays eh= new EffortsHolidays(driver);
		WebDriverWait w=rm.explicitWait(driver);
		w.until(ExpectedConditions.visibilityOfElementLocated(hm.store));
		
		hm.appStore().click();
		Thread.sleep(2000);
		
		rm.scrollWin5(js);	
		
		as.myTimeBtn().click();
		Thread.sleep(6000);
		rm.implicitWait(driver);
		
		driver.switchTo().frame(hm.iFrame());
		rm.implicitWait(driver);
		Thread.sleep(5000);		
		
		return driver;
	}
	
	public  WebDriver efforts(WebDriver driver) throws Exception
	{
		
		Home hm=new Home(driver);
		Appstore as= new Appstore(driver);
		ReusableMeths rm= new ReusableMeths(driver);
		EffortsHolidays eh= new EffortsHolidays(driver);
		WebDriverWait w=rm.explicitWait(driver);
		prop=rm.propInit(prop);
		
		eh.myTime(driver);
		
		eh.efforts().click();
		Thread.sleep(5000);
		
		
		DateFormat df = new SimpleDateFormat();
		Date date = new Date();
		String todaysDate=df.format(date);
		
		System.out.println("today's date is: "+todaysDate);
		String dateAlone=todaysDate.split("/")[0].toString();
		String yesterdaysDate = String.valueOf( (Integer.parseInt(dateAlone))-1 );
		
		List<WebElement> dates=eh.currentDate(); 	

		dates.stream().filter(s->s.getText().split(" ")[0].toString().contains(yesterdaysDate)).forEach(ss->ss.findElement(eh.doYouYesBtn()).click());
		Thread.sleep(2000);
		
		eh.workFromHome().click();
		Thread.sleep(2000);
	
		eh.doneBtn().click();
		Thread.sleep(2000);
		
		rm.scrollWin5(js);
		Thread.sleep(3000);
		
		dates.stream().filter(s->s.getText().split(" ")[0].toString().contains(yesterdaysDate)).forEach(ss->ss.findElement(eh.learn()).click());
		rm.implicitWait(driver);
		
		prop = rm.propInit(prop);
		dates.stream().filter(s->s.getText().split(" ")[0].toString().contains(yesterdaysDate)).forEach(ss->ss.findElement(eh.learn()).sendKeys(prop.getProperty("effort")));
		System.out.println("Efforts updated...");
		Thread.sleep(4000);
		
		eh.holidayCount(driver);
		Thread.sleep(3000);
		
		return driver;
	}
	
	
	public  WebDriver holidayCount(WebDriver driver) throws Exception
	{
		
		Home hm=new Home(driver);
		Appstore as= new Appstore(driver);
		ReusableMeths rm= new ReusableMeths(driver);
		EffortsHolidays eh= new EffortsHolidays(driver);
		WebDriverWait w=rm.explicitWait(driver);
		prop=rm.propInit(prop);
		w.until(ExpectedConditions.visibilityOfElementLocated(eh.leave));
		
		eh.leaveOptn().click();
		w.until(ExpectedConditions.visibilityOfElementLocated(eh.holiday));
		
		eh.holidayCalendar().click();
		rm.implicitWait(driver);
		
		int size=eh.leaveCount().size();
		System.out.println("Number of Holidays: "+ size);
		
		eh.timesMw().click();
		
		return driver;
	}
}
