package pageObjects1;

import java.io.File;
import java.io.FilenameFilter;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import resources1.*;


public class ImarketDashboardLogout {
	
	
	public JavascriptExecutor js = null;
	public Properties prop=null;
	public WebDriver driver;    											 //driver object created
	
	public ImarketDashboardLogout(WebDriver driver)
	{
		this.driver=driver;                						//life for driver is only given here or else null exception thrown
		PageFactory.initElements(driver, this);
	}

	
	

	By percent = By.cssSelector("[class='col-xs-12 nopad profile_completed'] span:nth-child(1)");
	WebElement profilePercent;
	public WebElement profilePercent()
	{
		profilePercent= driver.findElement(percent);
		return profilePercent;
	}
	
	
	@FindBy(css="[class='col-xs-12 nopad prof_details_line'] #accountName")
	WebElement myAccount;
	public WebElement myAccount()
	{
		return myAccount;
	}
	
	
	@FindBy(css="[title='AMR2 Canada WT78']")
	WebElement projectName;
	public WebElement projectName()
	{
		return projectName;
	}
	
	
	@FindBy(css=".menu_burger_icon")
	WebElement imarketmw;
	public WebElement imarketmw()
	{
		return imarketmw;
	}
	
	@FindBy(css=".pull-left.more_menu_icon .anchorFiller")
	WebElement threeDot;
	public WebElement threeDot()
	{
		return threeDot;
	}
	
	@FindBy(xpath="//*[text()='My Profile']")
	WebElement myProfile;
	public WebElement myProfile()
	{
		return myProfile;
	}
	
	@FindBy(css=".menu_burger_icon")
	WebElement mWProfile;
	public WebElement mwProfile()
	{
		return mWProfile;
	}
	
	By about = By.cssSelector("[class*='blockSectionTitle']");
	//@FindBy(css="[class*='blockSectionTitle']")
	WebElement aboutMe;
	public WebElement aboutMe()
	{
		aboutMe=driver.findElement(about);
		return aboutMe;
	}
	
	
	
	
	
	
	
	By btn= By.cssSelector("[class*='thumb']:nth-child(1)");
	List<WebElement> sliderBtn;
	public List<WebElement> sliderBtn()
	{
		sliderBtn=driver.findElements(btn);
		return sliderBtn;
	}
	
	
	@FindBy(css="[class*='faq_cls'] a")
	WebElement downloadLinkFAQ;
	public WebElement downloadLinkFAQ()
	{
		return downloadLinkFAQ;
	}
	
	@FindBy(css="[title='Logout']")
	WebElement logOutMyWipro;
	public WebElement logOutMyWipro()
	{
		return logOutMyWipro;
	}
	
	By login= By.cssSelector("[role='button']:nth-child(1)");
	WebElement loginMyWipro;
	public WebElement loginMyWipro()
	{
		return loginMyWipro;
	}
	
	
	public  WebDriver iMarketScape(WebDriver driver) throws Exception
	{
		Home hm=new Home(driver);
		Appstore as= new Appstore(driver);
		ReusableMeths rm= new ReusableMeths(driver);
		ImarketDashboardLogout idl= new ImarketDashboardLogout(driver);
		WebDriverWait w=rm.explicitWait(driver);
		prop=rm.propInit(prop);
		w.until(ExpectedConditions.visibilityOfElementLocated( hm.store ));
		
		hm.appStore().click();
		Thread.sleep(5000);
		
		as.career().click();
		Thread.sleep(3000);
		
		as.iMarketScape().click();
		
		rm.iFrameSwitch(driver);
		rm.switchChild(driver);
	
		String[] arr=driver.getTitle().split("/");
		for(String s: arr)
		{  
			if(s.contains("Imarketscape"))
			{ Assert.assertTrue(s.contains("Imarketscape"));
			System.out.println("In :"+ driver.getTitle() + "...");
			break;}
		}
		
		w.until(ExpectedConditions.visibilityOfElementLocated(idl.percent));
		 
		System.out.println(idl.profilePercent().getText() + " profile updated");
		Assert.assertFalse(idl.profilePercent().getText().contains("100%"),prop.getProperty("profileStatus"));
		
		Select sl=new Select(idl.myAccount());
		sl.selectByVisibleText(idl.projectName().getText());
		Thread.sleep(9000);
		
		idl.threeDot().click();
		idl.myProfile().click();
		
		//w.until(ExpectedConditions.visibilityOfElementLocated(idl.about));
		Thread.sleep(8000);
		rm.implicitWait(driver);
		Assert.assertTrue(idl.aboutMe().getText().contains("About Me"),"ImarketScape asserted");
		
		
		idl.mwProfile().click();
		Thread.sleep(5000);
		
		return driver;
	}
	
	
	public  WebDriver dashboard(WebDriver driver) throws Exception
	{
		Home hm=new Home(driver);
		ReusableMeths rm= new ReusableMeths(driver);
		ImarketDashboardLogout idl= new ImarketDashboardLogout(driver);
		WebDriverWait w=rm.explicitWait(driver);
		prop=rm.propInit(prop);
		w.until(ExpectedConditions.visibilityOfElementLocated(hm.store));
		
		hm.settings().click();
		
		List<WebElement> slider= idl.sliderBtn();
		
		slider.stream().forEach(s->s.click());
		
		idl.downloadLinkFAQ().click();
		
		
		File folder=new File("C:\\Users\\SH20204415\\Downloads");
		
		FilenameFilter filter= new FilenameFilter() {										//interface
			public boolean accept(File dir, String fname)
			{	
				return fname.contains("FAQ");
			}
		};
		
		File[] listOfFiles=folder.listFiles(filter);
	 	boolean found=false;
		for(File f:listOfFiles)
		{
			if(f.isFile())
			{
				String file=f.getName();
				if(file.contains("FAQ"))
				{
					found=true;
					Assert.assertTrue(found,"FAQ file downloaded");	
					System.out.println(file + " FAQ file downloaded");
				}
			}
			
		}
	/*	
		File[] listOfFiles=folder.listFiles( (dir,fname)->{
			return ( fname.contains("FAQ") && fname.matches( "[a-zA-Z]+\\.[a-z]" ) );
		});
		
		for(File f:listOfFiles)
		{
			System.out.println(f.getName() + " This FAQ file downloaded");
		}
		*/ 
		Thread.sleep(2000);
		return driver;
	}
	
	public  WebDriver logout(WebDriver driver) throws Exception
	{
		ReusableMeths rm= new ReusableMeths(driver);
		ImarketDashboardLogout idl= new ImarketDashboardLogout(driver);
		WebDriverWait w=rm.explicitWait(driver);
		
		idl.logOutMyWipro().click();
		
		w.until(ExpectedConditions.visibilityOfElementLocated(idl.login));
		
		rm.implicitWait(driver);
		//Assert.assertTrue(idl.loginMyWipro().isDisplayed(),"Logout asserted");
		
		return driver;
	}

}
