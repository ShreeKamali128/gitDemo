package pageObjects1;

import java.io.File;
import java.io.FileInputStream;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.asserts.SoftAssert;

import resources1.*;

public class Appstore {
	
	public JavascriptExecutor js = null;
	public Properties prop=null;
	public WebDriver driver;    											 //driver object created
	
	
	public Appstore(WebDriver driver)
	{
		this.driver=driver;     //life for driver is only given here or else null exception thrown
		PageFactory.initElements(driver, this);
	}

	
	@FindBy(xpath="//span[@class='icon-search']/following-sibling::span")
	WebElement findAnApp;
	public WebElement findAnApp()
	{
		return findAnApp;
	}
	
	
	@FindBy(css="[placeholder='Find an app']")
	WebElement inputFindAnApp;
	public WebElement inputFindAnApp()
	{
		return inputFindAnApp;
	}
	
	
	@FindBy(css="[class='active ng-star-inserted'] a")
	WebElement searchedItem;
	public WebElement searchedItem()
	{
		return searchedItem;
	}
	
	@FindBy(css="button[title='close']")
	WebElement closeSearch;
	public WebElement closeSearch()
	{
		return closeSearch;
	}
	
	@FindBy(css="h1[class='pull-left logo_text title_cls']")
	WebElement myWipro;
	public WebElement myWiprologo()
	{
		return myWipro;
	}
	
	
	@FindBy(xpath="//ul/li[3]//button[@title='MY TIME']")   
	WebElement myTimeBtn;
	public WebElement myTimeBtn()
	{
		return myTimeBtn;
	}
	
	@FindBy(css="#mat-tab-label-0-2")
	WebElement finance;
	public WebElement finance()
	{
		return finance;
	}
	
	
	@FindBy(xpath="//ul/li[6]//button[@title='MY MEDICAL CLAIM']")
	WebElement medicalClaim;
	public WebElement medicalClaim()
	{
		return medicalClaim;
	}
	
	@FindBy(xpath="(//span[contains(@aria-hidden,'true')][normalize-space()='Fav'])[20]")
	WebElement myStatus;
	public WebElement myStatus()
	{
		return myStatus;
	}
	
	@FindBy(xpath="//div[@role='alertdialog']//div[3]//button")
	WebElement ok;
	public WebElement ok()
	{
		return ok;
	}
	
	@FindBy(css="[title='yes']")
	WebElement removeYes;
	public WebElement removeYes()
	{
		return removeYes;
	}
	
	
	@FindBy(css="#mat-tab-label-0-5 div")
	WebElement information;
	public WebElement information()
	{
		return information;
	}
	
	@FindBy(xpath="//button[@title='FINDER']")
	WebElement finder;
	public WebElement finder()
	{
		return finder;
	}
	
	@FindBy(css="#mat-tab-label-0-1 div")
	WebElement career;
	public WebElement career()
	{
		return career;
	}
	
	
	@FindBy(css="[title='IMARKETSCAPE']")
	WebElement iMarketScape;
	public WebElement  iMarketScape()
	{
		return  iMarketScape;
	}
	
	public  WebDriver performSearch(WebDriver driver) throws Exception
	{
		Home hm=new Home(driver);
		Appstore as= new Appstore(driver);
		ReusableMeths rm= new ReusableMeths(driver);
		WebDriverWait w=rm.explicitWait(driver);
		prop=rm.propInit(prop);
		
		w.until(ExpectedConditions.visibilityOfElementLocated(hm.store));
		
		hm.appStore().click();
		//Thread.sleep(6000);
		rm.implicitWait(driver);
		
		as.findAnApp().click();
	
		as.inputFindAnApp().sendKeys(prop.getProperty("time"));
		Thread.sleep(3000);
		
		String searched=as.searchedItem().getText();
		Assert.assertTrue(searched.contains("mytime"));
		
		as.closeSearch().click();
		
		as.myWiprologo().click();	//Home
		rm.implicitWait(driver);
		
		Assert.assertTrue(driver.getTitle().contains("Home"),"Perform Search asserted");
		System.out.println("Performed search on mytime...");
		Thread.sleep(5000);
		
		
		return driver;
	}
	
	
	public  WebDriver favourites(WebDriver driver) throws Exception
	{
		Home hm=new Home(driver);
		Appstore as= new Appstore(driver);
		ReusableMeths rm= new ReusableMeths(driver);
		WebDriverWait w=rm.explicitWait(driver);
		prop=rm.propInit(prop);
		
		w.until(ExpectedConditions.visibilityOfElementLocated(hm.store));
		
		hm.appStore().click();
		Thread.sleep(5000);
		
		rm.scrollWin5(js);
		Thread.sleep(2000);
		
		as.myStatus().click();
		rm.implicitWait(driver);
		
		as.ok().click();
		Thread.sleep(2000);
		
		as.myWiprologo().click();                 //Home
		rm.implicitWait(driver);
		Thread.sleep(5000);
		
		List<WebElement> favApps=hm.verifyMyStatus();
		for(WebElement i: favApps)
		{
			if(i.getText().contains("myStatus"))
				{
				SoftAssert softAssert= new SoftAssert();
				softAssert.assertTrue(i.getText().contains("myStatus"));
				System.out.println("Favourite app MyStatus added to favourites..."); break;}
		           
		}
		
		hm.appStore().click();
		Thread.sleep(4000);
		
		as.myStatus().click();
		rm.implicitWait(driver);
		
		as.removeYes().click();
		as.myWiprologo().click();
		
		return driver;
	}
	
	
}
