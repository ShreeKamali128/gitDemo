package resources1;


import java.io.FileInputStream;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class DriverInit {
	
public WebDriver driver;
public Properties prop=null;
String browser=null;

   // @Parameters({"browser"})
	@Test
	public WebDriver driver() throws Exception
	{

		ReusableMeths rm= new ReusableMeths(driver);
	
		prop=rm.propInit(prop);
		browser=prop.getProperty("browser");
		
		
		if(browser.equals("edge"))
		{
			System.setProperty("webdriver.edge.driver", "C:/Users/SH20204415/Eclipse/edgedriver/msedgedriver.exe");
			driver = new EdgeDriver();
			
			
		}
		else if(browser.equals("chrome"))
		{
			System.setProperty("webdriver.chrome.driver","C:\\Users\\SH20204415\\Eclipse\\chromeDriver\\chromedriver.exe");
			driver = new ChromeDriver();
		}
		
		driver.manage().window().maximize();
		rm.implicitWait(driver);
		return driver;
	}

}
