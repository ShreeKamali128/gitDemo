package resources1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WindowType;

import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;


public class ReusableMeths extends DriverInit{
	

	public JavascriptExecutor js = null;
	public Properties prop=null;
	public WebDriver driver;
	public String parent=null;
	
	public ReusableMeths(WebDriver driver)
	{
		this.driver=driver;    //life for driver is only given here or else null exception thrown
		
	}
	
	
	@BeforeTest
	public WebDriver init(WebDriver driver) throws Exception
	{
		driver = driver();
		return driver;
	}
	
	public  Properties propInit(Properties prop) throws Exception
	{
		prop = new Properties();
		File f= new File("C:\\Users\\SH20204415\\eclipse-workspace\\Selenium\\HandsonSel\\src\\main\\java\\resources1\\Parameters.properties");
		FileInputStream fis = new FileInputStream(f);
		prop.load(fis);
	
		return prop;
	}
	
	
	@BeforeMethod
	public WebDriver getUrl(WebDriver driver) throws Exception
	{
		ReusableMeths rm= new ReusableMeths(driver);
		
		prop=rm.propInit(prop);
		driver.get(prop.getProperty("url"));
		
		rm.implicitWait(driver);
		
		String title= driver.getTitle();
		System.out.println( title );
		Assert.assertTrue(title.contains("Home"));
	
		return driver;
	}

	
	public WebDriver switchTab(WebDriver driver) throws Exception				//child switch then parent close
	{
		winHandles(driver);
		
		driver.close();
		driver.switchTo().window(parent);
		System.out.println("Back to parent.. "+ driver.getTitle());
		return driver;
	}
	
	
	public  WebDriver winHandles(WebDriver driver) throws Exception				//child switch alone
	{
		//driver.switchTo().newWindow(WindowType.TAB);
		Set<String> windows = driver.getWindowHandles();
		Iterator<String> itr = windows.iterator();
		parent = itr.next();
		Thread.sleep(3000);
		String child= itr.next();
		driver.switchTo().window(child);
		Thread.sleep(5000);
		System.out.println("Switched to Child:  "+driver.getTitle());
		return driver;
	}
	
	
	public WebDriver implicitWait(WebDriver driver)
	{
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		return driver;
	}
	
	public WebDriverWait explicitWait(WebDriver driver)
	{
		WebDriverWait w = new WebDriverWait(driver,Duration.ofSeconds(20));
		return w;
	}
	
	public JavascriptExecutor scrollWin5(JavascriptExecutor js) throws Exception
	{
		js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,500)");
		Thread.sleep(4000);
		return js;
	}
	
	public JavascriptExecutor scrollWin2(JavascriptExecutor js) throws Exception
	{
		js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,200)");
		Thread.sleep(4000);
		return js;
	}
	
	
	
	By frame= By.cssSelector("[class*='iframeStyle']");
	public WebDriver iFrameSwitch(WebDriver driver) throws Exception
	{
		String url=driver.findElement(frame).getDomAttribute("src");
		driver.switchTo().newWindow(WindowType.TAB);
		driver.get(url);
		Thread.sleep(4000);
		return driver;
	}
	
	
	public WebDriver switchChild(WebDriver driver) throws InterruptedException{    //child switch; parent close
		
		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		
		driver.switchTo().window(tabs.get(0));
		driver.close();
		driver.switchTo().window(tabs.get(1));
		return driver;
	}
	
	public WebDriver switchParent(WebDriver driver) throws InterruptedException{    //parent switch; child close
		
		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		
		driver.switchTo().window(tabs.get(1));
		driver.close();
		driver.switchTo().window(tabs.get(0));
		return driver;
	}
	
	
public void exceldata(String strr) throws Exception, Throwable {

		
		File f = new File("C:\\Users\\SH20204415\\eclipse-workspace\\Selenium\\HandsonSel\\src\\main\\java\\resources1\\MedClaimSteps.xlsx");
		FileInputStream inputStream = new FileInputStream(f);
		XSSFWorkbook wb = new XSSFWorkbook(inputStream);
		XSSFSheet sheet = wb.getSheet("Sheet1");
		
		String[] str=strr.split("\n");
		//System.out.println(str.length);
		
		for(int i=0;i<str.length;i++)
		{
			Row newRow = sheet.createRow(i);
			Cell cell = newRow.createCell(0);
			cell.setCellValue(str[i]);
		}
		
		inputStream.close();
		FileOutputStream outputStream= new FileOutputStream(f);
		wb.write(outputStream);
		outputStream.close();
		
		System.out.println("Added " + str.length + "data in excel...");
		}
	
	
	
	

	@AfterClass
	public void close(WebDriver driver) throws Exception
	{
	//	Thread.sleep(2000);
		driver.quit();
	}
	
}
