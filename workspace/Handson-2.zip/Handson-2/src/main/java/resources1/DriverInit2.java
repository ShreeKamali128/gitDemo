package resources1;

import java.io.File;
import java.io.FileInputStream;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

import org.apache.logging.log4j.*;

public class DriverInit2 {

	public static WebDriver driver;
	public Properties prop = null;
	private static Logger log = LogManager.getLogger(DriverInit2.class.getName());

	public WebDriver driverRem() throws Exception {
		prop = new Properties();
		File f = new File(
				"C:\\Users\\SH20204415\\eclipse-workspace\\Selenium\\HandsonSel\\src\\main\\java\\resources1\\Parameters.properties");
		FileInputStream fis = new FileInputStream(f);
		prop.load(fis);
		log.info("properties file loaded");
		log.debug("to maximize window..");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		return driver;
	}

	public static void main(String[] args) throws Exception {
		System.setProperty("webdriver.edge.driver", "C:/Users/SH20204415/Eclipse/edgedriver/msedgedriver.exe");
		log.info("routed to local edge driver successfully");
		driver = new EdgeDriver();
		log.info("driver instantiated successfully");
		DriverInit2 driv = new DriverInit2();
		log.debug("to call properties file in a method");
		driv.driverRem();
	}

}
