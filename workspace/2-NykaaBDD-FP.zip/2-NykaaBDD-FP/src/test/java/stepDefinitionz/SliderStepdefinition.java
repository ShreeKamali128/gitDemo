package stepDefinitionz;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import pageObjects.Home;
import pageObjects.SliderPage;
import utils.testContextSetUp;

public class SliderStepdefinition {
	
	public testContextSetUp tcs;
	SliderPage sp;
	
	public SliderStepdefinition(testContextSetUp tcs){			//dependency injection---object created for testContextSetUp
		this.tcs=tcs;
		this.sp=tcs.pom.sliderPage();
	}

	
	@Then("^click slider image second$")
	public void slider_lists() throws Exception
	{	
		sp.sliderBtnClick();
		sp.sliderImgClick();
		sp.printSliderName();
	}

}
