package stepDefinitionz;

import java.io.File;
import java.io.FileInputStream;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjects.GiftCards;
import pageObjects.Home;
import pageObjects.PageObjectManager;
import pageObjects.StoreEvents;
//import resources2.ReusableMeths;
import utils.testContextSetUp;

public class StoreEventsStepdefinition{
	

	public testContextSetUp tcs;
	StoreEvents se;
	
	public StoreEventsStepdefinition(testContextSetUp tcs){			//dependency injection---object created for testContextSetUp
		this.tcs=tcs;
		this.se=tcs.pom.storeEvents();
	}


@Then("search the city {string}")
public void search_the_city(String string) throws Exception

  {
	Assert.assertTrue(se.verifyStoreTitle());
	se.searchCity(string);
 
  }

@Then("print in excel")
public void print_in_excel() throws Throwable

  {	
	se.printExcel();
   
 } 

}