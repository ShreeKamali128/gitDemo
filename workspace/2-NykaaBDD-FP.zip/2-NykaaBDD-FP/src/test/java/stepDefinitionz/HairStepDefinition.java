package stepDefinitionz;

import org.testng.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjects.Hair;
import pageObjects.Home;
import utils.testContextSetUp;

public class HairStepDefinition {
	
	public testContextSetUp tcs;
	Hair hr;
	
	public HairStepDefinition(testContextSetUp tcs){			//dependency injection---object created for testContextSetUp
		this.tcs=tcs;
		this.hr=tcs.pom.hair();
	}

	@When("sort by dropdown filter applied")
	public void sort_by_dropdown_filter_applied() throws Exception {
		hr.sortByDropDowns();
		Assert.assertTrue(hr.verifyFilterApplied());
	}
	
	
	@Then("top rated product added to cart")
	public void top_rated_product_added_to_cart() throws Exception {
	
		hr.productClick();
		hr.switchTab();
		hr.addToBagClick();
		hr.viewBagClick();
		hr.switchFrame();
		hr.productVerify();
		hr.coupons();
		hr.chargeFees();
		hr.closeFrame();
	}

}
