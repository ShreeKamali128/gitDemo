package stepDefinitionz;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;

import io.cucumber.java.After;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import utils.testContextSetUp;
import org.openqa.selenium.TakesScreenshot;

public class Hooks {
	
	public testContextSetUp tcs;
	
	public Hooks(testContextSetUp tcs)
	{
		this.tcs=tcs;
	}
	
	@After("@StoreEvent")
	public void goHome()
	{
		tcs.act.sendKeys(Keys.HOME).build().perform();
	}
	
	@After("@GiftCard")
	public void goHome1()
	{
		tcs.act.sendKeys(Keys.HOME).build().perform();
	}
	
	@After("@Chatbot")
	public void quitDriver() throws Exception
	{
		Thread.sleep(3000);
		tcs.wdm.getDriver().quit();
		
	}
	
	@AfterStep
	public void addScreenShot(Scenario scenario) throws Exception
	{
		WebDriver driver=tcs.wdm.getDriver();
		if(scenario.isFailed())
		{
		File sourcePath=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		byte[] fileContent = FileUtils.readFileToByteArray(sourcePath);
		scenario.attach(fileContent, "image/png", "image");
		}
	}
	

}
