 package stepDefinitionz;

import java.io.File;
import java.io.FileInputStream;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjects.GiftCards;
import pageObjects.Home;
import pageObjects.PageObjectManager;
import pageObjects.Sanitizer;
//import resources2.ReusableMeths;
import utils.testContextSetUp;

public class HomeStepdefinition{
	

	public testContextSetUp tcs;
	Home hm;
	Sanitizer sr;
	
	public HomeStepdefinition(testContextSetUp tcs){			//dependency injection---object created for testContextSetUp
		this.tcs=tcs;
		this.hm=tcs.pom.home();
		this.sr= tcs.pom.sanitizer();
	}
	
	@Given("Initialize the browser with edge")
	public void init_the_browser_with_edge() throws Exception
	{
		Assert.assertTrue(hm.titleOfPage());	
	}
	
	@When("store event menu clicked")
	public void store_event_menu_clicked() throws Exception
	{
		hm.storeEventsClick();
	}
	
	@Given("^giftcards clicked in homepage$")
	public void giftcard_clicked_in_homepage() throws Exception
	{
		hm.giftCards();
	}
	
	@Given("hair category chosen")
	public void hair_category_chosen() throws Exception {
		hm.categoriesClick();
		hm.goToHairCategory();
		hm.hairCareClick();
	}
	
	@Then("Hand sanitizer searched and counted")
	public void hand_sanitizer_searched_and_counted() throws Exception {
		
		sr.goToSearchWidget();
		sr.suggesstionsClick();
		sr.countOfSanitizer();
	}
	
	@Given("cleansers clicked in skin tab")
	public void cleansers_clicked_in_skin_tab() throws Exception {
		hm.goToSkinCategory();
		hm.clickCleansers();
	}
}