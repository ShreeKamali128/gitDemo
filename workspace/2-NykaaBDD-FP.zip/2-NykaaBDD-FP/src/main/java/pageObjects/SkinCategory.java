package pageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import Resources.ReusableMethod;

public class SkinCategory extends AbstractComponent {

	public SkinCategory(WebDriver driver) {
		super(driver);
	}

	@FindBy(css = "#filters-strip span")
	public List<WebElement> listofFilters;

	@FindBy(xpath = "//span[text()='4 stars & above']/parent::div/following-sibling::div")
	WebElement customerRating;

	@FindBy(xpath = "//span[contains(text(),'30% and above')]")
	WebElement discount;

	@FindBy(xpath = "//div[@id='filters-listing']/div[1]/div[2]//span")
	public List<WebElement> listOffiltersApplied;

	@FindBy(css = ".cross")
	WebElement filterCross;

	public void customerRatingClick() throws Exception {
		rm.scrollWindow3();
		listofFilters.stream().filter(s -> s.getText().toLowerCase().contains("customer rating"))
				.forEach(ss -> ss.click());
		customerRating.click();
	}

	public void discountClick() throws Exception {
//		rm.sleepMethod();
		rm.scrollWindow1();
		listofFilters.stream().filter(s -> s.getText().toLowerCase().contains("discount")).forEach(ss -> ss.click());
//		rm.sleepMethod();
		rm.implicitWait(driver);

		discount.click();
	}

	public void displayFiltersApplied() throws Exception {
		rm.sleepMethod();
		System.out.println("FILTERS APPLIED:  ");
		final List<WebElement> appliedFilters = listOffiltersApplied;
		appliedFilters.stream().forEach(s -> System.out.print(s.getText() + " and" + "\n"));

	}

	@FindBy(xpath = "(//*[@class='css-jtn0l5']//a)[4]")
	public WebElement product4th;

	By heart = By.xpath("ancestor::div[2]//button[1]//*[name()='svg']");

	public WebElement HeartIcon() {
		return driver.findElement(heart);
	}

	@FindBy(css = ".container.landing-screen h2")
	public WebElement signInHeading;

	@FindBy(css = ".close-btn")
	WebElement signInClose;

	@FindBy(xpath = "//a[@title='logo']//*[name()='svg']")
	WebElement nykaaLogo;

	public void heartIconClicked() throws Exception {
		act.moveToElement(product4th).perform();
		rm.sleepMethod();
		rm.scrollWindow1();
		rm.moveToElementAction(act, product4th);
		product4th.findElement(heart).click();
		rm.implicitWait(driver);
	}

	public void closeSignIn() {
		signInClose.click();
		rm.implicitWait(driver);
		rm.moveToHomeAction(act);

		nykaaLogo.click();

	}

}
