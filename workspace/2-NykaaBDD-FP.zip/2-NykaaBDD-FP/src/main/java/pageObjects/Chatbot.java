package pageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import Resources.ReusableMethod;

public class Chatbot extends AbstractComponent {

	public Chatbot(WebDriver driver) {
		super(driver);
	}

	By frame = By.cssSelector("#verloop-iframe");
	public WebElement helpFrame() {
		return driver.findElement(frame);
	}

	@FindBy(css = "[data-state='start'] [class='verloop-button']")
	WebElement howWeMayHelp;

	@FindBy(xpath = "(//button[@class='btn js-quick-reply'])[4]")
	WebElement personalCare;

	@FindBy(css = ".message-body")
	public WebElement Response;

	@FindBy(css = "[class*='close']")
	WebElement close;

	@FindBy(xpath = "//*[@class='close']")
	WebElement closePop;

	@FindBy(xpath="//*[@class='close']")
	public List<WebElement> closePopUp;

	public void chatbotClicked() throws Exception {
		
		rm.moveToElement_ClickAction(act, howWeMayHelp);
		rm.sleepMethod();
		driver.switchTo().frame(helpFrame());
	}
	
	public boolean responseEnabled()
	{
		return Response.isEnabled();
	}

	public void helpclicked() {
		rm.implicitWait(driver);
		rm.moveToElement_ClickAction(act, personalCare);
	}

	public void getResponse_close() {
		System.out.println(Response.getText());
		close.click();
		rm.implicitWait(driver);
		rm.moveToHomeAction(act);
	}

}
