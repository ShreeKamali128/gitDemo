package pageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import Resources.ReusableMethod;

public class Sanitizer extends AbstractComponent{
	
	public Sanitizer(WebDriver driver)
	{
		super(driver);
	}	
	
	@FindBy(css=".css-19j7d8y input")
	WebElement searchInput;

	@FindBy(xpath="//div[@data-value='Hand Sanitizer']")
	WebElement handSanitizer;
	
	@FindBy(css=".suggestionQuery")
	public List<WebElement> suggestions;
		
	@FindBy(css="#title-listing .result-count")
	public WebElement searchCount;
	

	
	public void goToSearchWidget()
	{
		this.rm.explicitWait(this.w,searchInput);
		searchInput.clear();
		this.rm.sendInputsAction(act,searchInput,"Hand Sanitizer");
	}
	
	public void suggesstionsClick()
	{
		this.rm.implicitWait(driver);
		suggestions.stream().filter(s-> s.getText().contains("Hand Sanitizer")).forEach(s-> s.click());
	}
	
	public void countOfSanitizer()
	{
		System.out.println(searchCount.getText().split(" ")[1].toString());
	}
}
