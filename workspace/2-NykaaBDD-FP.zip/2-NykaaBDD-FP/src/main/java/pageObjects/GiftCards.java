package pageObjects;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import Resources.*;

public class GiftCards extends AbstractComponent{
	

	public GiftCards(WebDriver driver)
	{
		super(driver);
	}
	
	
	@FindBy(css="[class*='newsletter'] input")
	public WebElement mailInput;
	
	
	@FindBy(xpath="(//*[contains(@class,'send')]) [2]")
	public WebElement sendMail;
	
	@FindBy(css="#nykaaforCorporates span")
	public WebElement nykaforCorporates;
	
	@FindBy(xpath="//h2[text()='Nykaa for Corporates']")
	public WebElement textNykaaForCorporates;	
	
	@FindBy(css=".footer__newsletter")
	public WebElement footerContainer;

	@FindBy(css="[class='glyphicon glyphicon-ok-circle mm-icon'] span")
	public WebElement thanksForSubscribing;
	
	
	public void nykaaForCorporatesClick()
	{
		nykaforCorporates.click();
		this.rm.implicitWait(driver);
	}
	
	public boolean verifyNykaaForCorporates()
	{
		return this.textNykaaForCorporates.getText().toLowerCase().contains("nykaa for corporates");
		
	}
	
	public void goToFooterTitle()
	{
		this.rm.moveToElementAction(act, footerContainer);
	}
	
	public void inputMailClick(String str) throws Exception
	{
		mailInput.click();	
		mailInput.sendKeys(str);
	}
	
	public void sendMailClick()
	{
		sendMail.click();	
		
	}
	
	public boolean validateResponse() 
	{
		this.rm.explicitWait(this.w,sendMail);
		return this.driver.getPageSource().contains("Thanks for subscribing");
	}

}