package pageObjects;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import Resources.*;

public class StoreEvents extends AbstractComponent{
	
	public StoreEvents(WebDriver driver)
	{
		super(driver);
	}
	
	@FindBy(xpath="(//ol/li)[2]")
	public WebElement storesHeading;
	
	@FindBy(xpath="(//input[@id='nw-store-search'])[1]")    
	public WebElement searchCity;
	
	
	@FindBy(css=".nw-store-search-dropdown.nw_show")
	public WebElement searchCityDropdown;
	
	@FindBy(css="[onclick*=\"window._nykaa.redirectToStoreDetailPage('N16')\"] [class*='time']")
	public WebElement storetiming;
	
	
	
	@FindBy(css="[onclick*=\"window._nykaa.redirectToStoreDetailPage('N16')\"] [class*='address']")
	public WebElement storeAddress;
	
	
	
	public boolean verifyStoreTitle()
	{
		System.out.println("IN: "+ storesHeading.getText().toUpperCase().toString() );
		return storesHeading.getText().contains("store");
		
	}
	
	public void searchCity(String str) throws Exception {
		
		rm.implicitWait(driver);
		rm.moveToElement_ClickAction(act, searchCity);
		
		rm.scrollWindow3();
		searchCity.sendKeys(str);
		
		rm.explicitWait(w, searchCityDropdown);
		searchCityDropdown.click();
		
	}
	
	public void printExcel() throws Throwable
	{
		List<String[]> list=new ArrayList<String[]>();
		list.add(new String[] {storeAddress.getText()});
		list.add(new String[] {storetiming.getText()});
		rm.csvdata(list);
	}

}