package pageObjects;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import Resources.ReusableMethod;

public class Hair extends AbstractComponent{
	
	
	public static String topRatedProduct =null;
	public String proddInCart=null;
	public ArrayList<String> wins= null;

	
	
	public Hair(WebDriver driver)
	{
		super(driver);
//		PageFactory.initElements(driver, this);
	}

	@FindBy(css=".filters .sort-name")
	public WebElement sortByDropDown;
	
	@FindBy(css="[for*='customer'] [class*=indicator]")
	public WebElement customerTopRated;	
	
	@FindBy(css = "[class*='productWrapper']:nth-child(1) a")
	WebElement product;


	@FindBy(css = ".css-1gc4x7i")
	WebElement prodh1;


	@FindBy(xpath = "(//span[@class='btn-text'])[1]")
	WebElement addToBag;


	@FindBy(css = ".cart-count")
	WebElement cartCount;


	@FindBy(css = ".css-5s18zx.eoh7kvv0")
	WebElement viewBag;

	By prod = By.xpath("(//div[@class='product-name'])[last()]");
	public WebElement prodInCart() {
		return driver.findElement(prod);
	}

	@FindBy(css="[src*='Cart']")
	public WebElement cartiFrame;
	

	@FindBy(css = "[class='page-info'] span:nth-child(1)")
	WebElement shoppingBag;

	
	
	@FindBy(css =".payment-tbl-data")
	WebElement payBackDrop;


	@FindBy(css = "button[class*='coupon'] span")
	WebElement viewCoupons;


	@FindBy(css = "[class*='scrollable'] span:nth-child(1)")
	WebElement noCoupon;


	@FindBy(css = ".back-btn")
	WebElement backButton;


	@FindBy(css = ".payment-tbl-data div:nth-child(3) .value")
	WebElement subtotal;

	@FindBy(xpath = "//*[text()='Shipping Charge']/parent::div/following-sibling::div/i/*[name()='svg']")
	WebElement shippingCharge;
	
	@FindBy(xpath ="//span[text()='Payment Details']")
	WebElement paymentHeading;

	
	@FindBy(xpath="following-sibling::div/div")
	public WebElement shippingText;

	@FindBy(css = ".payment-tbl-data div:nth-child(4) ")
	WebElement grandTotal;
	
	
	

	
	public void sortByDropDowns() throws Exception
	{
		rm.implicitWait(driver);
		rm.explicitWait(this.w,sortByDropDown);
		rm.moveToElementAction(act,sortByDropDown);
		
		rm.sleepMethod();
		rm.moveToElement_ClickAction(act, sortByDropDown);
		
		rm.scrollWindow3();
		rm.explicitWait(this.w,customerTopRated);
		customerTopRated.click();
		
		rm.sleepMethod();
		rm.scrollWindow8();
	}
	
	public boolean verifyFilterApplied()
	{
		return sortByDropDown.getText().toLowerCase().contains("customer top rated");
	}
	
	public void productClick()
	{
		product.click();
	}
	
	public void switchTab() throws Exception
	{
		rm.switchChild();
		rm.sleepMethod();
	}
	
	public void addToBagClick() throws Exception
	{
		rm.sleepMethod();
		topRatedProduct = prodh1.getText().split(" ")[3];
	
		addToBag.click();
		rm.implicitWait(driver);
		Assert.assertTrue(cartCount.getText().contains("1"));
	}
	
	public void viewBagClick()
	{
		cartCount.click();
	}
	

	public void switchFrame()
	{
		rm.explicitWait(this.w,cartiFrame);
		driver.switchTo().frame(cartiFrame);
		System.out.println("switched...");
	}
	
	public void productVerify() throws Exception
	{
		rm.implicitWait(driver);
		rm.sleepMethod();
		proddInCart = prodInCart().getText().split(" ")[3];
		Assert.assertEquals(proddInCart,topRatedProduct);
	}
	
	public void coupons() throws Exception
	{
		
		rm.moveToElement_ClickAction(act, payBackDrop);

		rm.KeyAction(act, Keys.ARROW_DOWN);
		
		rm.sleepMethod();
		rm.moveToElementAction(act, viewCoupons);
		
		rm.sleepMethod();
		rm.moveToElement_ClickAction(act, paymentHeading);
		
		rm.KeyAction(act, Keys.ARROW_DOWN);
		
		rm.moveToElement_ClickAction(act, viewCoupons);
		
		rm.implicitWait(driver);
		System.out.println(noCoupon.getText());

		rm.sleepMethod();
		backButton.click();
	}
	

	
	
	public void chargeFees() throws InterruptedException
	{		
		rm.implicitWait(driver);
		rm.sleepMethod();
		
		rm.moveToElement_ClickAction(act, shippingCharge);
		
		rm.sleepMethod();
	
		rm.moveToElement_ClickAction(act, shippingCharge);
		
		rm.sleepMethod();
		//System.out.println("SubTotal:  " + subtotal.getText()+ "\n" + "ShippingCharge:  " + shippingText().getText() + "\n" + "GrandTotal:  " + grandTotal.getText());
	}
	
	
	public void closeFrame() throws InterruptedException
	{		
		driver.close();
		rm.switchParent();
		System.out.println("BACK IN: " + driver.getTitle().split(" - ")[0].toUpperCase().toString());
		
	}
	

}
