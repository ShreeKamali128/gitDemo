package pageObjects;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import Resources.*;

public class Home extends AbstractComponent {
	
	public Home(WebDriver driver)
	{
		super(driver);
	}	
	
	@FindBy(css="[class*='rightDiv ts-wrap-r'] li:nth-child(2) a")
	public WebElement storesEvents;
	
	
	@FindBy(css="[class*='rightDiv ts-wrap-r'] li:nth-child(3) a")
	public WebElement giftCards;
	
	
	@FindBy(xpath="//a[contains(text(),'categor')]")
	WebElement categories;
	
	
	@FindBy(xpath="(//div[@id='my-menu']//a[text()='hair'])[1]")      
	public WebElement hairCategory;	
	
	@FindBy(xpath="(//a[text()='hair care'])[1]")						
	WebElement hairCare;
	
	@FindBy(css=".css-19j7d8y input")
	WebElement searchInput;
	
	@FindBy(xpath="(//a[text()='skin'])[2]")
	public WebElement skinCategory;
	
	@FindBy(xpath="//a[text()='Cleansers']")
	WebElement cleansers;
	
	

	public void storeEventsClick() throws Exception
	{
		this.rm.explicitWait(this.w, storesEvents);
		this.storesEvents.click();
		this.switchWindow();
	}
	
	public void giftCards() throws Exception
	{
		this.rm.explicitWait(this.w, giftCards);
		this.giftCards.click();	
		this.switchWindow();
	}

	public void categoriesClick()
	{
		this.rm.explicitWait(this.w, categories);
		this.categories.click();
	}
	
	public void goToHairCategory()
	{
		this.rm.moveToElementAction(this.act,hairCategory);
	}
	
	public void hairCareClick() throws Exception
	{
		this.rm.explicitWait(this.w, hairCare);
		this.hairCare.click();
		this.switchWindow();
	}
	
	
	public void goToSkinCategory()
	{
		this.rm.moveToHomeAction(act);
		this.rm.explicitWait(this.w, skinCategory);
		this.rm.moveToElementAction(this.act,skinCategory);
	}
	
	public void clickCleansers() throws Exception
	{
		this.cleansers.click();
		this.switchWindow();
	}
	
	public boolean titleOfPage()
	{
		System.out.println( this.rm.getTitle().split(" ")[13].toString());
		System.out.println( this.rm.getTitle().split(": ")[0].toString());
		return this.rm.getTitle().matches(".*Nykaa.*");
				
	}

	public void switchWindow() throws Exception
	{
		this.rm.switchWindow();
	}

}