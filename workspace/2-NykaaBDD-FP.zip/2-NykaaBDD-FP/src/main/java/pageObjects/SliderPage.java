package pageObjects;

import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Resources.ReusableMethod;

public class SliderPage extends AbstractComponent {
	
	public SliderPage(WebDriver driver)
	{
		super(driver);
	}

	@FindBy(xpath="//div[@class='css-18u8mwg en1fyme0']/div[4]//img")											
	public WebElement slider;
	
	@FindBy(xpath="//ul[@class='css-1dlyq3o']/li[2]/button")										
	public WebElement sliderBtn;
	
	By img= By.xpath("//ul[@class='css-1dlyq3o']/li[2]/button/ancestor::div[1]/div/div/div[4]//img");		 //		ancestor::div[1]//div[4]//img					////img[contains(@src,'4925')]
	WebElement sliderImg;
	public WebElement sliderImg()
	{
		sliderImg=driver.findElement(img);
		return sliderImg;
	}
	
	
	By title= By.cssSelector("#title h1");
	WebElement h1Slider;
	public WebElement h1SliderTitle()
	{
		h1Slider=driver.findElement(title);
		return h1Slider;
	}


	public void sliderBtnClick() throws InterruptedException
	{
		rm.sleepMethod();
		rm.implicitWait(driver);
		sliderBtn.click();
	}
	
	public void sliderImgClick() throws InterruptedException
	{
		rm.sleepMethod();
		rm.implicitWait(driver);
		sliderImg().click();
	}
	
	public void printSliderName()
	{
		h1SliderTitle().getText().split(" \\(")[0].trim().toUpperCase().toString();
	}
	
}
