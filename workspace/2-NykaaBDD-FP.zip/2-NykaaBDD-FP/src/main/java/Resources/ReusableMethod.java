package Resources;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Set;
/*

import com.opencsv.CSVWriter;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
*/

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.opencsv.CSVWriter;

public class ReusableMethod {

	public JavascriptExecutor js = null;
	public Properties prop = null;
	public WebDriver driver;
	public String parent, child = null;

	public ReusableMethod(WebDriver driver) {
		this.driver = driver;     				 // life for driver to use funcs in the class is given here or else null exception thrown

	}

	public Properties propInit(Properties prop) throws Exception {
		prop = new Properties();
		File f = new File(System.getProperty("user.dir")+"\\src\\main\\java\\Resources\\Parameters.properties");
		FileInputStream fis = new FileInputStream(f);
		prop.load(fis);

		return prop;
	}

	public WebDriver implicitWait(WebDriver driver) {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		return driver;
	}
	
	public void explicitWait(WebDriverWait wait,WebElement waitElem)
	{
//		w.until(ExpectedConditions.visibilityOfElementLocated(waitElem));	//webelement is of By type argument
		wait.until((d)-> waitElem.isDisplayed());								//webelement is of WebElement type itself
	}
	
	public void sleepMethod() throws InterruptedException
	{
		Thread.sleep(3000);
	}
	
	public String getTitle() 
	{
		return driver.getTitle();
	}
	
	public void moveToElementAction(Actions act,WebElement moveToElem)
	{
		act.moveToElement(moveToElem).perform();
	}
	
	public void moveToElement_ClickAction(Actions act,WebElement elemClick)
	{
		act.moveToElement(elemClick).click().build().perform();
	}
	
	public void moveToHomeAction(Actions act)
	{
		act.sendKeys(Keys.HOME).build().perform();
	}
	
	public void KeyAction(Actions act, Keys key)
	{
		act.sendKeys(key).build().perform();
	}
	
	public void sendInputsAction(Actions act,WebElement inputElem, String str)
	{
		act.sendKeys(inputElem,str).build().perform();
	}
	
	

	public void scrollTop() throws Exception {
		js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,0)");
		Thread.sleep(4000);
		//return js;
	}

	public void scrollWindow1() throws Exception {
		js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,100)");
		Thread.sleep(4000);
		//return js;
	}

	public void scrollWindow3() throws Exception {
		js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,300)");
		Thread.sleep(4000);
		//return js;
	}

	public void scrollWindow8() throws Exception {
		js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,800)");
		Thread.sleep(4000);
		//return js;
	}

	By frame = By.cssSelector("[class*='iframeStyle']");

	public WebDriver iFrameSwitch(WebDriver driver) throws Exception {

		String url = driver.findElement(frame).getDomAttribute("src");
		driver.switchTo().newWindow(WindowType.TAB);
		driver.get(url);
		Thread.sleep(5000);
		return driver;
	}

//	public WebDriver switchTab(WebDriver driver) throws InterruptedException
//	{
//		public ArrayList<String> wins= null;
//		 wins = new ArrayList<String>(driver.getWindowHandles());
//		driver.switchTo().window(wins.get(1));
//		
//		return driver;
//	}
	
	public void switchWindow() throws Exception {

		winHandles(driver);
		driver.switchTo().window(parent);
		driver.close();
		driver.switchTo().window(child);
		
	}

	public WebDriver winHandles(WebDriver driver) throws Exception {

		Set<String> windows = driver.getWindowHandles();
		Iterator<String> itr = windows.iterator();
		parent = itr.next();
		Thread.sleep(5000);
		child = itr.next();
		driver.switchTo().window(child);

		return driver;
	}

	public WebDriver switchChild() throws InterruptedException { // child switch; parent close

		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs.get(1));
		System.out.println("switeched");
		return driver;
	}
	
	public WebDriver switchParent() throws InterruptedException { // child switch; parent close

		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());

		driver.switchTo().window(tabs.get(0));
		return driver;
	}

	public void csvdata(List<String[]> list2) throws Exception, Throwable {

		File f = new File("./src\\main\\java\\resources2\\StoreDetails.csv");
		FileWriter fw = new FileWriter(f);
		CSVWriter csvWriter = new CSVWriter(fw);

		List<String[]> list = list2;

		for (String[] i : list)
			csvWriter.writeNext(i);

		csvWriter.close();

		System.out.println("Data added to csv fie...");
		System.out.println("\n");
	}

	@AfterClass
	public void close(WebDriver driver) throws Exception {
		Thread.sleep(2000);
		driver.quit();
	}

	

}
