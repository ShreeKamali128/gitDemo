import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
//import org.openqa.selenium.interactions.Actions;
//import org.openqa.selenium.*;

public class Actions {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		System.setProperty("webdriver.edge.driver", "C:/Users/SH20204415/Eclipse/edgedriver/msedgedriver.exe");
//		WebDriver driver = new EdgeDriver();
//		driver.get("https://www.amazon.in/");
	//Actions a = new Actions(driver);
		
		System.out.println("j" + "a" + "v " + "a");
	
	}

}
