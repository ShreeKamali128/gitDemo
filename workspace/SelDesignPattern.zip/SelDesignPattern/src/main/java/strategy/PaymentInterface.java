package strategy;

import java.util.Map;

public interface PaymentInterface {
	
	void enterPaymetnInformation(Map<String,String> paymentDetails);

}
