package strategy;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CompCreditCard implements PaymentInterface{


	@FindBy(css="li.sbct")
	private List<WebElement> suggestions;
	
	@FindBy(name="q")
	private WebElement searchBox;
	
	
	
	public void click(int index)
	{
		this.suggestions.get(index-1).click();
	}
	
	@Override
	public void enterPaymetnInformation(Map<String, String> paymentDetails) {

		this.searchBox.sendKeys(paymentDetails.get("cc"));
	}

}
