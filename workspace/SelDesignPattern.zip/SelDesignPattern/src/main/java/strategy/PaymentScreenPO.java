package strategy;

import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;


public class PaymentScreenPO {

	private WebDriver driver;
	private CompUserInfo ui;
	private CompOrder or;
	private PaymentInterface pi;
	
	
	
	public PaymentScreenPO(final WebDriver driver)
	{
		this.driver=driver;
		this.ui = PageFactory.initElements(driver, CompUserInfo.class);
		this.or= PageFactory.initElements(driver, CompOrder.class);
		
	}
	
	public void goTo()
	{
		this.driver.get("https://vins-udemy.s3");
	}
	
	public CompUserInfo getUserInfo()
	{ 
		return ui;
	}

	public CompOrder getOrder()
	{
		return or;
	}
	
	public void  setPaymentInterface(PaymentInterface paymentInterface)
	{
		this.pi=paymentInterface;
		PageFactory.initElements(driver, this.pi);
	}
	
	public void pay(Map<String, String> paymentDetails)
	{
		this.pi.enterPaymetnInformation(paymentDetails);
	}
	
}
