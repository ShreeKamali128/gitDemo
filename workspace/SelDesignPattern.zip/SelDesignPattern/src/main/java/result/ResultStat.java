package result;
import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import common.AbstractComponent;

public class ResultStat extends AbstractComponent{

	@FindBy(id="resultStats")
	private WebElement stat;
	
	
	public ResultStat(final WebDriver driver)
	{
	super(driver);	
	}
	
	public String getStat()
	{
		return this.stat.getText();
	}
	
	
	@Override
	public boolean isDisplayed() {
		return this.wait.until(d->this.stat.isDisplayed());
		 
	}
	
	
	//FACTORY CONCEPT
		@Override
		public void launchsite() {
			
			//xxxxxxxxxxxxxx
		}

		@Override
		public void enterKeyword() {
			
			//ssssssssssssssssss
		}
	
}
