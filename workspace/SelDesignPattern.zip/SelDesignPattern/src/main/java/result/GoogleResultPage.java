package result;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;


import common.Searchsuggestion;
import common.Searchwidget;

public class GoogleResultPage {
	
	
	private Searchwidget searchwidget;
	private Searchsuggestion searchsuggestion;
	private Navigationbar navigationbar;
	private ResultStat resultstat;
	
	public GoogleResultPage(final WebDriver driver)
	{
		
		//using driver create an instance of the search widget class and give it to me
		this.searchwidget=PageFactory.initElements(driver, Searchwidget.class);
		this.searchsuggestion=PageFactory.initElements(driver, Searchsuggestion.class);
		this.navigationbar=PageFactory.initElements(driver, Navigationbar.class);
		this.resultstat=PageFactory.initElements(driver,ResultStat .class);
	}
	
	
	
	public Searchwidget getSearchWidget()
	{return searchwidget;}
	
	public Searchsuggestion getSearchSuggestion()
	{return searchsuggestion;}
	
	public Navigationbar getNavigationBar()
	{return navigationbar;}
	
	public ResultStat getResultStat()
	{return resultstat;}
	

}
