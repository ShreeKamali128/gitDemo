package result;
import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import common.AbstractComponent;

public class Navigationbar extends AbstractComponent{

	@FindBy(id="hdtb")
	private WebElement bar;
	
	@FindBy(linkText="Images")
	private WebElement images;
	
	@FindBy(linkText="News")
	private WebElement news;
	
	
	public Navigationbar(final WebDriver driver)
	{
	super(driver);	
	}
	
	public void gotoimages()
	{
		this.images.click();
	}
	
	public void gotoNews()
	{
		this.news.click();
	}
	
	
	@Override
	public boolean isDisplayed() {
		return this.wait.until(d->this.bar.isDisplayed());
		 
	}
	
	
	//FACTORY CONCEPT
		@Override
		public void launchsite() {
			
			//xxxxxxxxxxxxxx
		}

		@Override
		public void enterKeyword() {
			
			//ssssssssssssssssss
		}
}
