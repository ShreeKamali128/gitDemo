package main;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import common.Searchsuggestion;
import common.Searchwidget;

public class GoogleMainPage {
	
	private WebDriver driver;
	private Searchwidget searchwidget;
	private Searchsuggestion searchsuggestion;
	
	public GoogleMainPage(final WebDriver driver)
	{
		this.driver=driver;
		//using driver create an instance of the search widget class and give it to me
		this.searchwidget=new Searchwidget(driver);//PageFactory.initElements(driver, Searchwidget.class);
		this.searchsuggestion=PageFactory.initElements(driver, Searchsuggestion.class);
	}
	
	public void goTo()
	{
		this.driver.get("https://www.google.com");
	}
	
	public Searchwidget getSearchWidget()
	{return searchwidget;}
	
	public Searchsuggestion getSearchSuggestion()
	{return searchsuggestion;}
	

}
