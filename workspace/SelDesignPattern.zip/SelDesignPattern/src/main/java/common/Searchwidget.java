package common;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.util.concurrent.Uninterruptibles;

public class Searchwidget extends AbstractComponent {

	
	@FindBy(name="q")
	private WebElement searchBox;
	
	public Searchwidget(final WebDriver driver)
	{
		super(driver);
	}
	
	public void enter(String keyword)
	{
		this.searchBox.clear();
		for(char ch:keyword.toCharArray()) {
			Uninterruptibles.sleepUninterruptibly(Duration.ofMillis(2));
			this.searchBox.sendKeys(ch+"");
		}
		
	}
	
	@Override
	public boolean isDisplayed() {
		this.driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		return this.wait.until(d-> this.searchBox.isDisplayed());
	}
	
	
	
	//FACTORY CONCEPT
		@Override
		public void launchsite() {
			
			//xxxxxxxxxxxxxx
		}

		@Override
		public void enterKeyword() {
			
			//ssssssssssssssssss
		}
	

}
