package factoryPattern;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public abstract class AbstractGooglePage {
	
	protected WebDriver driver;
	public WebDriverWait wait;
	
	public AbstractGooglePage(final WebDriver driver)
	{
		this.driver=driver;
		this.wait=new WebDriverWait(driver,Duration.ofSeconds(60) );
		
	}
	
	public abstract void launchSite();
	public abstract void search(String keyword);
	public abstract int getResultCount();

}
