package factoryPattern;

import org.openqa.selenium.WebDriver;

public class GoogleFrenchComponent extends AbstractGooglePage {

	public GoogleFrenchComponent(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void launchSite() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void search(String keyword) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int getResultCount() {
		// TODO Auto-generated method stub
		return 0;
	}

}
