package factoryPattern;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

import org.openqa.selenium.WebDriver;



public class GoogleFactory {
//
//	private static final Function<WebDriver,AbstractGooglePage> fr = d -> new GoogleFrenchComponent(d);
//	
//	public static AbstractGooglePage get(String scenario, WebDriver driver)
//	{
//		if(scenario.equalsIgnoreCase("gcard"))
//				return (new GoogleFrenchComponent(driver)); 
//	//	return ;
//		
//	}

	
	
    private static final Function<WebDriver,AbstractGooglePage> fr = d -> new GoogleFrenchComponent(d);
 	
	private static final  Map<String,Function<WebDriver, AbstractGooglePage>> map=new HashMap<>();
	
	static {
		map.put("FR", fr);
			}
	
	public static AbstractGooglePage get(String scenario, WebDriver driver)
	{
		return map.get(scenario).apply(driver);
	}
	
	
}
