package DriverInit;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import com.google.common.util.concurrent.Uninterruptibles;

public class BaseTest {
	
	protected WebDriver driver;
	

	@BeforeTest
	public void setUpDriver()
	{
		System.setProperty("webdriver.chrome.driver", "C:/Users/SH20204415/Eclipse/chromeDriver/chromedriver.exe");
		driver = new ChromeDriver();
	}
	
	@AfterTest
	public void stopDriver()
	{
		Uninterruptibles.sleepUninterruptibly(Duration.ofSeconds(3));
		this.driver.quit();
	}
	

}
