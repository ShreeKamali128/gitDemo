package FactoryPattern;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import DriverInit.BaseTest;
import factoryPattern.GoogleFactory;
import factoryPattern.AbstractGooglePage;

public class FactoryPatternTest extends BaseTest{
	
	private AbstractGooglePage googlepage;
	
	@Test(dataProvider="factoryGet")
	public void actionTest(String language, String keyword)
	{
		  //this.ac=GoogleFactory.get(language, driver);
		  this.googlepage=GoogleFactory.get(language, this.driver);
		  this.googlepage.launchSite();
		  this.googlepage.search(keyword);
		  this.googlepage.getResultCount();
	}
	
	
	@DataProvider
	public Object[][] factoryGet()
	{
		return new Object[][]
				{
			//Factory
			{"EN","selenium"},
			{"FR","webdriver"},
			{"ARB","Jenkins"}
				};
	}
	/*
	 * 
	 * Based on one of the languages as user input, the googleFactory choose and give the objects accordingly and
	 * so that we can implement the other steps in the test with the abstract class object as interface object for al 3 language classes
	 * 
	 */
	

}
