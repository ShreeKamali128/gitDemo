package googleTest;

import org.junit.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import DriverInit.BaseTest;
import common.AbstractComponent;
import factoryPattern.GoogleFactory;
import main.GoogleMainPage;
import result.GoogleResultPage;


public class GoogleTest extends BaseTest{
	
	private GoogleMainPage gmp;
	private GoogleResultPage grp;
	private AbstractComponent ac;
	
	//here we need to create factory class and hide the instantiation of below 2 PageObjects from test
    //remove beforeTest and can include one line of factory line in Test
	@BeforeTest
	public void setUpPages()
	{
		this.gmp=new GoogleMainPage(driver);
		this.grp=new GoogleResultPage(driver);
	}
	
	
	@Test(dataProvider="dataToGet")
	public void googleWorkFlow(String keyword, int index)
	
	{
		//String keyword="selenium webdriver";
		//int index=1;
		SoftAssert ass= new SoftAssert();
		this.driver.manage().deleteAllCookies();
		
		gmp.goTo();
		
		ass.assertTrue(gmp.getSearchWidget().isDisplayed());
		gmp.getSearchWidget().enter(keyword);
		
		Assert.assertTrue(gmp.getSearchSuggestion().isDisplayed());
		gmp.getSearchSuggestion().click(index);
		
		Assert.assertTrue(grp.getNavigationBar().isDisplayed());
		grp.getSearchWidget().enter(keyword);
		
		Assert.assertTrue(grp.getSearchSuggestion().isDisplayed());
		grp.getSearchSuggestion().click(index);
	
		grp.getNavigationBar().gotoimages();
		System.out.println(grp.getResultStat().getStat());
	}
	
	
	@DataProvider
	public Object[][] dataToGet()
	{
		return new Object[][]
		{
			{"selenium",3},
		};
	}
	
	
}
