package StrategyPattern;

import java.util.Map;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.collections.Maps;

import DriverInit.BaseTest;
import strategy.CompCreditCard;
import strategy.CompNetBanking;
import strategy.PaymentInterface;
import strategy.PaymentScreenPO;


public class StrategyPatternTest extends BaseTest{
	
	private PaymentScreenPO ps;
	
	@BeforeTest
	public void setPaymentScreen()
	{
		this.ps= new PaymentScreenPO(this.driver);
	}
	
	@Test(dataProvider="getData")
	public void paymentTest(PaymentInterface paymentInterface, Map<String, String> paymentDetails)
	{
		  this.ps.goTo();
		  this.ps.getUserInfo().enterDetails("shree", "ram", "abc@gmail.com");
		  this.ps.setPaymentInterface(paymentInterface);
		  this.ps.pay(paymentDetails);
		  this.ps.getOrder().placeOrder();
	}
	
	
	@DataProvider
	public Object[][] getData()
	{
		
		Map<String, String> cc = Maps.newHashMap();
		cc.put("cc", "09876");
		cc.put("year", "2021");
		cc.put("cvv", "123");
		
		Map<String, String> nb = Maps.newHashMap();
		nb.put("bank", "SBI");
		nb.put("account", "9008987");
		nb.put("pin", "1234");
		
		return new Object[][]
				{
					{new CompCreditCard(), cc},
					{new CompNetBanking(), nb}
				};
		
	}
	
	

}
