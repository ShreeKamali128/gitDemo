package utils;

import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

import pageObjects2.PageObjectManager;
import resources2.ReusableMeths;

public class testContextSetUp {
	
	public WebDriver driver;
	public Properties prop;
	
	public WebDriverManager wdm;
	public PageObjectManager pom;
	
	public ReusableMeths rm;
	public Actions act;
	
	public testContextSetUp() throws Exception
	{
	 wdm=new WebDriverManager();
	 driver=wdm.getDriver();
	 
	 pom=new PageObjectManager(driver);
	 rm=new ReusableMeths(driver);
	 act=new Actions(driver);
	}

}
