package utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import resources2.ReusableMeths;

public class WebDriverManager {
	
	public static WebDriver driver=null;
	public Properties prop;
	public ReusableMeths rm;
	
	
	public WebDriver getDriver() throws Exception
	{     
       
		if(driver==null)
		{
		System.setProperty("webdriver.edge.driver", System.getProperty("user.dir")+"\\src\\test\\java\\resources\\edgedriverN");
		driver = new EdgeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		rm = new ReusableMeths(driver);
		prop=rm.propInit(prop);
		String url=prop.getProperty("url");	
		driver.get(url);
		}
		
		return driver;
	}

}
