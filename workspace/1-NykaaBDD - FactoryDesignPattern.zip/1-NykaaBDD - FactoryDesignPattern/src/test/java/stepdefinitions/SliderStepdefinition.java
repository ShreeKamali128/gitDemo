package stepdefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import pageObjects2.Home;
import pageObjects2.SliderPage;
import utils.testContextSetUp;

public class SliderStepdefinition {
	
	public testContextSetUp tcs;
	SliderPage sp;
	
	public SliderStepdefinition(testContextSetUp tcs){			//dependency injection---object created for testContextSetUp
		this.tcs=tcs;
		this.sp=tcs.pom.sliderPage();
	}

	
	@Then("^click slider image second$")
	public void slider_lists() throws Exception
	{	
		sp.sliderBtnClick();
		sp.sliderImgClick();
		System.out.println("SLIDER HEADING:  "+sp.h1SliderTitle().getText().split(" \\(")[0].trim().toUpperCase().toString());
		System.out.println("\n");
	}

}
