package stepdefinitions;

import java.io.File;
import java.io.FileInputStream;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjects2.GiftCards;
//import pageObjects2.Hair;
import pageObjects2.Home;

import pageObjects2.PageObjectManager;
//import pageObjects2.SkinCategory;
//import pageObjects2.TopRatedProduct;
import pageObjects2.StoreEvents;
//import resources2.ReusableMeths;
import utils.testContextSetUp;

public class StoreEventsStepdefinition{
	

	public testContextSetUp tcs;
	StoreEvents se;
	
	public StoreEventsStepdefinition(testContextSetUp tcs){			//dependency injection---object created for testContextSetUp
		this.tcs=tcs;
		this.se=tcs.pom.storeEvents();
	}


@Then("search the city {string}")
public void search_the_city(String string) throws Exception

  {
	Assert.assertTrue(se.storesHeading.getText().contains("store"));
	System.out.println("IN: "+se.storesHeading.getText().toUpperCase().toString() );
	se.searchCity(string);
 
  }

@Then("print in excel")
public void print_in_excel() throws Throwable

  {	
	se.printExcel();
	System.out.println(se.storeAddress.getText() + "\n" + se.storetiming.getText());
	//tcs.act.sendKeys(Keys.HOME).build().perform();
   
 } 

}