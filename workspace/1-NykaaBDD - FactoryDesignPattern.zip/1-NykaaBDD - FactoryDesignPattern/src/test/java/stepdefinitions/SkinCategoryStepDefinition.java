package stepdefinitions;

import org.junit.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjects2.Hair;
import pageObjects2.SkinCategory;
import utils.testContextSetUp;

public class SkinCategoryStepDefinition {
	
	public testContextSetUp tcs;
	SkinCategory sk;
	
	public SkinCategoryStepDefinition(testContextSetUp tcs){			//dependency injection---object created for testContextSetUp
		this.tcs=tcs;
		this.sk=tcs.pom.skin();
	}
	
	
	@When("customer rating and discount filters applied")
	public void customer_rating_and_discount_filters_applied() throws Exception {
		
		sk.customerRatingClick();
		sk.discountClick();
		sk.displayFiltersApplied();
	}
	
	
	@Then("product added as favourite {string}")
	public void product_added_as_favourite(String string) throws Exception {
		
		sk.heartIconClicked();
		Assert.assertTrue(sk.signInHeading.getText().toLowerCase().contains(string));
		sk.closeSignIn();
	}



}
