package stepdefinitions;

import org.junit.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import pageObjects2.Chatbot;
import pageObjects2.SkinCategory;
import utils.testContextSetUp;

public class ChatbotStepDefinition {

	public testContextSetUp tcs;
	Chatbot cb;

	public ChatbotStepDefinition(testContextSetUp tcs) { // dependency injection---object created for testContextSetUp
		this.tcs = tcs;
		this.cb = tcs.pom.chatbot();
	}

	@Given("chatbot clicked")
	public void chatbot_clicked() throws Exception {
		cb.chatbotClicked();
	}

	@Then("select a query and validatet its response")
	public void select_a_query_and_validatet_its_response() {
		cb.helpclicked();
		Assert.assertTrue(cb.Response.isEnabled());
		cb.getResponse_close();
	}

}
