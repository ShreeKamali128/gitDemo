package pageObjects2;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import resources2.*;

public class Home {
	
	public WebDriver driver;

	public Home hm;
	public ReusableMeths rm;
	public Actions act;
	public WebDriverWait w;
	
	public Home(WebDriver driver)
	{
		this.driver=driver;                						//life for driver is only given here or else null exception thrown
		PageFactory.initElements(driver, this);
		rm=new ReusableMeths(driver);
		act=new Actions(driver);
		w=rm.explicitWait(driver);
	}	
	
	@FindBy(css="[class*='rightDiv ts-wrap-r'] li:nth-child(2) a")
	public WebElement storesEvents;
	
	
	@FindBy(css="[class*='rightDiv ts-wrap-r'] li:nth-child(3) a")
	public WebElement giftCards;
	
	
	@FindBy(xpath="//a[contains(text(),'categor')]")
	WebElement categories;
	
	
	By hair= By.xpath("(//div[@id='my-menu']//a[text()='hair'])[1]");         //[id='my-menu'] a[href*='/nykaa-hair']
	public WebElement hairCategory()
	{
		return driver.findElement(hair);
	}
	
	
	@FindBy(xpath="(//a[text()='hair care'])[1]")						//[data-nykaa-tracking-parameters='biotique'] a
	WebElement hairCare;
	
	
	public void storeEventsClick() throws Exception
	{
		sleepMethod();
		storesEvents.click();
	}
	
	public void giftCards() throws Exception
	{
		sleepMethod();
		giftCards.click();	
		
	}
	

	public void categoriesClick() throws Exception
	{
		sleepMethod();
		categories.click();
	}
	
	public void hairCareClick() throws Exception
	{
		moveToWebElement(hairCategory());
		sleepMethod();
		hairCare.click();
	}

	
	public By find=By.cssSelector(".css-19j7d8y input");
	public WebElement searchInput()
	{
		return driver.findElement(find);
	}
	

	@FindBy(xpath="//div[@data-value='Hand Sanitizer']")
	WebElement handSanitizer;
	
	
	@FindBy(css="h1")
	WebElement headingSanitizer;
	public WebElement headingSanitizer()
	{
		return headingSanitizer;
	}
	
	
	@FindBy(css=".result-count")
	WebElement searchedCount;
	
		
	public void handSanitizer() throws Exception
	{
		rm.implicitWait(driver);
		explicitWait(find);
		act.sendKeys(searchInput(),"Hand Sanitizer").build().perform();
		sleepMethod();
		handSanitizer.click();
		sleepMethod();

	}
	
	
	

	By skin=By.xpath("(//a[text()='skin'])[2]");
	public WebElement skinCategory()
	{
		return driver.findElement(skin);	
	}
	
	@FindBy(xpath="//a[text()='Cleansers']")
	WebElement cleansers;
	
	
	public void clickCleansers() throws Exception
	{
		act.sendKeys(Keys.HOME).build().perform();
		explicitWait(skin);
		
		moveToWebElement(skinCategory());
		cleansers.click();
		
		rm.switchWindow();		
		System.out.println("IN: "+driver.getTitle().split(":")[0].toUpperCase().toString());	
	}
	

	
	
	public String getTitle() 
	{
	   return driver.getTitle();
	}
	
	public void moveToWebElement(WebElement moveToElem)
	{
		act.moveToElement(moveToElem).perform();
	}
	
	public void explicitWait(By waitElem)
	{
		w.until(ExpectedConditions.visibilityOfElementLocated(waitElem));
	}
	
	public void sleepMethod() throws InterruptedException
	{
		Thread.sleep(3000);
	}
}