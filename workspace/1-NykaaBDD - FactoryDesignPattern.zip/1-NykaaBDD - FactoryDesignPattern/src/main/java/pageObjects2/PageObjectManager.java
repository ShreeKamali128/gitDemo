package pageObjects2;

import org.openqa.selenium.WebDriver;

public class PageObjectManager {
	
	public Home home;
	public GiftCards giftCards;
	public SliderPage sp;
	public StoreEvents se;
	public Hair hair;
	public SkinCategory skin;
	public  Chatbot chatbot;
	public WebDriver driver;
	
	public PageObjectManager(WebDriver driver)
	{
		this.driver=driver;
	}
	
	public Home home()
	{
		home=new Home(driver);
		return home;
	}
	
	public GiftCards giftCards()
	{
		giftCards = new GiftCards(driver);
		return giftCards;
	}
	
	
	public SliderPage sliderPage()
	{
		sp = new SliderPage(driver);
		return sp;
	}
	
	public StoreEvents storeEvents()
	{
		se = new StoreEvents(driver);
		return se;
	}
	
	public Hair hair()
	{
		hair=new Hair(driver);
		return hair;
	}
	
	public SkinCategory skin()
	{
		skin=new SkinCategory(driver);
		return skin;
	}


	public Chatbot chatbot()
	{
		chatbot =  new Chatbot(driver);
		return chatbot;
	}
}
