package pageObjects2;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import resources2.*;

public class StoreEvents {
	
	public WebDriver driver;
	public Properties prop;
	public ReusableMeths rm;
	public Actions act;
	
	
	public StoreEvents(WebDriver driver)
	{
		this.driver=driver;                						//life for driver is only given here or else null exception thrown
		PageFactory.initElements(driver, this);
		rm=new ReusableMeths(driver);
		act=new Actions(driver);
	}
	
	
	@FindBy(xpath="(//ol/li)[2]")
	public WebElement storesHeading;
	
	
	// [placeholder='Search City']
	@FindBy(xpath="(//input[@id='nw-store-search'])[1]")     //(//div[@class='nw-search-location']//input)[2]
	public WebElement searchCity;
	
	
	@FindBy(css=".nw-store-search-dropdown.nw_show")
	public WebElement searchCityDropdown;
	
	
	
	@FindBy(css="[onclick*=\"window._nykaa.redirectToStoreDetailPage('N16')\"] [class*='time']")
	public WebElement storetiming;
	
	
	
	@FindBy(css="[onclick*=\"window._nykaa.redirectToStoreDetailPage('N16')\"] [class*='address']")
	public WebElement storeAddress;
	
	
	
	
	public void searchCity(String str) throws Exception {
		
		rm.implicitWait(driver);
		act.click(searchCity).build().perform();
		rm.scrollWindow3(rm.js);
		
		searchCity.sendKeys(str);
		Thread.sleep(3000);
		searchCityDropdown.click();
		Thread.sleep(3000);
	}
	
	public void printExcel() throws Throwable
	{
		List<String[]> list=new ArrayList<String[]>();
		list.add(new String[] {storeAddress.getText()});
		list.add(new String[] {storetiming.getText()});
		rm.csvdata(list);
	}
	
	
	

}