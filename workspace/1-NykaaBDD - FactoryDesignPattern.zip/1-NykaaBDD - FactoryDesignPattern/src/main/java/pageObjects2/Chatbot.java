package pageObjects2;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import resources2.ReusableMeths;

public class Chatbot {

	public WebDriver driver;

	public Home hm;
	public ReusableMeths rm;
	public Actions act;
	public WebDriverWait w;

	public Chatbot(WebDriver driver) {
		this.driver = driver; // life for driver is only given here or else null exception thrown
		PageFactory.initElements(driver, this);
		rm = new ReusableMeths(driver);
		act = new Actions(driver);
		w = rm.explicitWait(driver);
	}

	By frame = By.cssSelector("#verloop-iframe");

	public WebElement helpFrame() {
		return driver.findElement(frame);
	}

	@FindBy(css = "[data-state='start'] [class='verloop-button']")
	WebElement howWeMayHelp;

	@FindBy(xpath = "(//button[@class='btn js-quick-reply'])[4]")
	WebElement personalCare;

	@FindBy(css = ".message-body")
	public WebElement Response;

	@FindBy(css = "[class*='close']")
	WebElement close;

	@FindBy(xpath = "//*[@class='close']")
	WebElement closePop;

	By popup = By.xpath("//*[@class='close']");
	List<WebElement> closePopUp;

	public List<WebElement> closePopUp() {
		closePopUp = driver.findElements(popup);
		return closePopUp;
	}

	public void chatbotClicked() throws Exception {
		act.moveToElement(howWeMayHelp).click().perform();
		Thread.sleep(20000);
		driver.switchTo().frame(helpFrame());
	}

	public void helpclicked() {
		rm.implicitWait(driver);
		act.moveToElement(personalCare).click().perform();
	}

	public void getResponse_close() {
		System.out.println(Response.getText());
		close.click();
		rm.implicitWait(driver);
		act.sendKeys(Keys.HOME).build().perform();
	}

}
