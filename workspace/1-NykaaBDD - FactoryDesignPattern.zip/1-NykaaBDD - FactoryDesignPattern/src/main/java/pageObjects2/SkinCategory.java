package pageObjects2;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import resources2.ReusableMeths;

public class SkinCategory {

	public WebDriver driver;
	public JavascriptExecutor js = null;
	
	public SkinCategory sk;
	public ReusableMeths rm;
	public Actions act;
	public WebDriverWait w;
	
	public SkinCategory(WebDriver driver) {
		
		this.driver=driver;                						//life for driver is only given here or else null exception thrown
		PageFactory.initElements(driver, this);
		rm=new ReusableMeths(driver);
		act=new Actions(driver);
		w=rm.explicitWait(driver);
	}

	
	By disc=By.cssSelector("#filters-strip span");
	List<WebElement> listofFilters;
	public List<WebElement> listofFilters()
	{
		listofFilters=driver.findElements(disc);
		return listofFilters;
	}	
	
	@FindBy(xpath="//span[text()='4 stars & above']/parent::div/following-sibling::div")
	WebElement customerRating;

	@FindBy(xpath="//span[contains(text(),'30% and above')]")
	WebElement discount;
	
	By applied= By.xpath("//div[@id='filters-listing']/div[1]/div[2]//span");
	List<WebElement> listOffiltersApplied;
	public List<WebElement> listOffiltersApplied()
	{
		listOffiltersApplied=driver.findElements(applied);
		return listOffiltersApplied;
	}
	

	@FindBy(css=".cross")
	WebElement filterCross;
	
	List<WebElement> filters;
	public void customerRatingClick() throws Exception
	{
		rm.scrollWindow3(js);
		filters= listofFilters();
		filters.stream().filter(s->s.getText().toLowerCase().contains("customer rating")).forEach(ss->ss.click());
		
		customerRating.click();
	}
	
	public void discountClick() throws Exception
	{
		Thread.sleep(2000);
		rm.scrollWindow1(js);
		filters.stream().filter(s->s.getText().toLowerCase().contains("discount")).forEach(ss->ss.click());
		Thread.sleep(2000);
		rm.implicitWait(driver);
		
		discount.click();
	}
	
	public void displayFiltersApplied() throws Exception
	{
		Thread.sleep(2000);
		System.out.println("FILTERS APPLIED:  ");
		final List<WebElement> appliedFilters=listOffiltersApplied();
		appliedFilters.stream().forEach(s->System.out.print(s.getText()+ " and"+"\n"));
		System.out.println("\n");
	}
	
	
	
	By prod4= By.xpath("(//*[@class='css-jtn0l5']//a)[4]");	
	public WebElement product4th()
	{
		return driver.findElement(prod4);	
	}
	

	By heart= By.xpath("ancestor::div[2]//button[1]//*[name()='svg']");
	public WebElement  HeartIcon()
	{
		return product4th().findElement(heart);
	}
	
	
	@FindBy(css=".container.landing-screen h2")
	public WebElement signInHeading;
	
	@FindBy(css=".close-btn")
	WebElement signInClose;
	
	@FindBy(xpath="//a[@title='logo']//*[name()='svg']")
	WebElement nykaaLogo;
	
	public void heartIconClicked() throws Exception
	{
		act.moveToElement(product4th()).perform();
		Thread.sleep(3000);
		rm.scrollWindow1(js);
		act.moveToElement(product4th()).perform();       //for hovering
		
		product4th().findElement(heart).click();
		rm.implicitWait(driver);
	}
	
	public void closeSignIn()
	{
		signInClose.click();
		rm.implicitWait(driver);
		act.sendKeys(Keys.HOME).build().perform();
		
		nykaaLogo.click();
		
	}
	

}
