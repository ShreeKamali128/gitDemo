package pageObjects2;

import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import resources2.ReusableMeths;

public class SliderPage {
	
	public WebDriver driver;
	
	public ReusableMeths rm;
	public Actions act;
	
	public SliderPage(WebDriver driver)
	{
		this.driver=driver;                						//life for driver is only given here or else null exception thrown
		PageFactory.initElements(driver, this);
		rm=new ReusableMeths(driver);
		act=new Actions(driver);
	}
	
	

	@FindBy(xpath="//div[@class='css-18u8mwg en1fyme0']/div[4]//img")											
	public WebElement slider;
	
	
		
	@FindBy(xpath="//ul[@class='css-1dlyq3o']/li[2]/button")										
	public WebElement sliderBtn;
	
	
	
	By img= By.xpath("//ul[@class='css-1dlyq3o']/li[2]/button/ancestor::div[1]/div/div/div[4]//img");		 //		ancestor::div[1]//div[4]//img					////img[contains(@src,'4925')]
	WebElement sliderImg;
	public WebElement sliderImg()
	{
		sliderImg=driver.findElement(img);
		return sliderImg;
	}
	
	
	By title= By.cssSelector("#title h1");
	WebElement h1Slider;
	public WebElement h1SliderTitle()
	{
		h1Slider=driver.findElement(title);
		return h1Slider;
	}
	
	
	public String getTitle() 
	{
		return driver.getTitle();
	}
	

	public void sliderBtnClick() throws InterruptedException
	{
		Thread.sleep(3000);
		rm.implicitWait(driver);
		sliderBtn.click();
	}
	
	public void sliderImgClick() throws InterruptedException
	{
		Thread.sleep(3000);
		rm.implicitWait(driver);
		sliderImg().click();
	}
	
}
