package pageObjects2;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import resources2.*;

public class GiftCards {
	
	public WebDriver driver;
	public Properties prop;
	public ReusableMeths rm;
	public Actions act;
	
	public GiftCards hm;
	
	
	public GiftCards(WebDriver driver)
	{
		this.driver=driver;                						//life for driver is only given here or else null exception thrown
		PageFactory.initElements(driver, this);
		rm=new ReusableMeths(driver);
		act=new Actions(driver);
	}
	
	
	@FindBy(css="[class*='rightDiv ts-wrap-r'] li:nth-child(3) a")
	public WebElement giftCards;
	
	
	@FindBy(css="[class*='newsletter'] input")
	public WebElement mailInput;
	
	
	@FindBy(xpath="(//*[contains(@class,'send')]) [2]")
	public WebElement sendMail;
	
	
	
	@FindBy(css="#nykaaforCorporates span")
	public WebElement nykaforCorporates;
	

	By footer= By.cssSelector(".footer__newsletter");
	public WebElement footerTitle()
	{
		return driver.findElement(footer);
		
	}
	

	@FindBy(css="[class='glyphicon glyphicon-ok-circle mm-icon'] span")
	public WebElement thanksForSubscribing;
	
	
	public String getTitle() 
	{
		return driver.getTitle();
	}

	

	public void sendMail(String str) throws Exception
	{
		prop=rm.propInit(prop);
		act.moveToElement(footerTitle()).perform();
		
		Thread.sleep(3000);
		mailInput.click();
		mailInput.sendKeys(str);
		sendMail.click();
		
	}
	
	
	
	

}