package pageObjects2;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import resources2.ReusableMeths;

public class Hair {
	
	public WebDriver driver;
	public JavascriptExecutor js = null;
	public static String topRatedProduct =null;
	public String proddInCart=null;
	public ArrayList<String> wins= null;

	public Hair hr;
	public ReusableMeths rm;
	public Actions act;
	public WebDriverWait w;
	
	public Hair(WebDriver driver)
	{
		this.driver=driver;                						//life for driver is only given here or else null exception thrown
		PageFactory.initElements(driver, this);
		rm=new ReusableMeths(driver);
		act=new Actions(driver);
		w=rm.explicitWait(driver);
	}
	
	

	By sort=By.cssSelector(".filters .sort-name");
	public WebElement sortByDropDown()
	{
		return driver.findElement(sort);
	}
	
	By cust= By.cssSelector("[for*='customer'] [class*=indicator]");
	public WebElement customeTopRated()
	{
		return driver.findElement(cust);
	}
	
	
	
	public void sortByDropDowns() throws Exception
	{
		rm.implicitWait(driver);
		explicitWait(sort);
		moveToElement(sortByDropDown());
		sleepMethod();
		act.click(sortByDropDown()).build().perform();
		
		rm.scrollWindow3(js);
		explicitWait(cust);
		customeTopRated().click();
		
		sleepMethod();
		rm.scrollWindow8(js);
	}
	
	
	
	@FindBy(css = "[class*='productWrapper']:nth-child(1) a")
	WebElement product;


	@FindBy(css = ".css-1gc4x7i")
	WebElement prodh1;


	@FindBy(xpath = "(//span[@class='btn-text'])[1]")
	WebElement addToBag;


	@FindBy(css = ".cart-count")
	WebElement cartCount;


	@FindBy(css = ".css-5s18zx.eoh7kvv0")
	WebElement viewBag;

	By prod = By.xpath("(//div[@class='product-name'])[2]");
	public WebElement prodInCart() {
		return driver.findElement(prod);
	}

	By cframe= By.cssSelector("[src*='Cart']");
	public WebElement cartiFrame() {
		return driver.findElement(cframe);
	}

	@FindBy(css = "[class='page-info'] span:nth-child(1)")
	WebElement shoppingBag;

	
	
	@FindBy(css =".payment-tbl-data")
	WebElement payBackDrop;


	@FindBy(css = "button[class*='coupon'] span")
	WebElement viewCoupons;


	@FindBy(css = "[class*='scrollable'] span:nth-child(1)")
	WebElement noCoupon;


	@FindBy(css = ".back-btn")
	WebElement backButton;


	@FindBy(css = ".payment-tbl-data div:nth-child(3) .value")
	WebElement subtotal;

	@FindBy(xpath = "//*[text()='Shipping Charge']/parent::div/following-sibling::div/i/*[name()='svg']")
	WebElement shippingCharge;
	
	@FindBy(xpath ="//span[text()='Payment Details']")
	WebElement paymentHeading;

	
	By text=By.xpath("following-sibling::div/div");
	public WebElement shippingText() {
		return shippingCharge.findElement(text);
	}

	@FindBy(css = ".payment-tbl-data div:nth-child(4) ")
	WebElement grandTotal;
	
	
	public void productClick()
	{
		product.click();
	}
	
	public void switchTab() throws Exception
	{
		rm.switchChild();
		sleepMethod();
	}
	
	public void addToBagClick() throws Exception
	{
		Thread.sleep(2000);
		topRatedProduct = prodh1.getText().split(" ")[3];
	
		addToBag.click();
		rm.implicitWait(driver);
		Assert.assertTrue(cartCount.getText().contains("1"));
	}
	
	public void viewBagClick()
	{
		cartCount.click();
	}
	

	public void switchFrame()
	{
		explicitWait(cframe);
		driver.switchTo().frame(cartiFrame());
		System.out.println("switched...");
	}
	
	public void productVerify() throws Exception
	{
		rm.implicitWait(driver);
		sleepMethod();
		proddInCart = prodInCart().getText().split(" ")[3];
		Assert.assertEquals(proddInCart,topRatedProduct);
	}
	
	public void coupons() throws Exception
	{
		clickElement(payBackDrop);
		sendKey(Keys.ARROW_DOWN);;
		sleepMethod();
		moveToElement(viewCoupons);
		sleepMethod();
		moveClickElement(paymentHeading);
		sendKey(Keys.ARROW_DOWN);
		clickElement(viewCoupons);
	
		rm.implicitWait(driver);
		System.out.println(noCoupon.getText());

		sleepMethod();
		backButton.click();
	}
	
	public void chargeFees() throws InterruptedException
	{
		
		rm.implicitWait(driver);
		sleepMethod();
		moveClickElement(shippingCharge);
		sleepMethod();
		String shpChg= shippingText().getText();
		System.out.println(shpChg);
		moveClickElement(shippingCharge);
		
		Thread.sleep(2000);
		System.out.println("SubTotal:  " + subtotal.getText()+ "\n" + "ShippingCharge:  "
				+ shpChg + "\n" + "GrandTotal:  " + grandTotal.getText());
	}
	
	public void closeFrame() throws InterruptedException
	{		
		driver.close();
		rm.switchParent();
		System.out.println("BACK IN: " + driver.getTitle().split(" - ")[0].toUpperCase().toString());
		System.out.println("\n");
		
	}
	
	
	
	
	
	
	public String getTitle() 
	{
	   return driver.getTitle();
	}
	
	public void moveToElement(WebElement moveToElem)
	{
		act.moveToElement(moveToElem).perform();
	}
	
	public void clickElement(WebElement clickElem)
	{
		act.click(clickElem).build().perform();
		
	}
	
	public void moveClickElement(WebElement moveClickElem)
	{
		
		act.moveToElement(moveClickElem).click().perform();
	}
	
	public void sendKey(Keys keyElem)
	{
		act.sendKeys(keyElem).build().perform();
	}
	
	public void explicitWait(By waitElem)
	{
		w.until(ExpectedConditions.visibilityOfElementLocated(waitElem));
	}
	
	public void sleepMethod() throws InterruptedException
	{
		Thread.sleep(3000);
	}
}
