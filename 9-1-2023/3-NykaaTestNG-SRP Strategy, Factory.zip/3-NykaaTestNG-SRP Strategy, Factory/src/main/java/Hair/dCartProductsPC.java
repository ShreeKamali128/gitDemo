package Hair;

import java.util.ArrayList;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import _common.AbstractComponent;

public class dCartProductsPC extends AbstractComponent {

	
	public String proddInCart=null;
	public ArrayList<String> wins= null;
	
	
	@FindBy(xpath="(//span[@data-test-id='product-name'])")
	public WebElement prod;
//	public WebElement prodInCart() {
//		return driver.findElement(prod);
//	}
	
	
	@FindBy(xpath="//*[@id='app']//*[text()='Bag']")
	public WebElement Bag;

	@FindBy(css="[src*='Cart']")
	public WebElement cartiFrame;
	

	@FindBy(css = "[class='page-info'] span:nth-child(1)")
	WebElement shoppingBag;

	
	@FindBy(css =".payment-tbl-data")
	WebElement payBackDrop;
	
	
	@FindBy(css = "button[class*='coupon'] span")  //    [data-test-id='coupon_card']
	WebElement viewCoupons;


	@FindBy(css = "[class*='scrollable'] span:nth-child(1)")
	WebElement noCoupon;


	@FindBy(css = ".back-btn")
	WebElement backButton;


	@FindBy(css = ".payment-tbl-data div:nth-child(3) .value")
	WebElement subtotal;

	@FindBy(xpath = "//*[text()='Shipping']/parent::div/following-sibling::div//span")		//following-sibling::div/i/*[name()='svg']
	WebElement shippingCharge;
	
	@FindBy(xpath ="//span[text()='Payment Details']")
	WebElement paymentHeading;

	
	@FindBy(xpath="following-sibling::div/div")
	public WebElement shippingText;

	@FindBy(css = ".payment-tbl-data div:nth-child(4) ")
	WebElement grandTotal;

	
	public dCartProductsPC(WebDriver driver) {
		super(driver);
		
	}
	
	
	
	public void switchFrame()
	{
		explicitWait(cartiFrame);
		switchFrame(cartiFrame);
		System.out.println("switched...");
	}
	
	public String cartProduct() throws Exception
	{
		implicitWait(driver);
		sleepMethod();
		proddInCart = prod.getText().split(" ")[3];
		//Assert.assertEquals(proddInCart,topRatedProduct);
		return proddInCart;
		
	}
	
	public void coupons() throws Exception{
		
	
		sleepMethod();
		moveToElementAction(act, viewCoupons);
		
		sleepMethod();
		moveToElement_ClickAction(act, paymentHeading);
		
		KeyAction(act, Keys.ARROW_DOWN);
		
		moveToElement_ClickAction(act, viewCoupons);
		
		implicitWait(driver);
		System.out.println(noCoupon.getText());

		sleepMethod();
		backButton.click();
	}
	

	
	
	public void chargeFees() throws InterruptedException
	{		
		implicitWait(driver);
		sleepMethod();
		
		moveToElement_ClickAction(act, shippingCharge);
		
		sleepMethod();
	
		moveToElement_ClickAction(act, shippingCharge);
		
		sleepMethod();
		//System.out.println("SubTotal:  " + subtotal.getText()+ "\n" + "ShippingCharge:  " + shippingText().getText() + "\n" + "GrandTotal:  " + grandTotal.getText());
	}
	
	
	public void closeFrame() throws InterruptedException
	{		
		driver.close();
		switchParent();
		System.out.println("BACK IN: " + driver.getTitle().split(" - ")[0].toUpperCase().toString());
		
	}


	@Override
	public boolean isDisplayed() {
		
		return this.w.until((d) -> this.Bag.isDisplayed());
	}

}
