package Hair;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import _common.AbstractComponent;

public class bProductListingPC extends AbstractComponent{



	
	@FindBy(css = "[class*='productWrapper']:nth-child(1) a")
	WebElement product;
	
	
	public bProductListingPC(WebDriver driver) {
		super(driver);
	}

	
	public void productClick() throws InterruptedException
	{
		product.click();
		switchChild();
		sleepMethod();
	}
	
	
	@Override
	public boolean isDisplayed() {
		return this.w.until((d)-> product.isDisplayed());
	}
	
	

}
