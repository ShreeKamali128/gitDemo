package _common;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.TreeMap;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.opencsv.CSVWriter;

public abstract class AbstractComponent {

	protected WebDriverWait w;
	protected Actions act;
	protected Properties prop;
	public WebDriver driver;
	public WebElement sectionElement;

	public JavascriptExecutor js = null;
	public String parent, child = null;

	public AbstractComponent() {
	}

	public AbstractComponent(final WebDriver driver) {
		this.w = new WebDriverWait(driver, Duration.ofSeconds(60));
		this.act = new Actions(driver);
		this.driver = driver;
	}

	public abstract boolean isDisplayed();

	public String getTitle() {
		return driver.getTitle();
	}

	public Properties propInit(Properties prop) throws IOException {
		prop = new Properties();
		File f = new File(System.getProperty("user.dir") + "\\src\\main\\java\\Resources\\Parameters.properties");
		FileInputStream fis = new FileInputStream(f);
		prop.load(fis);

		return prop;
	}

	public WebDriver implicitWait(WebDriver driver) {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		return driver;
	}

	public void windowMaximize(WebDriver driver) {
		driver.manage().window().maximize();

	}

	public void pageLoadWait(WebDriver driver) {
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(12));
	}

	public void switchFrame(WebElement frame) {
		driver.switchTo().frame(frame);
	}
//	public WebDriverWait explicitWait(WebDriver driver) {
//		WebDriverWait w = new WebDriverWait(driver, Duration.ofSeconds(20));
//		return w;
//	}

	public void explicitWait(WebElement waitElem) {
//		w.until(ExpectedConditions.visibilityOfElementLocated(waitElem));	//webelement is of By type argument
		w.until((d) -> waitElem.isDisplayed()); // webelement is of WebElement type itself
	}

	public void sleepMethod() throws InterruptedException {
		Thread.sleep(3000);
	}

	public void moveToElementAction(Actions act, WebElement moveToElem) {
		act.moveToElement(moveToElem).perform();
	}

	public void moveToHomeAction(Actions act) {
		act.sendKeys(Keys.HOME).build().perform();
	}

	public void EnterAction(Actions act) {
		act.sendKeys(Keys.ENTER).build().perform();
	}
	
	public void moveToElement_EnterAction(Actions act, WebElement elemEnter) {
		act.moveToElement(elemEnter).sendKeys(Keys.ENTER).build().perform();
	}
	
	public void moveToElement_ClickAction(Actions act, WebElement elemClick) {
		act.moveToElement(elemClick).click().build().perform();
	}

	public void sendInputsAction(Actions act, WebElement inputElem, String str) {
		act.sendKeys(inputElem, str).build().perform();
	}

	public void KeyAction(Actions act, Keys key) {
		act.sendKeys(key).build().perform();
	}

	public JavascriptExecutor scrollTop() throws Exception {
		js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,0)");
		Thread.sleep(4000);
		return js;
	}

	public JavascriptExecutor scrollWindow1() throws Exception {
		js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,100)");
		Thread.sleep(4000);
		return js;
	}

	public JavascriptExecutor scrollWindow3() throws Exception {
		js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,300)");
		Thread.sleep(4000);
		return js;
	}

	public JavascriptExecutor scrollWindow8() throws Exception {
		js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,800)");
		Thread.sleep(4000);
		return js;
	}

	By frame = By.cssSelector("[class*='iframeStyle']");

	public WebDriver iFrameSwitch(WebDriver driver) throws Exception {

		String url = driver.findElement(frame).getDomAttribute("src");
		driver.switchTo().newWindow(WindowType.TAB);
		driver.get(url);
		Thread.sleep(5000);
		return driver;
	}

//	public WebDriver switchTab(WebDriver driver) throws InterruptedException
//	{
//		public ArrayList<String> wins= null;
//		 wins = new ArrayList<String>(driver.getWindowHandles());
//		driver.switchTo().window(wins.get(1));
//		
//		return driver;
//	}

	public void switchWindow() throws Exception {

		winHandles(driver);
		driver.switchTo().window(parent);
		driver.close();
		driver.switchTo().window(child);

	}

	public WebDriver winHandles(WebDriver driver) throws Exception {

		Set<String> windows = driver.getWindowHandles();
		Iterator<String> itr = windows.iterator();
		parent = itr.next();
		Thread.sleep(5000);
		child = itr.next();
		driver.switchTo().window(child);

		return driver;
	}

	public WebDriver switchChild() throws InterruptedException { // child switch; parent close

		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs.get(1));
		//System.out.println("switched");
		return driver;
	}

	public WebDriver switchParent() throws InterruptedException { // child switch; parent close

		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());

		driver.switchTo().window(tabs.get(0));
		return driver;
	}

	/*public void csvdata(List<String[]> list2) throws Exception {

		File f = new File(System.getProperty("user.dir") + "\\src\\main\\java\\Resources\\StoreDetails.csv");
		FileWriter fw = new FileWriter(f);
		CSVWriter csvWriter = new CSVWriter(fw);

		List<String[]> list = list2;

		for (String[] i : list)
			csvWriter.writeNext(i);

		csvWriter.close();

		System.out.println("Data added to csv fie...");
		System.out.println("\n");

	}
	
	public void writeDataList(List<String> string) throws Exception {

		System.out.println("in writeData Excel");
		File f = new File(System.getProperty("user.dir") + "\\src\\main\\java\\Resources\\StoreDetailsW.xlsx");
		FileOutputStream fos = new FileOutputStream(f);
		
		XSSFWorkbook wb= new XSSFWorkbook();
		CreationHelper ch= wb.getCreationHelper();
		XSSFSheet sh = wb.createSheet("Locations");
		
		for(int i=0;i<string.size();i++) {
			Row r1= sh.createRow(i);
			r1.createCell(0).setCellValue(ch.createRichTextString(string.get(i).toString()));			
		}
		
		wb.write(fos);
		fos.close();
		System.out.println("Written the data...");
	}*/

	public void writeDataW(Map<String, Object[]> storeData) throws Exception {

		System.out.println("===========================");
		System.out.println("Writing into Excel");
		File f = new File(System.getProperty("user.dir") + "\\src\\main\\java\\Resources\\StoreDetailsW.xlsx");
		FileOutputStream fos = new FileOutputStream(f);
		
		XSSFWorkbook wb= new XSSFWorkbook();
		CreationHelper ch= wb.getCreationHelper();
		XSSFSheet sh = wb.createSheet("Locations");
		XSSFRow row; 
		
		Set<String> keyid= storeData.keySet();
		int rowid=0;
		
		for(String key: keyid)
		{
			row = sh.createRow(rowid++);
			Object[] objArr = storeData.get(key);
			
			int cellid=0;
			for(Object obj: objArr)
			{
				Cell cell = row.createCell(cellid++);
				System.out.println(obj);
				cell.setCellValue((String)obj.toString());
			}
		}
		
		wb.write(fos);
		fos.close();
		System.out.println("written data into excel");	
		System.out.println("===============================");
	}
	

	public List<String> readDataW() throws Exception {
		System.out.println("=================================");
		System.out.println("reading data from excel");
		File f = new File(System.getProperty("user.dir") + "\\src\\main\\java\\Resources\\StoreDetailsW.xlsx");
		FileInputStream fis = new FileInputStream(f);
				
		List<String> al = new ArrayList<String>();
		
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		int sheets = wb.getNumberOfSheets();
		for (int i = 0; i < sheets; i++) {
			if (wb.getSheetName(i).equalsIgnoreCase("Locations")) {
				XSSFSheet sh = wb.getSheetAt(i);
				
				int rowCount=sh.getLastRowNum()-sh.getFirstRowNum();
				
				for(int j=0; j<rowCount; j++)
				{
					int cellCount=sh.getRow(1).getLastCellNum();
					for(int k=0;k<cellCount;k++)
					{
						String cv = sh.getRow(j).getCell(k).getStringCellValue();
						al.add(cv);
					}
				}
				
//				Iterator<Row> rows = sh.iterator();
//				while(rows.hasNext())
//				{
//					Row r = rows.next();
//					String cv=r.getCell(i).getStringCellValue();
//					al.add(cv);
//					
//				}
			}
		}
		return al;
	}

/*	public List<String> readData(String str) throws Exception {
		System.out.println("in readData Excel");
		FileInputStream f = new FileInputStream(
				System.getProperty("user.dir") + "\\src\\main\\java\\Resources\\StoreDetailsW.xlsx");
		XSSFWorkbook wb = new XSSFWorkbook(f);

		List<String> al = new ArrayList<String>();
		int sheets = wb.getNumberOfSheets();
		for (int i = 0; i < sheets; i++) {
			if (wb.getSheetName(i).equalsIgnoreCase("Locations")) {
				XSSFSheet sh = wb.getSheetAt(i);
				Iterator<Row> rows = sh.iterator();

				Row fr = rows.next();
				Iterator<Cell> ce = fr.cellIterator();
				int k = 0, col = 0;
				while (ce.hasNext()) {
					Cell value = ce.next();
					if (value.getStringCellValue().equalsIgnoreCase("Testcases")) {
						col = k;
					}
					k++;
				}
				while (rows.hasNext()) {
					Row r = rows.next();
					if (r.getCell(col).getStringCellValue().equalsIgnoreCase("Purchase")) {
						Iterator<Cell> cv = r.cellIterator();
						while (cv.hasNext()) {
							System.out.println(cv.next().getStringCellValue());

							Cell c = cv.next();
							if (c.getCellType() == CellType.STRING)
								al.add(c.getStringCellValue());
							else {
								String s = NumberToTextConverter.toText(c.getNumericCellValue());
								al.add(s);
							}

						}
					}
				}
			}
		}
		return al;
	}
*/
}
