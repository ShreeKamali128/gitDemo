package Home;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import _common.AbstractComponent;

public class cSubHeaderBar extends AbstractComponent {
	
	//public WebDriver driver;
	
	
	@FindBy(css="#category_navigation")
	public WebElement subHeaderMenu;
	
	@FindBy(xpath="(//div[@id='my-menu']//a[text()='hair'])[1]")
	public WebElement hairCategory;
	
	
	@FindBy(xpath="(//a[text()='hair care'])[1]")
	public WebElement hairCare;
	

	@FindBy(xpath="(//a[text()='skin'])[2]")
	public WebElement skinCategory;
	
	
	@FindBy(xpath="//a[text()='Cleansers']")
	WebElement cleansers;
	
	
	public cSubHeaderBar(WebDriver driver) {
		super(driver);
	}

	
	public void goToHairCategory()
	{
		moveToElementAction(this.act,hairCategory);
	}
	
	public void goToHairCare() throws Exception
	{
		explicitWait(hairCare);
		hairCare.click();
		switchWindow();
	}
	
	public void goToSkinCategory()
	{
		moveToHomeAction(act);
		explicitWait( skinCategory);
		moveToElementAction(this.act,skinCategory);
	}
	
	public void goToCleansers() throws Exception
	{
		cleansers.click();
		switchWindow();
	}
	
	
	
	@Override
	public boolean isDisplayed() {
		 return this.w.until(d-> this.subHeaderMenu.isDisplayed());
	}

}
