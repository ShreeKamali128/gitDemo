package Home;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import _common.AbstractComponent;

public class bHeaderBar extends AbstractComponent {
	
	//public WebDriver driver;
	
	@FindBy(xpath="//div[@id='category_navigation']/parent::div/parent::div/child::div[2]")
	public WebElement HeaderMenu;
	
	@FindBy(xpath="//a[contains(text(),'categor')]")
	WebElement categories;
	

	@FindBy(css=".css-19j7d8y input")
	WebElement searchInput;
	
	@FindBy(css=".suggestionQuery")
	public List<WebElement> suggestions;
	
	@FindBy(css="#title-listing .result-count")
	public WebElement searchCount;
	

	@FindBy(css = ".cart-count")
	WebElement cartCount;
	
	@FindBy(xpath="//*[contains(@id,'Logo')]//*[name()='svg']")
	WebElement logo;
	
	@FindBy(xpath = "//a[@title='logo']//*[name()='svg']")
	WebElement nykaaLogo;

	
	public bHeaderBar(WebDriver driver) {
		super(driver);
	}
	
	public void goToCategories()
	{
		explicitWait(categories);
		categories.click();
	}
	
	public void goToSearchWidget()
	{
		explicitWait(searchInput);
		searchInput.clear();
		sendInputsAction(act,searchInput,"Hand Sanitizer");
	}
	
	public void suggesstionsClick()
	{
		implicitWait(driver);
		suggestions.stream().filter(s-> s.getText().contains("Hand Sanitizer")).forEach(s-> s.click());
	}
	
	public void countOfSanitizer()
	{
		System.out.println(searchCount.getText().split(" ")[1].toString());
	}
	
	public void viewBagClick()
	{
		Assert.assertTrue(cartCount.getText().contains("1"));
		cartCount.click();
	}
	
	public void goToLogo()
	{
		nykaaLogo.click();
		this.implicitWait(driver);
	}
	
	public void goToLogoo()
	{
		this.logo.click();
		this.implicitWait(driver);
	}
	
	public boolean verifyUrl()
	{
		return driver.getCurrentUrl().contains("root=logo");
	}
	
	@Override
	public boolean isDisplayed() {
		return this.w.until(d->this.HeaderMenu.isDisplayed());
	}

}
