package Home;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import _common.AbstractComponent;

public class aOfferTopBar extends AbstractComponent {

	// public WebDriver driver;

	@FindBy(xpath = "//div[@id='offer-banner']//div[contains(@class,'rightDiv')]")
	public WebElement offerBar;

	@FindBy(css = "[class*='rightDiv ts-wrap-r'] li:nth-child(2) a")
	public WebElement storesEvents;

	@FindBy(css = "[class*='rightDiv ts-wrap-r'] li:nth-child(3) a")
	public WebElement giftCards;
	
//	static By section_Element = By.xpath("//div[contains(@class,'top-menu')]");
//	By giftcard = By.xpath("//*[text()='Gift Card']");

	public aOfferTopBar(WebDriver driver) {   //, By section_Element1) {
		super(driver);
		//super(driver,section_Element);
	}

	public void goToStoresEvents() throws Exception {
		explicitWait(storesEvents);
		storesEvents.click();
		switchWindow();
	}

	public void goToGiftCards() throws Exception {
		explicitWait(giftCards);
		giftCards.click();
		switchWindow();
	}

//	public void getAttributeOf()
//	{
//		System.out.println(findElement(giftcard));			//method calling //method implementation is in Abstract Component
//	}
	
	@Override
	public boolean isDisplayed() {
		return this.w.until(d -> this.offerBar.isDisplayed());
	}

}
