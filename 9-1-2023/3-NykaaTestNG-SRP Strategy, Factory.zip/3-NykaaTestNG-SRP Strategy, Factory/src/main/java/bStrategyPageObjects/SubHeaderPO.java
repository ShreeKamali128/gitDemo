package bStrategyPageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import cStrategyPageComponents.HairPC;
import cStrategyPageComponents.SkinPC;
import Hair._HairPOManager;
import Home.aOfferTopBar;
import Home.bHeaderBar;
import Home.cSubHeaderBar;
import dStrategyInterface.AbstractComponent;
import dStrategyInterface.CategoryMainMenu;
import dStrategyInterface.StrategyFactor;

public class SubHeaderPO extends AbstractComponent {
	CategoryMainMenu category;
	
	@FindBy(css = "#category_navigation")
	public WebElement subHeaderMenu;

	

	public SubHeaderPO(final WebDriver driver, By section_Element2) {
		super(driver,section_Element2);
	}

	//it knows now where to reroute; it knows now which class object i want now
	public void setCategoryStrategy(String strategyType) {
		StrategyFactor strategyFactor = new StrategyFactor(driver);
		category = strategyFactor.createStrategy(strategyType);

		System.out.println("category is: "+ category);
		this.category=category;
		System.out.println("category is: "+ category);
	}

	public void mainMenuSelection(String categoryName) {
		category.mainMenuSelection(categoryName); // calling the correct method of hair or skin or so on..
	}

	@Override
	public boolean isDisplayed() {
		return this.w.until(d -> this.subHeaderMenu.isDisplayed());
	}

}
