package Skin;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import _common.AbstractComponent;

public class aFiltersPC extends AbstractComponent {

	@FindBy(css = "#filters-strip span")
	public List<WebElement> listofFilters;

	@FindBy(xpath = "//span[text()='4 stars & above']/parent::div/following-sibling::div")
	WebElement customerRating;

	@FindBy(xpath = "//span[contains(text(),'30% and above')]")
	WebElement discount;

	@FindBy(xpath = "//div[@id='filters-listing']/div[1]/div[2]//span")
	public List<WebElement> listOffiltersApplied;

	@FindBy(css = ".cross")
	WebElement filterCross;
	
	@FindBy(xpath = "//*[@id='title']/h1[contains(text(),'Cleansers')]")
	public WebElement SkinTitle;

	public aFiltersPC(WebDriver driver) {
		super(driver);
	}

	public void customerRatingClick() throws Exception {
		scrollWindow3();
		listofFilters.stream().filter(s -> s.getText().toLowerCase().contains("customer rating"))
				.forEach(ss -> ss.click());
		customerRating.click();
	}

	public void discountClick() throws Exception {
		scrollWindow1();
		listofFilters.stream().filter(s -> s.getText().toLowerCase().contains("discount")).forEach(ss -> ss.click());
		implicitWait(driver);

		discount.click();
	}
	
	public boolean verifyFilterApplied() throws InterruptedException {
		sleepMethod();
		//final List<WebElement> appliedFilters = listOffiltersApplied;
		//appliedFilters.stream().forEach(s -> System.out.print(s.getText() + " and" + "\n"));
		return  listOffiltersApplied.get(0).getText().toLowerCase().contains("%") && 
				listOffiltersApplied.get(1).getText().toLowerCase().contains("stars");
	}

	

	@Override
	public boolean isDisplayed() {
		return this.w.until((d) -> SkinTitle.isDisplayed());
	}

	

}
