package Skin;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import _common.AbstractComponent;

public class bProductListingPC extends AbstractComponent{
	
	
	public bProductListingPC(WebDriver driver) {
		super(driver);
	}

	@FindBy(xpath = "//div[@id='filters-listing']/div[1]/div[2]//span")
	public List<WebElement> listOffiltersApplied;
	
	@FindBy(xpath = "(//*[@class='css-jtn0l5']//a)[4]")
	public WebElement product4th;

	By heart = By.xpath("ancestor::div[2]//button[1]//*[name()='svg']");
	public WebElement HeartIcon() {
		return driver.findElement(heart);
	}

	@FindBy(css = ".container.landing-screen h2")
	public WebElement signInHeading;

	@FindBy(css = ".close-btn")
	WebElement signInClose;

	@FindBy(xpath = "//a[@title='logo']//*[name()='svg']")
	WebElement nykaaLogo;
	

	public void heartIconClicked() throws Exception {
		act.moveToElement(product4th).perform();
		sleepMethod();
		scrollWindow1();
		moveToElementAction(act, product4th);
		product4th.findElement(heart).click();
		implicitWait(driver);
	}

	public void closeSignIn() {
		signInClose.click();
		implicitWait(driver);
		moveToHomeAction(act);

		

	}
	
	public boolean verify(String str)
	{
		return signInHeading.getText().toLowerCase().contains(str);
	}
	
	
	
	
	@Override
	public boolean isDisplayed() {
		return this.w.until((d)-> listOffiltersApplied.get(0).isDisplayed());
	}
	
	

}
