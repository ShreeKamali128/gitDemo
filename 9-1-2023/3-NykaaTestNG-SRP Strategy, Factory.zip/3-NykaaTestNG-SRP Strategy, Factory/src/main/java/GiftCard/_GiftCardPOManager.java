package GiftCard;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class _GiftCardPOManager {

	
	private aTagsPComponent gc;
	private bMailPComponent mail;
	
	
	public _GiftCardPOManager(final WebDriver driver) {
		//this.driver = driver;	//important line; life of driver assigned to local variable this.driver and then passsed to PCs //also it is not used outside so no need of assignment
		this.gc = PageFactory.initElements(driver, aTagsPComponent.class);
		this.mail = PageFactory.initElements(driver, bMailPComponent.class);

	}
	
	
	public aTagsPComponent getgiftCardContainerPC() {
		return gc;		//new aGiftCards(driver,section_Element);
	}

	public bMailPComponent getMailPC() {
		return mail;
	}
}
