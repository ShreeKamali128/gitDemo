package GiftCard;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import _common.AbstractComponent;

public class bMailPComponent extends AbstractComponent {

	@FindBy(css = ".footer__newsletter")
	public WebElement footerContainer;

	@FindBy(css = "[class*='newsletter'] input")
	public WebElement mailInput;

	@FindBy(xpath = "(//*[contains(@class,'send')]) [2]")
	public WebElement sendMail;

	@FindBy(css = "[class='glyphicon glyphicon-ok-circle mm-icon'] span")
	public WebElement thanksForSubscribing;

//	static By section_Element = By.xpath("//*[contains(@class,'footer')]");
//	By placeholder = By.cssSelector("[placeholder='Enter Your Email Id']");
	
	public bMailPComponent(final WebDriver driver) {
		//super(driver,section_Element);
		super(driver);
	}

	public void goToFooterTitle() {
		moveToElementAction(act, footerContainer);
	}

	public void inputMailClick() throws Exception {
		prop =propInit(prop);
		mailInput.click();
		mailInput.sendKeys(prop.getProperty("mail"));
	}

	public void sendMailClick() {
		sendMail.click();
	}

	public boolean validateResponse() {
		return this.driver.getPageSource().contains("Thanks for subscribing");
	}
	
//	public void getAttributeOf()
//	{
//		System.out.println(findElement(placeholder));			//method calling //method implementation is in Abstract Component
//	}

	@Override
	public boolean isDisplayed() {

		return this.w.until(d -> this.footerContainer.isDisplayed());
	}

}
