package cStrategyPageComponents;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import dStrategyInterface.AbstractComponent;
import dStrategyInterface.CategoryMainMenu;

public class HairPC extends AbstractComponent implements CategoryMainMenu {

	@FindBy(xpath = "(//div[@id='my-menu']//a[text()='hair'])[1]")
	public WebElement hairCategory;

	@FindBy(xpath = "(//a[text()='hair care'])[1]")
	public WebElement hairCare;

	public HairPC(WebDriver driver) {
		super(driver);
	}

	@Override
	public void mainMenuSelection(String category) {

		// System.out.println("inside hair category");
		this.moveToElementAction(this.act, hairCategory);
		this.explicitWait(this.w, hairCare);
		hairCare.click();
		try {
			this.switchWindow();
		} catch (Exception e) {
			System.out.println("Error opening hair care window; Please Wait");
		}
	}

	@Override
	public boolean isDisplayed() {
		return this.w.until(d-> this.hairCare.isDisplayed());
	}

}
