package cStrategyPageComponents;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import dStrategyInterface.AbstractComponent;
import dStrategyInterface.CategoryMainMenu;

public class SkinPC extends AbstractComponent implements CategoryMainMenu {

	@FindBy(xpath = "(//a[text()='skin'])[2]")
	public WebElement skinCategory;

	@FindBy(xpath = "//a[text()='Cleansers']")
	WebElement cleansers;

	public SkinPC(WebDriver driver) {
		super(driver);
	}

	@Override
	public void mainMenuSelection(String category) {

		// System.out.println("inside skin category");
		this.moveToHomeAction(act);
		this.explicitWait(this.w, skinCategory);
		this.moveToElementAction(this.act, skinCategory);
		this.cleansers.click();
		try {
			this.switchWindow();
		} catch (Exception e) {
			System.out.println("Unable to open the window");
		}
	}

	@Override
	public boolean isDisplayed() {
		return this.w.until(d -> this.skinCategory.isDisplayed());	}

}
