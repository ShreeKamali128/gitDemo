package aStrategyHome;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;


import Hair.aFiltersPC;
import Hair.bProductListingPC;
import Hair.cSingleProductPC;
import Hair.dCartProductsPC;
import Home.aOfferTopBar;
import Home.bHeaderBar;
import Home.cSubHeaderBar;
import bStrategyPageObjects.OfferTopBarPO;
import bStrategyPageObjects.SubHeaderPO;
import dStrategyInterface.CategoryMainMenu;

public class HomePage {

private WebDriver driver;
	
	By section_Element1 = By.xpath("//div[contains(@class,'top-menu')]");
	By section_Element2 = By.cssSelector("#category_navigation");
	
	public HomePage(final WebDriver driver)
	{
		this.driver=driver;
	}
	
	public OfferTopBarPO getOfferTopBar()
	{return new OfferTopBarPO(driver,section_Element1);}
	
	
	public SubHeaderPO getSubHeaderBar()
	{return new SubHeaderPO(driver,section_Element2);}
	
	

}
