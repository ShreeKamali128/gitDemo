package dStrategyInterface;

public interface CategoryMainMenu {

	public void mainMenuSelection(String category);
	
}
