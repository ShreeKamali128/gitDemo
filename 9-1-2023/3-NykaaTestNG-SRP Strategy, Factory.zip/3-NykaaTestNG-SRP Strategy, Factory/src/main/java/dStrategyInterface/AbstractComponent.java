package dStrategyInterface;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;


public abstract class AbstractComponent {
	
	protected WebDriverWait w;
	
	protected Actions act;
	protected Properties prop;
	public WebDriver driver;
	public WebElement sectionElement;
	
	public JavascriptExecutor js = null;
	public String parent, child = null;
	
	public AbstractComponent(final WebDriver driver)
	{
		this.w=new WebDriverWait(driver, Duration.ofSeconds(60));
		
		this.act=new Actions(driver);

		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	public AbstractComponent(final WebDriver driver, By section_Element)		
	{
		this.w=new WebDriverWait(driver, Duration.ofSeconds(60));
		
		this.act=new Actions(driver);

		this.driver=driver;
		PageFactory.initElements(driver, this);
		this.sectionElement=driver.findElement(section_Element);
	}

	public WebElement findElement(By findElementBy)
	{
		return sectionElement.findElement(findElementBy);
	}
	
	public abstract boolean isDisplayed();
	

	public String getTitle() {
		return driver.getTitle();
	}

	public Properties propInit(Properties prop) throws IOException {
		prop = new Properties();
		File f = new File(System.getProperty("user.dir") + "\\src\\main\\java\\utils\\Parameters.properties");
		FileInputStream fis = new FileInputStream(f);
		prop.load(fis);

		return prop;
	}

	public WebDriver implicitWait(WebDriver driver) {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		return driver;
	}

	public void switchFrame(WebElement frame) {
		driver.switchTo().frame(frame);
	}
//	public WebDriverWait explicitWait(WebDriver driver) {
//		WebDriverWait w = new WebDriverWait(driver, Duration.ofSeconds(20));
//		return w;
//	}

	public void explicitWait(WebDriverWait w, WebElement waitElem) {
//		w.until(ExpectedConditions.visibilityOfElementLocated(waitElem));	//webelement is of By type argument
		w.until((d) -> waitElem.isDisplayed()); // webelement is of WebElement type itself
	}

	public void sleepMethod() throws InterruptedException {
		Thread.sleep(3000);
	}

	public void moveToElementAction(Actions act, WebElement moveToElem) {
		act.moveToElement(moveToElem).perform();
	}

	public void moveToHomeAction(Actions act) {
		act.sendKeys(Keys.HOME).build().perform();
	}

	public void moveToElement_ClickAction(Actions act, WebElement elemClick) {
		act.moveToElement(elemClick).click().build().perform();
	}

	public void sendInputsAction(Actions act, WebElement inputElem, String str) {
		act.sendKeys(inputElem, str).build().perform();
	}

	public void KeyAction(Actions act, Keys key) {
		act.sendKeys(key).build().perform();
	}

	public JavascriptExecutor scrollTop() throws Exception {
		js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,0)");
		Thread.sleep(4000);
		return js;
	}

	public JavascriptExecutor scrollWindow1() throws Exception {
		js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,100)");
		Thread.sleep(4000);
		return js;
	}

	public JavascriptExecutor scrollWindow3() throws Exception {
		js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,300)");
		Thread.sleep(4000);
		return js;
	}

	public JavascriptExecutor scrollWindow8() throws Exception {
		js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,800)");
		Thread.sleep(4000);
		return js;
	}

	By frame = By.cssSelector("[class*='iframeStyle']");

	public WebDriver iFrameSwitch(WebDriver driver) throws Exception {

		String url = driver.findElement(frame).getDomAttribute("src");
		driver.switchTo().newWindow(WindowType.TAB);
		driver.get(url);
		Thread.sleep(5000);
		return driver;
	}

//	public WebDriver switchTab(WebDriver driver) throws InterruptedException
//	{
//		public ArrayList<String> wins= null;
//		 wins = new ArrayList<String>(driver.getWindowHandles());
//		driver.switchTo().window(wins.get(1));
//		
//		return driver;
//	}

	public void switchWindow() throws Exception {

		winHandles(driver);
		driver.switchTo().window(parent);
		driver.close();
		driver.switchTo().window(child);

	}

	public WebDriver winHandles(WebDriver driver) throws Exception {

		Set<String> windows = driver.getWindowHandles();
		Iterator<String> itr = windows.iterator();
		parent = itr.next();
		Thread.sleep(5000);
		child = itr.next();
		driver.switchTo().window(child);

		return driver;
	}

	public WebDriver switchChild() throws InterruptedException { // child switch; parent close

		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs.get(1));
		System.out.println("switched");
		return driver;
	}

	public WebDriver switchParent() throws InterruptedException { // child switch; parent close

		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());

		driver.switchTo().window(tabs.get(0));
		return driver;
	}

	/*
	 * public void csvdata(List<String[]> list2) throws Exception, Throwable {
	 * 
	 * File f = new File("./src\\main\\java\\resources2\\StoreDetails.csv");
	 * FileWriter fw = new FileWriter(f); CSVWriter csvWriter = new CSVWriter(fw);
	 * 
	 * List<String[]> list = list2;
	 * 
	 * for (String[] i : list) csvWriter.writeNext(i);
	 * 
	 * csvWriter.close();
	 * 
	 * System.out.println("Data added to csv fie..."); System.out.println("\n"); }
	 * 
	 */

	@AfterClass
	public void close(WebDriver driver) throws Exception {
		Thread.sleep(2000);
		driver.quit();
	}

}
