package dStrategyInterface;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import cStrategyPageComponents.HairPC;
import cStrategyPageComponents.SkinPC;


public class StrategyFactor {
    WebDriver driver;
    //By sectionElement= By.id("flightSearchContainer");

    public StrategyFactor(WebDriver driver) {
        this.driver = driver;
    }

    public CategoryMainMenu createStrategy(String strategyType)
    {
        if(strategyType.equalsIgnoreCase("hair"))
        {
           return new HairPC(driver);
        }
        if(strategyType.equalsIgnoreCase("skin"))
        {
            return new SkinPC(driver);
        }
        return null;
    }
}
