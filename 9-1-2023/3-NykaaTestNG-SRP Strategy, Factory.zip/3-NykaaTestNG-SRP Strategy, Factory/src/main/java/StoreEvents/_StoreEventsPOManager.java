package StoreEvents;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;


public class _StoreEventsPOManager {

	
	private aFilterPC f;
	private bStoreDetailsPC sd;
	

	public _StoreEventsPOManager(final WebDriver driver) {
		this.f = PageFactory.initElements(driver, aFilterPC.class);
		this.sd = PageFactory.initElements(driver, bStoreDetailsPC.class);
	}


	public aFilterPC getFiltersPC() {
		return f;
	}

	public bStoreDetailsPC getStoreDetailsPC() {
		return sd;
	}

	

}
