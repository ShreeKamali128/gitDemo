package StoreEvents;

import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.FindBy;
import _common.AbstractComponent;

public class aFilterPC extends AbstractComponent {

	public aFilterPC(WebDriver driver) {
		super(driver);
	}

	@FindBy(xpath = "(//ol/li)[2]")
	public WebElement storesHeading;

	@FindBy(xpath = "(//input[@id='nw-store-search'])[1]")
	public WebElement searchCity;

	@FindBy(xpath = "//*[contains(@class,'nw-store-search-dropdown')]/a")
	public List<WebElement> searchCityDropdown;

	@FindBy(css = ".nw-store-list")
	public WebElement storeList;

	public boolean verifyStoreTitle(String s) {
		return storesHeading.getText().contains(s);
	}

	public void searchCity(String str) throws Exception {

		w.until((x) -> this.storeList.isDisplayed());
		moveToElement_ClickAction(act, searchCity);
		w.until((x) -> this.storeList.isDisplayed());
		Thread.sleep(3000);
		searchCity.sendKeys(str.toString());
		for(WebElement opt: searchCityDropdown)
		{
			if(opt.toString().equals(str))
			{
				//opt.click();
				implicitWait(driver);
				this.moveToElement_EnterAction(act, opt);
				//this.moveToElement_ClickAction(act, opt);
			}
		}
	}

	public void chooseCity(String str) throws InterruptedException {
		// this.EnterAction(act);
		//explicitWait(searchCityDropdown);
		//w.until( (x) -> this.searchCityDropdown.isDisplayed() );
		//this.implicitWait(driver);
		
		for(WebElement opt: searchCityDropdown)
		{
			if(opt.toString().equals(str))
			{
				opt.click();
				//this.moveToElement_ClickAction(act, opt);
			}
		}
	}

//	public void clearSearch(){
//		act.click(this.searchCity).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build().perform();
//			} 

	@Override
	public boolean isDisplayed() {
		return this.w.until((d) -> storesHeading.isDisplayed());
	}

}