package Tests;

import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import DriverInit.BaseTest;
import DriverInit.testContextSetUp;
import Home._HomePOManager;

import StoreEvents._StoreEventsPOManager;
import StoreEvents.aFilterPC;
import StoreEvents.bStoreDetailsPC;
import _common.PageObjectManager;

public class StoreEventsTest extends BaseTest implements ITestListener{

	private PageObjectManager pom;
	private _StoreEventsPOManager se;
	private _HomePOManager home;

	private aFilterPC f;
	private bStoreDetailsPC sd;
	
	private SoftAssert ass;
	private testContextSetUp tcs;


	@BeforeClass
	public void initAllPOM()
	{
		tcs = new testContextSetUp(driver);
		pom = tcs.pom;
		ass = tcs.ass;
		tcs.deltcookies();
		
		se = pom.storeEventsPOM();
		home =pom.homePOM();
		
		f=se.getFiltersPC();
		sd=se.getStoreDetailsPC();
	}

	@Test(priority=1)
	public void GoToStoreEvents() throws Exception {
		ass.assertTrue(home.getOfferTopBar().isDisplayed());
		home.getOfferTopBar().goToStoresEvents();
	}

	
	@Test (priority=2, dataProvider="GetData", dependsOnMethods= {"GoToStoreEvents"})
	public void SearchCity(String place) throws Throwable

	{
		ass.assertTrue(f.isDisplayed());
		//System.out.println(place);
		f.searchCity(place);
		//se.getFilters().chooseCity(place);
		
		ass.assertTrue(sd.isDisplayed());
		ass.assertTrue(sd.verifyPlace(place));
		sd.printExcel();
	}
	
	@DataProvider
	public Object GetData()
	{
		Object[][] o=new Object[1][1];
		o[0][0]="Chennai";
		//o[1][0]="Bangalore";
		
		return o;
	}
	
	@AfterClass
	public void goToHomeLogo()
	{
		home.getHeaderBar().goToLogoo();
		ass.assertTrue(home.getHeaderBar().verifyUrl());
	}
	
	
	@Override
	public void onTestSuccess(ITestResult result) {
		System.out.println("Successfully completed "+result.getName()+ " Test");
	}

	@Override
	public void onTestFailure(ITestResult result) {
		System.out.println("Failed Test " + result.getName());

	}
}
