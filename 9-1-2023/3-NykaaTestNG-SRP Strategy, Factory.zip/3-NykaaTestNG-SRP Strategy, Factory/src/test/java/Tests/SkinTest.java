package Tests;


import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import DriverInit.BaseTest;
import DriverInit.testContextSetUp;
import Home._HomePOManager;
import Skin._SkinPOManager;
import Skin.aFiltersPC;
import Skin.bProductListingPC;
import _common.PageObjectManager;

public class SkinTest extends BaseTest implements ITestListener {

	private PageObjectManager pom;
	private _SkinPOManager skin;
	private _HomePOManager home;
	
	private aFiltersPC f;
	private bProductListingPC pl;
	
	private SoftAssert ass;
	private testContextSetUp tcs;

	
	@BeforeClass
	public void setUpPages() {
		tcs = new testContextSetUp(driver);
		pom = tcs.pom;
		ass = tcs.ass;
		tcs.deltcookies();
		
		skin = pom.skinPOM();
		home = pom.homePOM();
		
		f = skin.getFiltersPC();
		pl = skin.getProductListingPC();
	}
	
	@Test(priority=1)
	public void GoToSkinCategory() throws Exception

	{
		ass.assertTrue(home.getSubHeaderBar().isDisplayed());
		home.getSubHeaderBar().goToSkinCategory();
		home.getSubHeaderBar().goToCleansers();
	}

	@Test(priority=2, dependsOnMethods= {"GoToSkinCategory"})
	public void ApplyFilters() throws Exception

	{
		ass.assertTrue(f.isDisplayed());
		f.customerRatingClick();
		f.discountClick();
		ass.assertTrue(f.verifyFilterApplied());
	}
	
	@Parameters({"Label"})
	@Test(priority=3, dependsOnMethods= {"GoToSkinCategory", "ApplyFilters"})
	public void AddToWishlist(String label) throws Exception

	{	
		ass.assertTrue(pl.isDisplayed());
		pl.heartIconClicked();
		ass.assertTrue(pl.verify(label));
		pl.closeSignIn();
		
	}
	
	@AfterClass
	public void goToHomeLogo()
	{
		home.getHeaderBar().goToLogo();
		ass.assertTrue(home.getHeaderBar().verifyUrl());
	}
	
	@Override
	public void onTestSuccess(ITestResult result) {
		System.out.println("Successfully completed " + result.getName()  +" Test");
	}

	@Override
	public void onTestFailure(ITestResult result) {
		System.out.println("Failed Test " + result.getName());

	}
	
	
}
