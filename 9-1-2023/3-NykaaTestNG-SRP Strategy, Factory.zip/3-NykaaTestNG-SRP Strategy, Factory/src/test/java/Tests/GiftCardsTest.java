package Tests;

import org.junit.Assert;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import DriverInit.BaseTest;
import DriverInit.testContextSetUp;
import GiftCard._GiftCardPOManager;
import GiftCard.aTagsPComponent;
import GiftCard.bMailPComponent;
import Home._HomePOManager;
import _common.PageObjectManager;

public class GiftCardsTest extends BaseTest implements ITestListener {


	private PageObjectManager pom;
	private _HomePOManager home;
	private _GiftCardPOManager gc;
	
	private SoftAssert ass;
	private testContextSetUp tcs;
	
	private aTagsPComponent tg;
	private bMailPComponent ml;

		
	@BeforeClass
	public void initAllPOM()
	{
		tcs = new testContextSetUp(driver);
		pom = tcs.pom;
		ass = tcs.ass;
		tcs.deltcookies();
		
		gc = pom.gcPOM();
		home = pom.homePOM();
		
		tg = gc.getgiftCardContainerPC();
		ml = gc.getMailPC();
	}

	@Test(priority=1)
	public void GoToGiftCards() throws Exception {
		ass.assertTrue(home.getOfferTopBar().isDisplayed());
		home.getOfferTopBar().goToGiftCards();
	}

	@Test(priority=2, dependsOnMethods= {"GoToGiftCards"})
	public void GoToTags() throws Exception

	{
		ass.assertTrue(tg.isDisplayed());
		tg.nykaaForCorporatesClick();
		Assert.assertTrue(tg.verifyNykaaForCorporates());
	}

	@Test(priority=3, dependsOnMethods= {"GoToGiftCards", "GoToTags"})
	public void GoToMail() throws Exception {
		ass.assertTrue(ml.isDisplayed());
		ml.goToFooterTitle();
		ml.inputMailClick();
		ml.sendMailClick();
		ass.assertTrue(ml.validateResponse());
	}
	
	@AfterClass
	public void goToHomeLogo()
	{
		home.getHeaderBar().goToLogoo();
		ass.assertTrue(home.getHeaderBar().verifyUrl());
	}
	
	@Override
	public void onTestSuccess(ITestResult result) {
		System.out.println("Successfully completed " + result.getName() + " Test");
	}

	@Override
	public void onTestFailure(ITestResult result) {
		System.out.println("Failed the Test " + result.getName());

	}

}
