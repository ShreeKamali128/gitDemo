package Tests;


import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import DriverInit.BaseTest;
import DriverInit.testContextSetUp;
import Hair._HairPOManager;
import Hair.aFiltersPC;
import Hair.bProductListingPC;
import Hair.cSingleProductPC;
import Hair.dCartProductsPC;
import Home._HomePOManager;
import _common.PageObjectManager;

public class HairTest extends BaseTest implements ITestListener {

	private PageObjectManager pom;
	private _HomePOManager home;
	private _HairPOManager hr;
	
	private aFiltersPC f;
	private bProductListingPC pl;
	private cSingleProductPC sp;
	private dCartProductsPC cp;
	 
	private testContextSetUp tcs;
	private SoftAssert ass;
	
	
	@BeforeClass
	public void setUpPages() {
		tcs = new testContextSetUp(driver);
		pom = tcs.pom;
		ass = tcs.ass;
		tcs.deltcookies();
		
		home = pom.homePOM();
		hr = pom.hairPOM();
	
		f=hr.getFiltersPC();
		pl=hr.getProductListingPC();
		sp=hr.getSingleProductPC();
		cp=hr.getCartProductsPC();
		
	}


	@Test(priority=1)
	public void GoToHairCare() throws Exception
	{
	ass.assertTrue(home.getSubHeaderBar().isDisplayed());
	home.getSubHeaderBar().goToHairCategory();
	home.getSubHeaderBar().goToHairCare();
	}
	
	@Test(priority=2, dependsOnMethods= {"GoToHairCare"})
	public void GetFiltersApplied() throws Exception

	{		
		ass.assertTrue(f.isDisplayed());
		f.sortByDropDowns();
		f.selectFilters();
		ass.assertTrue(f.verifyFilterApplied());
	}
	
	@Test(priority=3, dependsOnMethods= {"GoToHairCare", "GetFiltersApplied"})
	public void WorkOnSingleProd() throws Exception

	{		
		ass.assertTrue(pl.isDisplayed());
		pl.productClick();
		
		ass.assertTrue(sp.isDisplayed());
		String s1 =sp.topRatedProduct();
		sp.addToBagClick();
		
		home.getHeaderBar().viewBagClick();
		
		cp.switchFrame();
		//ass.assertTrue(cp.isDisplayed());
		
		String s2=cp.cartProduct();
		ass.assertEquals(s1,s2);
		cp.chargeFees();
		cp.closeFrame();	
	}
	
	@AfterClass
	public void goToHomeLogo()
	{
		home.getHeaderBar().goToLogo();
		ass.assertTrue(home.getHeaderBar().verifyUrl());
	}
	
	@Override
	public void onTestSuccess(ITestResult result) {
		System.out.println("Successfully completed "+result.getName() +" Test");
	}

	@Override
	public void onTestFailure(ITestResult result) {
		System.out.println("Failed Test " + result.getName());

	}
	
}
