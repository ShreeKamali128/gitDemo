package StrategyTest;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import DriverInit.BaseTest;
import GiftCard._GiftCardPOManager;
import Hair._HairPOManager;
import Home._HomePOManager;
import aStrategyHome.HomePage;
import cStrategyPageComponents.HairPC;
import cStrategyPageComponents.SkinPC;

public class Testss extends BaseTest {

	
	private HomePage home;
	

	@BeforeTest
	public void setUpPages() {
		this.home = new HomePage(driver);
	}

	@Test
	public void giftCardsWorkFlow() throws Exception

	{
		SoftAssert ass= new SoftAssert();
		this.driver.manage().deleteAllCookies();
		
		ass.assertTrue(home.getSubHeaderBar().isDisplayed());
		
		home.getSubHeaderBar().setCategoryStrategy("hair");
		home.getSubHeaderBar().mainMenuSelection("Hair Care");
	}
		
}
