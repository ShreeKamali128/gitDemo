package DriverInit;

import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;

import com.google.common.util.concurrent.Uninterruptibles;

import _common.AbstractComponent;

public class BaseTest extends AbstractComponent {

	protected static WebDriver driver = null; // important static member else driver not shared among all tests. only
												// first class in first test will run. from the second there will be an
												// error
	protected Properties prop;

	@Parameters({ "browser" })
	@BeforeSuite
	public WebDriver setUpDriver(String browser) throws Exception {
		if (driver == null) 
		{
			if (browser.equalsIgnoreCase("edge")) {				//here browser==edge do not work.
				System.setProperty("webdriver.edge.driver",System.getProperty("user.dir") + "\\src\\test\\java\\resources\\msedgedriverN");
				driver = new EdgeDriver();
			}
			else if(browser.equalsIgnoreCase("chrome")){
				System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir") + "\\src\\test\\java\\resources\\chromedriver");
				driver = new ChromeDriver();
			}

			this.windowMaximize(driver);
			implicitWait(driver);

			prop = propInit(prop);
			String url = prop.getProperty("url");
			driver.get(url);
		}
		return driver;
	}

	@AfterSuite
	public void stopDriver() {
		Uninterruptibles.sleepUninterruptibly(Duration.ofSeconds(3));
		driver.quit();
	}

	@Override
	public boolean isDisplayed() {
		return false;
	}

}
