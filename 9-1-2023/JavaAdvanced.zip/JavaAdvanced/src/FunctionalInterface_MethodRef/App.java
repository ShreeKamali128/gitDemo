package FunctionalInterface_MethodRef;


interface Calculator
{
	public abstract void add(int a, int b);
}

class Calci
{
	public static void sum(int a, int b)
	{
		System.out.println("a +b is: "+ (a+b) );
	}
	public void sums(int a, int b)
	{
		System.out.println("a +b is: "+ (a+b) );
	}
}

interface Messenger{
	Message getMessage(String msg);
}

class Message{
	Message(String msg)
	{
		System.out.println("Msg is: "+ msg);
	}
}
public class App {

	public static void main(String[] args) {

		//usual
		//Calci.sum(10, 20);
		
		//1. reference to a static method
		Calculator cref= Calci::sum;
		cref.add(10, 20);
		
		//2.Reference to non-static method or instance method
		Calci calc=new Calci();
		Calculator cref1 = calc::sums;
		cref1.add(20,30);
		
		//3. Reference to constructor method 
		Messenger mref= Message::new;
		mref.getMessage("Search for the candle rather than cursing the darkness!!");
	}

}
