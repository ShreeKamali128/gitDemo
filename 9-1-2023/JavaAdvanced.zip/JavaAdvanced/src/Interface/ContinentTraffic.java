package Interface;

public interface ContinentTraffic {
	
	
	public void GreenGo();
	public void RedStop();
	public void YellowWait();
}
