package Interface;

public class IndianTraffic implements CentralTraffic, ContinentTraffic {

	public static void main(String[] args) {
		IndianTraffic it = new IndianTraffic();
		it.DogSymbol();

		ContinentTraffic cot = new IndianTraffic();
		cot.RedStop();
		cot.GreenGo();
		cot.YellowWait();
		

		CentralTraffic cet = new IndianTraffic();
		cet.PedestrainSymbol();
	}

	@Override
	public void GreenGo() {
		System.out.println("green go");
	}

	@Override
	public void RedStop() {
		// TODO Auto-generated method stub
		System.out.println("Red Stop");
	}

	public void DogSymbol() {
		System.out.println("Dog Symbol");
	}

	@Override
	public void YellowWait() {
		// TODO Auto-generated method stub
		System.out.println("Yellow wait");
	}

	@Override
	public void PedestrainSymbol() {
		// TODO Auto-generated method stub
		System.out.println("Pedestrain symbol");
	}

}
