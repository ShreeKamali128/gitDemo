package enumDemo;
import java.util.*;
/*
enum Season {
	WINTER, SUMMER, FALL
} // outside class no specifier else error

public class enumSample {

	// public enum Season { WINTER, SUMMER, FALL}

	public static void main(String[] args) {

		for (Season s : Season.values())
			System.out.println(s);
		System.out.println(Season.valueOf("WINTER"));
		System.out.println(Season.valueOf("SUMMER").ordinal());

	}

}
*/

/*
class enumSample {
	enum Season {
		WINTER(6), AUTUMN(9), SPRING(8); // not initialized- raise error

		private int age;

		private Season(int age) {
			this.age = age;
		}
	}

	public static void main(String[] args) {
		Season s = Season.valueOf("SPRING");
		System.out.println(s);
	}

}
*/


class enumSample {
	public enum Day {
		SUNDAY, MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY
	}

	public static void main(String args[]) {
		
		
		Set<Day> sett=EnumSet.of(Day.MONDAY, Day.FRIDAY);
		Set<Day> sett1=EnumSet.allOf(Day.class);
		Set<Day> sett2=EnumSet.noneOf(Day.class);
		
		Iterator itr=sett1.iterator();
		while(itr.hasNext())
			System.out.println(itr.next());
		
		
		
		
		
		Day day = Day.MONDAY;

		switch (day) {
		case SUNDAY:
			System.out.println("sunday");
			break;
		case MONDAY:
			System.out.println("monday");
			break;
		default:
			System.out.println("other day");
		}
	}
}
