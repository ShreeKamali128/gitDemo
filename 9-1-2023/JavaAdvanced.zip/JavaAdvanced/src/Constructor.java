import Inheritance.Sinlge.aParentClass;

public class Constructor extends aParentClass{

	String name="child class property";
	int a=2;
	public Constructor()
	{
		System.out.println("default const");
	}
	
	public Constructor(int a, int b)
	{
		int c= a+b;
		System.out.println(c);
	}
	
	public Constructor(String str)
	{
		System.out.println(str);
	}
	
	//super keyword
	public void getName()
	{
		System.out.println(name);
		System.out.println(super.name);
	}
	
	//this keyword
	public void thisDemo()
	{
		int a=3;
		System.out.println(a);
		System.out.println(this.a);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Constructor cons1= new Constructor(2,4);
		//Constructor cons2= new Constructor("Sweety");
		Constructor cons= new Constructor();
		cons.getName();
		cons.thisDemo();

	}

}
