import java.text.SimpleDateFormat;
import java.util.Date;
public class DateDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Date date= new Date();
		System.out.println(date.toString());
		SimpleDateFormat sdf= new SimpleDateFormat("G z y/M/d EF D W w h:m:sa H:m:Sa");
		System.out.println(sdf.format(date));  

	}

}