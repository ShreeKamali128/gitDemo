package Exceptions;

public class Sample2 {
	
	static void getDs()
	{
		try {
//			int a=2,b=0;
//			int c=a/b;
			throw new ArithmeticException("AE");
		}
		catch(ArithmeticException e)
		{
			System.out.println("Cant divide any number by zero");
		}
	}
	public static void main(String[] args) {
		getDs();
	}

}
