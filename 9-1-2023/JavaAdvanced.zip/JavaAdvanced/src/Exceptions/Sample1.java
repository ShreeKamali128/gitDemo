package Exceptions;

public class Sample1 {

	public static void main(String[] args) {

		try {
		try {
			int a=30, b=0;
			int c=a/b;
			System.out.println("c is"+ c);
		}
		catch(ArithmeticException e)
		{
			System.out.println("Cant divide by zero");
		}
		
		try {
			int str=Integer.parseInt("Edureka");
			System.out.println("Str is "+ str);
			
		}
		catch(NumberFormatException e)
		{
			System.out.println("Cant convert number int string");
		}
		
		try {
			int[] arr=new int[5];
			arr[6]=21;
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("Cant add 21 in the 6th index");
		}
		
		System.out.println(" exceptions handled");
		try {
			int x=9, z=0;
			int y=x/z;
		}
		finally {
			System.out.println("finally always executed though catch is not there");
		}
		}
		catch(Exception e)
		{
			System.out.println("Not handled exception");	//since last try dont have catch, this catch executed
		}
	}

}
