package Exceptions;

import java.util.Scanner;

//user defined exception
//1. it should use throw
//2. then user defined exception must extend exception class

public class Sample4 {
	
	static void validateInput(int input) throws InvalidInputException
	{
		if(input>100)
		{
			throw new InvalidInputException("Exception");
		}
		System.out.println("valid input");
	}
	public static void main(String[] args) {
		
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter a number < 100 ");
		int input=sc.nextInt();
		try {
		validateInput(input);
		}
		catch(Exception e)
		{
			System.out.println("Number is not < 100");
		}
	}
}

class InvalidInputException extends Exception
{
	InvalidInputException(String exceptionText){
		super(exceptionText);
	}
}