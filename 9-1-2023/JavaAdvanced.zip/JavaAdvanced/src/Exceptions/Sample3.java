package Exceptions;

//user defined exception
//1. it should use throw
//2. then user defined exception must extend exception class

public class Sample3 {
	
	public static void main(String[] args) {
		try {
			throw new MyException(5);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}

class MyException extends Exception
{
	int a;
	MyException(int a)
	{
		this.a=a; 
	}
	
	public String toString()
	{
		return "Exception is : "+ this.a;
	}
}