package Exceptions;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Sample5 {
	
	static void dateFormat(String input)
	{
		try {
		SimpleDateFormat sdf= new SimpleDateFormat("dd/mm/yyyy");
		Date date= sdf.parse(input);
		SimpleDateFormat odf= new SimpleDateFormat("yyyy/MM/dd");
		String output=odf.format(date);
		System.out.println("After changing the date format "+ output);
		}
		catch(java.text.ParseException e)
		{
			System.out.println("Some error occured...");
		}
		
	}
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter date in dd/mm/yyy format");
		String input=sc.nextLine();
		dateFormat(input);
	}
		

}
