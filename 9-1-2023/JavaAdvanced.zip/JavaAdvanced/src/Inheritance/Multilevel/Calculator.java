package Inheritance.Multilevel;

public class Calculator {
	 public float div(float m, float n)
	 {
		 return m/n;
	 }
	 public float mul(float m, float n)
	 {
		 return m*n;
	 }
	 public float sum(float m, float n)
	 {
		 return m+n;
	 }
	 public float dif(float m, float n)
	 {
		 return m-n;
	 }

}

 class advanced extends Calculator
{
	public float mod(float m, float n)
	{
		return m%n;
	}
	
	public float sq(float m)
	{
		return m*m;
	}
	
	public float sqrt(float m)
	{
		System.out.println(Math.sqrt(m));
		return m;
	}
}

class area extends advanced
{
	public float square(float m)
	{
		return m*m;
	}
	
	public float rectangle(float m, float n)
	{
		return m*n;
	}
	
	public float circle(float r)
	{
		return (float)(3.14*r*r);	
	}
}
