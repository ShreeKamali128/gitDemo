package Inheritance.Multilevel;

public class BaseClass {
	public static void main(String[] args) {
		area a= new area();
		float sum=a.sum(3, 4);
		float dif=a.dif(4,1);
		float sq=a.sq(100);
		float sqrt=a.sqrt(16);
		float rect=a.rectangle(20,30);
		float circle=a.circle(30);
		System.out.println(sum+"\n"+dif+"\n"+sq+"\n"+sqrt+"\n"+rect+"\n"+circle);
	}
}
