package Inheritance.Sinlge;

public class EmpData {

	public static void main(String[] args) {

		Employee obj = new Employee();

		obj.setName(" Dhuhira");
		obj.setAge(19);
		obj.setEmpId(21);

		System.out.println("Geek's name: " + obj.getName());
		System.out.println("Geek's age: " + obj.getAge());
		System.out.println("Geek's roll: " + obj.getEmpId());

		// System.out.println("Geek's roll: " +obj.geekName); //Direct access of geekRoll is not possible due to encapsulation...

		/*
		 * any user with the instance of the object of the Encapsulate can change the
		 * fields. by simply referring the attribute with �this� keyword. Therefore, in
		 * order to avoid this, we enclose the properties in the methods called the
		 * getters and setters of the attributes.
		 */
	}

}
