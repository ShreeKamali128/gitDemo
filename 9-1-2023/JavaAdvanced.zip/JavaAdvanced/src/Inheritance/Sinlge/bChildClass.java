package Inheritance.Sinlge;

public class bChildClass extends aParentClass {

	 String name = "child class property";

	// constructor
	public bChildClass() {
		super(); // should be the first line
		System.out.println("child class constr");
	}
	
	public void getProperty()
	{
		System.out.println(super.name);
	}

	//run time polymorphism or dynamic dispatch
	// function overridden or method overridden or runtime polymorphism
	public void Engine() {
		System.out.println("engine child");
	}

	public void Brakes() {
		//calling parent brake method from the child
		super.Brakes();
		System.out.println("Brakes child");
	}

	//compile time polymorphism
	// method overloading
	public void getData(int a) {
		System.out.println(a);
	}

	public void getData(String s) {
		System.out.println(s);
	}

	public static void main(String[] args) {

		
		aParentClass pc1 = new aParentClass();
		pc1.RPM();
		pc1.Engine();
		pc1.Brakes();
		
		// up casting child class to parent class
		aParentClass pc = new bChildClass();
		
		
		System.out.println(pc.name); // The reference type of pc is Parent so the Parent class variable is accessed,
										// not the Child class variable
		
		pc.RPM();				 // not overridden method just a inherited method
		pc.Engine(); 			 // overridden methods
		pc.Brakes(); 			 // overridden methods // Here pc is a reference type of Parent class but holds an
								 // object type of Child Class so that's why Child class function will be called in
								 // that case
		
		bChildClass cc = new bChildClass();
		
		//polymorphism
		cc.getData(3);
		cc.getData("Shree");
		System.out.println();
		cc.getProperty();
		System.out.println(cc.name); 		// Here the reference type of cc is Child, so the Child class variable is
											// accessed not the Parent class variable.
		
		cc.getData(2); 					// class's own method
		cc.getData("Hello"); 			// Here cc holds an object of Child Class, so the Child class function will be
										// called.

		// down casting parent class to child class and then you can print the data member in the child class if you override the data member itself
		bChildClass cc1 = (bChildClass) pc;   
		System.out.println(cc1.name);		//o/p:  child class property
		cc1.RPM();		//inherited method
		cc1.Engine();
		cc1.Brakes();
		
		
		
		
		/*
		 * downcasting a child object can acquire the properties of the parent object.
		 * cc1.name = pc.name; i.e., c.name = " parent class property"
		 * If there is any property like "name" in the childclass, then the output wil be "child class property"
		 */

		/*
		 * There is no polymorphism for fields in Java. Variables decision happens at a
		 * compile time so always Base Class variables (not child�s inherited variables)
		 * will be accessed.So whenever upcasting happens always remember 1) Base Class
		 * variables will be accessed. 2) Sub Class methods(overridden methods if
		 * overriding happened else inherited methods as it is from parent) will be
		 * called.
		 */

	}

}
