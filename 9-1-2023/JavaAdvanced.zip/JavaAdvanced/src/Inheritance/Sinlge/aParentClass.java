package Inheritance.Sinlge;

public class aParentClass {

	protected String name="parent class property";
	
	public aParentClass()
	{
		System.out.println("parent classe const");
	}
	
	public void Engine()
	{
		System.out.println("engine parent");
	}
	
	public void Brakes()
	{
		System.out.println("Brakes parent");
	}
	
	public void RPM()
	{
		System.out.println("rpm parent");
	}

}
