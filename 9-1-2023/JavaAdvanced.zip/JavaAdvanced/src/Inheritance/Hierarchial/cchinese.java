package Inheritance.Hierarchial;

public class cchinese extends _HierarchialInheritance{
	
	void displayD()
	{
		System.out.println("pasta available");
		System.out.println("fried rice available");

	}

	

}
