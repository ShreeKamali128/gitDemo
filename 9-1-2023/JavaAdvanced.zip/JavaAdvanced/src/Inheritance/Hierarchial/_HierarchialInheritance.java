package Inheritance.Hierarchial;

public class _HierarchialInheritance {

	void displayA()
	{
		System.out.println("request to pass bread from parent restaurent");
		System.out.println("request to pass stew from parent restaurent");
		System.out.println("request to pass cheese from parent restaurent");

	}

}
