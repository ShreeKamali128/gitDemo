package Inheritance.Hierarchial;

public class restaurant extends _HierarchialInheritance{
	
	public static void main(String[] args) {
		
		amexican a= new amexican();
		bitalina b= new bitalina();
		cchinese c= new cchinese();
		System.out.println("This is mexican restaurant");
		a.displayA(); a.displayB();
		System.out.println("This is italian restaurant");
		b.displayA(); b.displayC();
		System.out.println("This is chinese restaurant");
		c.displayA(); c.displayD();
	}
	

}
