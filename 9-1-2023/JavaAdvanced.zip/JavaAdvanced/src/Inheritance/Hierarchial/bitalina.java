package Inheritance.Hierarchial;

public class bitalina extends _HierarchialInheritance {
	
	void displayC()
	{
		System.out.println("carrot available");
		System.out.println("sweet potato available");

	}

	

}
