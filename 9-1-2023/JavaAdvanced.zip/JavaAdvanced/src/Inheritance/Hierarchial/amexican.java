package Inheritance.Hierarchial;

public class amexican extends _HierarchialInheritance{

	void displayB()
	{
		System.out.println("noodles available");
		System.out.println("momos available");
		

	}

	

	

}
