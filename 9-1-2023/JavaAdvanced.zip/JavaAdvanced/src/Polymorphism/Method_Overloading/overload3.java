package Polymorphism.Method_Overloading;

public class overload3 {
	
	//sequence of parameters differ
	void display(char c, int i)
	{
		System.out.println("c is " + c);
	}
	
	void display(int i, char c)
	{
		System.out.println("c is " + c);
	}

}

class base3
{
	public static void main(String[] args) {
		overload3 o= new overload3();
		o.display('J', 3);
		o.display(3, 'J');
	}
}
