package Polymorphism.Method_Overloading;

public class typePromote {
	//type of parameters differ
	
	void display(int c, double d)
	{
		System.out.println("d is " + d);
	}
	
	void display(int c, double d, double e)
	{
		System.out.println("d is " + d);
	}

}

class base4
{
	public static void main(String[] args) {
		typePromote o= new typePromote();
		//float typeCasted to Double as there is no method with float type parameter
		o.display(3, 3.2f);
	}
}
