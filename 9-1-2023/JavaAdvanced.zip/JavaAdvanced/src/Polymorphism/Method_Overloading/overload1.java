package Polymorphism.Method_Overloading;

public class overload1 {
	//type of parameters differ
	void display(char c)
	{
		System.out.println("c is " + c);
	}
	
	void display(int c)
	{
		System.out.println("c is " + c);
	}

}

class base
{
	public static void main(String[] args) {
		overload1 o= new overload1();
		o.display('J');
		o.display(3);
	}
}
