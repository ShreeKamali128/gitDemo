package Polymorphism.Method_Overloading;

public class overload2 {
	
	//number of parameteres differ
	void display(char c)
	{
		System.out.println("c is " + c);
	}
	
	void display(int c, String s)
	{
		System.out.println("c and s is " + c+ " \t"+ s);
	}

}

class base2
{
	public static void main(String[] args) {
		overload2 o= new overload2();
		o.display('J');
		o.display(3,"Shree");
	}
}
