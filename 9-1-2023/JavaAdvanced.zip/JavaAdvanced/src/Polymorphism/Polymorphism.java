package Polymorphism;

public class Polymorphism {

	public static void main(String[] args) {

		 /*
		 * In the above concept of a bird and pigeon, a pigeon is inherently a bird.
		 *  And also, if the birds are further categorized into multiple categories like flying birds, flightless birds, etc. 
		 *  the pigeon also fits into the flying bird�s category.
		 *  And also, if the animal class is further categorized into plant-eating animals and meat-eating animals, 
		 *  the pigeon again comes into the plant-eating animal�s category.
		 * Therefore, the idea of polymorphism is the ability of the same object to take multiple forms. 
		 * There are two types of polymorphism:
		 */

		 /*
		 * Compile Time Polymorphism: It is also known as Static Polymorphism. 
		 * This type of polymorphism is achieved by function overloading or operator overloading.
		 *  It occurs when we define multiple methods with different signatures and the compiler knows which method needs to be executed based on the method signatures.
		 *  
		 *  Run Time Polymorphism: It is also known as Dynamic Polymorphism (Method Dispatch). 
		 *  It is a process in which a function call to the overridden method is resolved at Runtime. 
		 *  This type of polymorphism is achieved by Method Overriding.
		 *  When the same method with the same parameters is overridden with different contexts, the compiler doesn�t have any idea that the method is overridden. 
		 *  It simply checks if the method exists and during the runtime,it executes the functions which have been overridden.
		 */
	}

}
