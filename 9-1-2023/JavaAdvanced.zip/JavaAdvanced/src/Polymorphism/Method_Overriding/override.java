package Polymorphism.Method_Overriding;

public class override {
//	protected void display() {
//	public void display() {
	public void display() {
		System.out.println("parent class display");
	}

}

class base extends override{
//	public void display()		//the access specifier of the child class should be less restrictive than the parent class
//	protected void display()			//this combination throws error	
	public void display() 
	{
		System.out.println("Child calss display");
	}
	public void getData()
	{
		System.out.println("getData child");
	}
	public static void main(String[] args) {
		override o = new override();
		o.display();		//takes the object type reference and displays parent class method
		override o1 = new base();
		o1.display();		//takes the object type reference and displays child class method
	}
}
