package FunctioalInterface_lambdas2;

public class Application1_usual {
	public static void main(String[] args) {
		
		AlambdaInterface helloVar = () -> System.out.println("hello variable");
		helloVar.run();
	}

	//consider there are some functional interfaces (below); you can implement them as usual as below; but since it is functional interface
	//you need to implement using lambda similar to a sample demonstrated in above main function
	
	// for all the methods below we have replaced them with lambda expression which you can see them in the next next java files
	
	public void run() {
		System.out.println("hello...");
	}
	
//---------------------------------------------------------	

	public int sum(int a, int b) {
		return a + b;
	}

	public int nonZeroDivide(int a, int b) {
		if (a == 0) {
			return a;
		}
		return a / b;
	}
//---------------------------------------------------------
	public String reverseString(String str) {
		String result = " ";
		for (int i = str.length() - 1; i >= 0; i--) {
			result += str.charAt(i);
		}
		return result;
	}
	
	public int factorial(int n)
	{
		int result=1;
		for(int i=1;i<=n;i++)
		{
			return result=i*result;
		}
		return result;
	}

	
}	//class ends here

//---------------------------------------------------------
interface AlambdaInterface {
	public void run();
}

//----------------------------------
interface Calculate1 {
	public int sum(int a, int b);
}

interface Calculate2 {
	public int nonZeroDivide(int a, int b);
}
//----------------------------------

interface StringWorker1 {
	public String reverseString(String rev);
}

interface Factorial {
	public int factorial(int n);
}

//----------------------------------


