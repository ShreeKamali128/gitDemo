package FunctioalInterface_lambdas2;

public class Application3_lambda_SameDataType {
	public static void main(String[] args) {

		//example 1
		Calculates sum = (a, b) -> a + b; // method implementation
		System.out.println(sum.calculate(10, 20)); // method calling/definition

		//example 2
		Calculates nonZeroDivide = (a, b) -> {
			if (a == 0) {
				return a;
			}
			return a / b;
		};
		System.out.println(nonZeroDivide.calculate(10, 5));
	}
}

interface Calculates {
	public int calculate(int a, int b);
}