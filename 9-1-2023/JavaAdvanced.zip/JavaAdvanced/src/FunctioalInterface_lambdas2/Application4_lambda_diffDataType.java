package FunctioalInterface_lambdas2;

public class Application4_lambda_diffDataType {
	
	public static void main(String[] args) {		
		
		StringWorkers stringLambda = (s) -> {
			String result = "";
			for (int i = s.length() - 1; i >= 0; i--) {
				result += s.charAt(i);
			}
			return result;
		};
		System.out.println(stringLambda.someMeth("Mala"));
		
		
		
		CalculateFacts factorial = (n) -> {
			int result=1;
			for(int i=1;i<=n;i++)
			{
				result=i*result;
			}
			return result;
		};
		System.out.println(factorial.calculate(5));
	}

}


interface StringWorkers {
	public String someMeth(String rev);
}

interface CalculateFacts {
	public int calculate(int a);
}

