package FunctioalInterface_lambdas2;

public class Application5_lambda_generic_datatype {
	public static void main(String[] args) {

		MyGenericIntrfcs<String> stringLambda = (s) -> {
			String result = "";
			for (int i = s.length() - 1; i >= 0; i--) {
				result += s.charAt(i);
			}
			return result;
		};
		System.out.println(stringLambda.process("Mala"));
		
		MyGenericIntrfcs<Integer> factorial = (n) -> {
			int result=1;
			for(int i=1;i<=n;i++)
			{
				result=i*result;
			}
			return result;
		};
		System.out.println(factorial.process(5));
	}

	
}

//can replace the two interfaces CalculateFact and StringWorker with one argument as generic ones
interface MyGenericIntrfcs<T>{
	public T process(T t);
}

