package EncapsulationDemo;

public class Employee extends Person{

	private int empId;
	

	public int getEmpId() {
		return this.empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	

	

}
