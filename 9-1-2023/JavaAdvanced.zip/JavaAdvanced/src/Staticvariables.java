
public class Staticvariables {

	String name;   //instance variables
	String address;
	int j=0; 
	static int i; 
	static String city;   //static/class variables gets updated across objects if any changes made
	static		//static block
	{
		city="TN";
		i=0;
	}
	
	public Staticvariables()
	{
		
	}
	public Staticvariables(String name, String address)
	{
	this.name=name;
	this.address=address;
	i++;
	j++;
	System.out.println(i+ " "+ j);
	
	}
	
	public void getData()
	{
		System.out.println(name + " " +address + " " + city);
	}
	
	//static method
	public static void getCity()
	{
		System.out.println(city);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Staticvariables sv= new Staticvariables("Ram","Tanjore");
		Staticvariables sv1= new Staticvariables("Kayal","Trichy");
	
		Staticvariables.i=5;
		System.out.println(Staticvariables.i);
		Staticvariables svv= new Staticvariables();
		svv.j=8;
		System.out.println(svv.j);
		
		sv.getData();
		sv1.getData();
		Staticvariables.getCity(); //static method invoke
		
		Staticvariables.city="Banglore";
		Staticvariables.getCity(); //updated city printed
		
		sv.address="Madurai";
		sv.getData();
		sv1.getData();
	}

}
