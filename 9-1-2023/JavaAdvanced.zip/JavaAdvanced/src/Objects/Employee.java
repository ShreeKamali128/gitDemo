package Objects;

public class Employee {

		private int id;
		private String name;
		
		//here getter setter method used to access private fields outside the class
		
		public Employee()
		{
			
		}
		
		public Employee(int id, String name) {
			setId(id);
			setName(name);
		}
		
		public int getId() {
			return id;
		}
		public String getName() {
			return name;
		}
		public void setId(int id) {
			this.id = id;
		}
		public void setName(String name) {
			this.name = name;
		}
		
		public boolean equals(Object o)
		{
			//null or not of same class
			if(o== null || this.getClass() !=o.getClass())		
				return false;
			
			//shares same memory allocation
			 if(o==this)
				 return true;
			 
			 Employee e = (Employee)o;
			 return (this.getId()==e.getId());
			
		}
		
		//we should override the hashcode method inorder to store the employee objects e1 and e2 in main class which are logically the same objects, in same memory 
		public int hashCode()
		{
		 return this.getId();		
		}

}
