package Objects;

public class HashCode_Equals_Contract {

	public static void main(String[] args) {
	
		//way 1
//		Employee e1= new Employee();
//		e1.setId(1);
//		e1.setName("Shri");
		
		//way 2---not directly calling the set method, instead passing to constructor nd calling there set method
		Employee e1= new Employee(1, "Shri");
		System.out.println(e1.getId() + " " + e1.getName());
		
		Employee e2= new Employee();
		e2.setId(1);
		e2.setName("Shri");
		System.out.println(e1.getId() + " " + e1.getName());

		
		System.out.println("shallow compare: "+ (e1==e2));
		System.out.println("deep compare: "+ e1.equals(e2));

	}

}
