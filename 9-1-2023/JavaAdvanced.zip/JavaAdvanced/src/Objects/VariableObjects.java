package Objects;

public class VariableObjects {

	public static void main(String[] args) {
//boolean, byte, character, short, integer, long, float, double
		getTypeName(1);
		getTypeName(5L);
		getTypeName(9.2f);
		getTypeName("Happy");
		getTypeName(2.2d);

		
	}
	
	public static void getTypeName(Object o)
	{
		if(o instanceof Integer)
			System.out.println(o + " is of int type");
		
		else if(o instanceof Long)
			System.out.println(o + " is of long type");
		
		else if(o instanceof Float)
			System.out.println(o + " is of float type");
		
		else if(o instanceof String)
			System.out.println(o + " is of String type");
		
		else
			//getClass---return the class object of this object
			System.out.println(o+" is of "+ o.getClass().getTypeName() + " type");
	}

}
