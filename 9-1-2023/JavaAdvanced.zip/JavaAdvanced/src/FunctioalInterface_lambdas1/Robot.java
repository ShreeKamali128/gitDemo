package FunctioalInterface_lambdas1;

public class Robot implements WalkableFI{

	@Override
	public void walk() {
		System.out.println("robot also walks....");
	}

}
