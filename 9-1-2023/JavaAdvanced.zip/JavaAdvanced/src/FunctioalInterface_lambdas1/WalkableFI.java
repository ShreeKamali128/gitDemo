package FunctioalInterface_lambdas1;



//it is a functional interface since it has exactly one abstract method
//by default it has public abstract void walk();
@FunctionalInterface		//makes sure that it has only one abstract method
public interface WalkableFI {
	public void walk();

}
