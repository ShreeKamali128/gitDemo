package FunctioalInterface_lambdas1;

public class Human implements WalkableFI{

	@Override
	public void walk() {
		System.out.println("Human walks...");
		
	}

}
