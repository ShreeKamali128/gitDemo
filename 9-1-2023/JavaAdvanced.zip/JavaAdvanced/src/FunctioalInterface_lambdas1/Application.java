package FunctioalInterface_lambdas1;

public class Application {
	public static void main(String[] args) {

		Human hum = new Human();
		walker(hum);

		walker(new Robot());

		// anonymous
		walker(new WalkableFI() {
			@Override
			public void walk() {
				System.out.println("anonymous implementation..");
			}
		});

		// lambda implementation
		walker(() -> {
			System.out.println("lambda expression implementation...");
			System.out.println("yess it is...");
		});

		// a lambda expression created and assigned to a variable of type 'Functional
		// Interface' which means that the interface must contain only one abstract
		// method
		WalkableFI aBlockOfCode = () -> {
			System.out.println("lambda epression implementation...");
		};
		walker(aBlockOfCode);
	}

	public static void walker(WalkableFI intrfc_obj) {
		intrfc_obj.walk();
	}

}