package FunctioalInterface_lambdas3;

//wrong implementation; method calling not possible
interface Cab{
	public abstract double booking(String src, String dest);	//can be void and no param or one param
}

public class Capturing_variables {

	int instncVar=10;
	static int staticVar=20;
	public static void main(String[] args) {
	
	}
	
	Cab cab=(src, dest)->{
		int localVar=30;
		System.out.println("local var is: "+ localVar);
		System.out.println("instance var is: "+ instncVar);
		System.out.println("static var is: "+ staticVar);
		System.out.println("Cab is booked from "+ src + " to "+ dest);
		return 825.50;
	};
	
	//cab.booking("bang", "kmu");
}

