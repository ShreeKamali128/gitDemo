package FunctioalInterface_lambdas3;

import java.util.Arrays;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

public class Built_in_functnal_Intrfc {

	public static void main(String[] args) {

		List<Car> cars = Arrays.asList(new Car("Honda", "Accord", "Red", 22000),
				new Car("Toyota", "Civic", "Black", 24500), new Car("Honda", "Corolla", "Blue", 17000),
				new Car("Toyota", "Camry", "White", 18000), new Car("Honda", "Land Rover", "Red", 25000));

/*		printCarsbyRange(cars, 18000, 23000);
		printCarsbyColor(cars, "Red");
		
	}
	public static void printCarsbyRange(List<Car> cars, int low, int high) {
		for (Car c : cars) {
			if (c.getPrice() >= low && c.getPrice() <= high)
				c.printCar();
		}
	}

	public static void printCarsbyColor(List<Car> cars, String color) {
		for (Car c : cars) {
			if (c.getColor().equals(color))
				c.printCar();
		}

	}
*/
		//alliter2
/*		System.out.println("Printing cars between price range...");
		printByConditions(cars, new Condition() {

			@Override
			public boolean test(Car c) {
				return c.getPrice()>=18000 && c.getPrice()<25000;
			}	
		});
		
		System.out.println("Printing cars of particular color...");
		printByConditions(cars, new Condition() {

			@Override
			public boolean test(Car c) {
				return c.getColor().equals("Red");
			}	
		});
		
	}
	
	public static void printByConditions(List<Car> cars, Condition condition) {
		for (Car c : cars) {
			if (condition.test(c)) {
				c.printCar();
			}
		}
	}
	
	*/

		
	//alliter3
	printByConditions(cars, (c) -> c.getPrice()>=18000 && c.getPrice()<25000);
	printByConditions(cars, (c) -> c.getColor().equals("Red"));
	}	//main
	
	public static void printByConditions(List<Car> cars, Condition<Car> condition) {		//you can replace condition with predicate which is inbuilt functional interface
	//public static void printByConditions(List<Car> cars, Predicate<Car> condition) {		//if this line used no need below interface definition
		for (Car c : cars) {
			if (condition.test(c)) {
				c.printCar();
			}
		}
	}
	
	/*	
	//to access List of cars using java.util.function
	Function <Car, String> price_Color = (c) -> "Price: " + c.getPrice() + " Color: " + c.getColor();
	String stringCar= price_Color.apply(cars.get(4));
	System.out.println(stringCar);
	}//main		
	
	*/
}

//must for all types except 1st
@FunctionalInterface
interface Condition<T> {
	public boolean test(T t);
}