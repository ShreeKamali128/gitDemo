package JavaIO;

import java.io.*;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.Enumeration;
import java.util.Vector;

public class SequenceStream {

	public static void main(String[] args) throws Exception {
		try
		{
		FileInputStream fis= new FileInputStream("C:\\Users\\SH20204415\\eclipse-workspace\\Selenium\\JAVADemo\\src\\JavaIO\\FileInput1.txt");
		FileInputStream fis1= new FileInputStream("C:\\Users\\SH20204415\\eclipse-workspace\\Selenium\\JAVADemo\\src\\JavaIO\\FileInput2.txt");
		FileInputStream fis2= new FileInputStream("C:\\Users\\SH20204415\\eclipse-workspace\\Selenium\\JAVADemo\\src\\JavaIO\\FileInput3.txt");
		
		Vector<FileInputStream> v= new Vector<FileInputStream>();
		v.add(fis);
		v.add(fis1);
		v.add(fis2);
		
		Enumeration<FileInputStream> e= v.elements();
		// if two input files, directly give in sequence stream or else create vector and pass it as enumerator
		SequenceInputStream sis= new SequenceInputStream(e);
		FileOutputStream fos= new FileOutputStream("C:\\Users\\SH20204415\\eclipse-workspace\\Selenium\\JAVADemo\\src\\JavaIO\\FileOutput.txt");
		
		int i=0;
		while( (i=sis.read())!=-1 )
			{fos.write(i);
			System.out.print((char)i);
			}
		System.out.println();
		sis.close();
		fos.close();
		fis.close();
		fis1.close();
		System.out.println("written successfully...");
		}
		
		catch(Exception e)
		{
			System.out.println("Access denied");
		}
	}

}
