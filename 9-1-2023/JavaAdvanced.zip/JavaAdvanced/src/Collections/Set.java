package Collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.TreeSet;

public class Set {

	public static void main(String[] args) {

		HashSet<String> set1=new HashSet<String>();  
        set1.add("Ravi");  
        set1.add("Vijay");  
        set1.add("Arun");  
        set1.add("Sammit");  
        System.out.println(set1); 
        
        HashSet<String> set2=new HashSet<String>();  
        set2.add("Ajay");  
        set2.add("Gaurav"); 
        
        
//       //Removing specific element from HashSet  
//        set1.remove("Ravi");  
//        System.out.println("After invoking remove(object) method: "+set1);  
//        
//       // merge 2 sets
//        set1.addAll(set2);  
//        System.out.println("Updated List: "+set1);  
//       
//        
//        //Removing (all the new elements from HashSet) one set of elements from another 
//        set1.removeAll(set2);  
//        System.out.println("removeAll(): "+set1);  
//        
//        //Removing elements on the basis of specified condition  
//        set1.removeIf(str->str.contains("Vijay"));    
//        System.out.println("After invoking removeIf() method: "+set1); 
//        
//        //Removing all the elements available in the set  
//        set1.clear();  
//        System.out.println("After invoking clear() method: "+set1);  
//  	  

   /*
        //sorting set
        //1. converting set to array list and sorting
        //2. using tree set
        //3. using streams
        
        //1
        ArrayList<String> al = new ArrayList<String>();
        for(String s: set1)
        {
        	al.add(s);
        }
        
        System.out.println("set converted to list: ");
        al.forEach(x-> System.out.println(x));
        
       // al.sort(null); 				//here need to pass comparator to know in what way to sort
       // System.out.println("al.sort():	 " + al);
        
        Collections.sort(al);
        System.out.println("Collections.sort():		" + al);
        
        for(String s: al)
        {
        	System.out.println(s);
        }
        
        
        //tree set
        TreeSet<String> ts = new TreeSet<>();
        ts.addAll(set1);
        
        System.out.println("Treeset is:  ");
        for(String s: ts)
        {
        	System.out.println(ts.ceiling(s));
        	//System.out.println(ts.floor(s));
        }
        
        */
	}
}
