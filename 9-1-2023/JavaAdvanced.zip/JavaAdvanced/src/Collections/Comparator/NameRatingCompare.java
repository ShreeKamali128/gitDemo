package Collections.Comparator;

import java.util.Comparator;

public class NameRatingCompare implements Comparator<Movie> {

	
	public int compare(Movie m1, Movie m2) {
		//return m1.getName().compareTo(m2.getName());
		
		int NameCompare = m1.getName().compareTo(m2.getName());
		int RatingCompare = m1.getRating().compareTo(m2.getRating());
		return (NameCompare==0)?RatingCompare : NameCompare;
		
	}

}
