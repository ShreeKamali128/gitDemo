package Collections.Comparator;

public class Movie implements Comparable<Movie> {
	
	String name;
	int rating;
	
	public Movie(String name, int rating)
	{
		this.name=name;
		this.rating=rating;
	}
	

	public String getName()
	{
		return name;
	}
	
	public Integer getRating()
	{
		return rating;
	}

	public int compareTo(Movie m) {
		return this.rating - m.rating ;
	}
}
