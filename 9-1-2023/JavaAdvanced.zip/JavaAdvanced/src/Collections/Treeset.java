package Collections;

import java.util.Iterator;
import java.util.TreeSet;

public class Treeset {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 TreeSet<Integer> al=new TreeSet<Integer>();  
		  al.add(1); 
		  al.add(2);  
		  al.add(3);  
		  al.add(4); 

		  
		  //different iterations  
//		  Iterator<Integer> itr=al.iterator();  
//		  while(itr.hasNext())
//			  System.out.println(itr.next());  
//		  
//		  
//		  Iterator<Integer> it= al.descendingIterator();
//		  while(it.hasNext())  
//			  System.out.print(it.next()+ "\t"); 
//		 
//		  
		  //different methods is TreeSet class
		  System.out.println(al.ceiling(0)+ "\n"+ al.floor(5) + "\n" + al.higher(1)  +
				  "\n" + al.lower(4) + "\n" + al.first() + "\n" + al.last() + "\n" + al.headSet(4)
				  + "\n"+ al.tailSet(1));
		  System.out.println(al.subSet(1, 4));    //[1,2,3,4)
		  
		  
	

	}

}
