package Collections.Comparable;

import java.util.ArrayList;
import java.util.Collections;

public class ComparableDemoMain {

	public static void main(String[] args) {
		
		ArrayList<Movie> al= new ArrayList<Movie>();
		al.add(new Movie("Ram",23) );
		al.add(new Movie("Tina", 28));
		
		Collections.sort(al);  	//it automatically invokes compareTo to sort

		for(Movie i: al)
		{
			System.out.println(i.getName() + "   "+ i.getAge());
		}
	}

}
