package Collections.Comparable;

class Movie implements Comparable<Movie> {

	String name;
	int age;
	
	public Movie(String name, int age)
	{
		this.name=name;
		this.age=age;
	}


	//Note: The logic of sorting must be in the same class whose object you are going to sort.

	public int compareTo(Movie lc) {
		if(age==lc.getAge())			//natural sorting ie alphabetical order or numerical order
		   return 0;
		else if(age>lc.age)
			return 1;
		else
			return -1;
	}
	
	public String getName()
	{
		return name;
	}

	public int getAge()
	{
		return age;
	}
	
	
}
