package Collections;

import java.util.NavigableMap;
import java.util.SortedMap;
import java.util.TreeMap;

public class TreeMapDemo {

	public static void main(String[] args) {
		
		NavigableMap<Integer,String> mp= new TreeMap<Integer,String>();
		mp.put(0, "hi");
		mp.put(5, "good");
		mp.put(22, "morning");
		
		System.out.println(mp.headMap(5));			//less than 5 only no 5 itself if 5 needed include true
		System.out.println(mp.tailMap(5,true));
		System.out.println(mp.subMap(0, true, 5, true));
		System.out.println(mp.subMap(0, 5));
		System.out.println(mp.descendingMap());
		System.out.println(mp.firstEntry() + "\n"+ mp.firstKey());
		System.out.println(mp.higherEntry(5)+ "\n" + mp.higherKey(5)); 			//greater than nearest element
		System.out.println(mp.ceilingEntry(5)+ "\n"+ mp.ceilingKey(22));			//greater than or equal nearest elemnt
		
		mp.replaceAll((k,v)->"good");
		boolean b1=mp.containsKey(0);
		boolean b2=mp.containsValue("good");
		mp.forEach((k,v)->System.out.println(k + "   "+ v));
		System.out.println(mp.toString() + "\n"+ b1 + "\t"+ b2);
		
		
		/*
		SortedMap<Integer,String> smp= new TreeMap<Integer,String>();
		smp.put(0, "hi");
		smp.put(5, "good");
		smp.put(22, "morning");
		
		System.out.println(smp.headMap(5));
		System.out.println(smp.tailMap(0));
		System.out.println(smp.subMap(0, 22));
		System.out.println(smp.getOrDefault(22, null));
		*/

	}

}
