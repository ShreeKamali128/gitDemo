package Collections;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;


public class Arraylist {

	public static void main(String[] args) {

		List<String> l= new ArrayList<String>(10);
		
		l.add("Hi");
		l.add("How");
		l.add("Are");
		l.add("You?");
		l.add("Hi");
	
		/*
		//methods in Arraylist
		System.out.println("1st element is: "+l.get(0));
		System.out.println(l.toString());					//printing list
		System.out.println(l.size());
		
		//Iterations
		ListIterator<String> ls= l.listIterator(l.size());
		while(ls.hasPrevious())
			{
			System.out.println(ls.previous());
			System.out.println(ls.previousIndex());
			}
		*/
		/*
		//different iterations
		 
		//by iterator interface
		Iterator<String> itr =l.iterator();
		while(itr.hasNext())
			System.out.println(itr.next());
		
		//by ListIterator interface-------prints in reverse order
		ListIterator<String> ls= l.listIterator(l.size());
		while(ls.hasPrevious())
			System.out.println(ls.previous());
			
		//by forEachRemaining() method
		Iterator<String> itr= l.iterator();
		itr.forEachRemaining(a->{
			System.out.println(a);
		});
			
		//for loop
		for(int j=0;j<l.size();j++)
			System.out.println(l.get(j));
			
		//for-each
		 for(String i: l)
		    System.out.println(i);
		    
		//foreach() method
		l.forEach(x ->{System.out.println(x);}
		);
		
		
		*/
		
		
		
		/*
		
		//sorting array list using Collections class
//		Collections.sort(l);	           
//		System.out.println(l);
//		//reversing array list
//		Collections.reverse(l);
//		System.out.println(l.toString());
		
		//sort and reverse in single line
		Collections.sort(l,Collections.reverseOrder());               
		System.out.println(l);
		
		//sorted using array
		System.out.println("Arrays sort in ascending order: ");
		Object[] obj=l.toArray();
		Arrays.sort(obj);
		System.out.println(Arrays.toString(obj));
		*/
		

		 
		 //to remove duplicate element in AL-------convert to set
	/*	 Set<String> s = new LinkedHashSet<String>(l);  
		 System.out.println(s);
	*/	 
		
		
		/*
		//to convert arraylist to synchronized list
		Collections.synchronizedList(l);               	   //prints in insertion order
		synchronized(l){  								  //synchronized block to avoid non deterministic behaviour
			Iterator<String> itr =l.iterator();
			while(itr.hasNext())
				System.out.println(itr.next());
		}
		*/
		
		
		//Different ways to convert arraylist to array
		//1. actual & familiar method 
	/*	String[] ar= new String[l.size()];
		ar= l.toArray(ar);                //String[] ar=l.toArray(new String[l.size()]);   //alternative to above 2 step
		for(String s1: ar)
			System.out.println(s1);
	*/	
		//2. as object array
	/*	Object[] obj = l.toArray();
		
		for(Object o: obj)
			System.out.println(o);
	*/
		//3.using manual conversion using for loop
	/*	String[] ar= new String[l.size()];
		
		for(int i=0;i<ar.length;i++)
		{
			ar[i]=l.get(i);
		}
		
		for(String ss: ar)
			System.out.println(ss);
	*/
		//using streams
		//int[] a1= l.stream().mapToInt(i->i).toArray();   input here is string no method like maptostring so confused
		
		
		
		//different ways of Conversion of AL to set
	
/*		ArrayList<String> colorsList = new ArrayList<String>(Arrays.asList("Red", "Green", "Blue", "Cyan", "Magenta", "Yellow")); 
        //1. using iterative method
        Set<String> hSet = new HashSet<String>(); 
        for (String x : colorsList) 
            hSet.add(x);   
        System.out.println(hSet);
        
        //2.using addAll method
       Set<String> hSet1 = new HashSet<String>(); 
       hSet1.addAll(colorsList);   
       System.out.println(hSet1);   
    
       //3.using constructor method
       Set<String> hSet2 = new TreeSet<String>(colorsList);        
   	   System.out.println(hSet2);
   	   
   	   //4. using stream() method
   	   Set<String> set = colorsList.stream().collect(Collectors.toSet()); 
   	   System.out.println(set); 
   	 */  
   	   
       
    	

		
	}

}
