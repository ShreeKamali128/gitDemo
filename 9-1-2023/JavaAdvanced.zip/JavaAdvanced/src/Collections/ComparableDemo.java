package Collections;

class ComparableDemo implements Comparable<ComparableDemo> {

	String name;
	int age;
	
	public ComparableDemo(String name, int age)
	{
		this.name=name;
		this.age=age;
	}


	public int compareTo(ComparableDemo lc) {
		if(age==lc.age)			//natural sorting ie alphabetical order or numerical order
		   return 0;
		else if(age>lc.age)
			return 1;
		else
			return -1;
	}
	
	public String getName()
	{
		return name;
	}

	public int getAge()
	{
		return age;
	}
	
	
}
