package Collections;

import java.util.ArrayList;
import java.util.Collections;

public class ComparableDemoMain {

	public static void main(String[] args) {
		
		ArrayList<ComparableDemo> al= new ArrayList<ComparableDemo>();
		al.add(new ComparableDemo("Ram",23) );
		al.add(new ComparableDemo("Tina", 28));
		
		Collections.sort(al);  	//it automatically invokes compareTo to sort

		for(ComparableDemo i: al)
		{
			System.out.println(i.getName() + "   "+ i.getAge());
		}
	}

}
