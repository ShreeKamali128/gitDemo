package Collections;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class LinkedHshMapObjects {
	
	String name;
	int age;
	static String state="TN";
	
	public LinkedHshMapObjects(String name, int age)
	{
		this.name=name;
		this.age=age;
	}

	public static void main(String[] args) {
		
		LinkedHshMapObjects lm1=new LinkedHshMapObjects("Ram", 24);
		LinkedHshMapObjects lm2=new LinkedHshMapObjects("Jaan", 34);
		LinkedHshMapObjects lm3=new LinkedHshMapObjects("Shri", 56);
		
		LinkedHashMap<Integer,LinkedHshMapObjects> mp= new LinkedHashMap<Integer, LinkedHshMapObjects>();
		mp.put(0, lm1);
		mp.put(1, lm2 );
		mp.put(2, lm3 );
		
		//using different iterations
		//1
		Iterator<Integer> itr=mp.keySet().iterator();
		while(itr.hasNext())
		{
			int key=(int)itr.next();
			System.out.println(key +  "    "+  mp.get(key).name + "  " + mp.get(key).age + "   "+ mp.get(key).state);
		}
		
		//2
		for(Map.Entry<Integer,LinkedHshMapObjects> entObj: mp.entrySet())
		{
			int key=entObj.getKey();
			LinkedHshMapObjects value= entObj.getValue();     //mp.get(key);
			System.out.println(value.name + "    "+ value.age + "   "+ value.state);
		}
		
		
	}
}