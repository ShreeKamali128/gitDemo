package Is_Has_Relationship;

public class Car {

	private int maxSpeed;
	private String Color;
	

	public void carInfo()
	{
		System.out.println(this.maxSpeed+"\n"+this.Color);
	}
	public void setMaxSpeed(int maxSpeed) {
		this.maxSpeed = maxSpeed;
	}
	public void setColor(String color) {
		Color = color;
	}
	
	
}
