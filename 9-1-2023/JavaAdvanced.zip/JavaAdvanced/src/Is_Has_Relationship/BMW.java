package Is_Has_Relationship;

public class BMW extends Car {
	
	public void BMWStart()
	{
		Engine engine= new Engine();
		engine.stopCar();
	}

}
