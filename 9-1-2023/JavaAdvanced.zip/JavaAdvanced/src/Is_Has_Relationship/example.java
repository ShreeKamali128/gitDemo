package Is_Has_Relationship;

public class example {
	
	public static void main(String[] args) {
		BMW obj=new BMW();
		obj.setColor("green");
		obj.setMaxSpeed(230);
		obj.carInfo();
		
		obj.BMWStart();
	}

}
