package Is_Has_Relationship;

public class Engine {
	
	public void startCar()
	{
		System.out.println("started..");
	}
	
	public void stopCar()
	{
		System.out.println("stopped..");
	}


}
