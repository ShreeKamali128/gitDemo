package Threadss.Collection;


public class Application {

	public static void main(String[] args) throws InterruptedException {
		InventoryManager im= new InventoryManager();
		
		Thread inventoryTask=new Thread(new Runnable() {
			public void run()
			{
				im.populateSoldProducts();
			}
		});
		
		Thread displayTask=new Thread(new Runnable() {
			public void run()
			{
				im.displaySoldProducts();
			}
		});
		
		inventoryTask.start();
	//	Thread.sleep(2000); //here wait is not used since it raise exception saying the collection soldProductlist is used by first
	//	thread populate and so another thread cannot use it to display
	//	so join is used to inform the main thread that wait until 1st thread joins with you and then you proceed to sequential threads
	//	inventoryTask.join();
		Thread.sleep(2000);
		displayTask.start();
	}

}
