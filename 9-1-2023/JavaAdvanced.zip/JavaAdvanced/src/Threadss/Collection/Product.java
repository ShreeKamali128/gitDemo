package Threadss.Collection;

public class Product {
	
	String name;
	int id;
	
	public Product(String name, int id) {
		this.name = name;
		this.id = id;
	}
	
	public String toString()
	{
		return "id "+ id + " "+ "name "+ name;
	}
	

}
