package Threadss.Collection;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class InventoryManager {

	List<Product> soldProductsList = new CopyOnWriteArrayList<Product>();
	List<Product> purchasedProductsList = new ArrayList<Product>();
	
	public void populateSoldProducts()
	{
		for(int i=0;i<50;i++)
		{
			Product prod = new Product("test_product"+ i, i);
			soldProductsList.add(prod);
			try {
				Thread.sleep(i);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void displaySoldProducts()
	{
		for(Product p:soldProductsList)
		{
			System.out.println(p);
			try {
				Thread.sleep(10);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}
