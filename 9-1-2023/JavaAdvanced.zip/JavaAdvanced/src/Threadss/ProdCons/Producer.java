package Threadss.ProdCons;

import java.util.List;

public class Producer implements Runnable {
	List<Integer> quetionList = null;
	private int quetionNo;
	final int LIMIT = 5;

	public Producer(List<Integer> quetionList) {
		this.quetionList = quetionList;
	}

	public void readQuetions(int quetionNo) throws InterruptedException {
		synchronized (quetionList) {
			while (quetionList.size() == LIMIT) {
				System.out.println("piled up quetions..please wait until it clears...");
				quetionList.wait();
			}
		}

		synchronized (quetionList) {
			System.out.println("New Quetion: " + quetionNo);
			quetionList.add(quetionNo);
			Thread.sleep(100);
			quetionList.notify();
		}
	}

	@Override
	public void run() {

		while (true) {
			try {
				readQuetions(quetionNo++);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}
