package Threadss.ProdCons;

import java.util.List;

public class Consumer implements Runnable {
	List<Integer> quetionList = null;

	final int LIMIT = 5;

	public Consumer(List<Integer> quetionList) {
		this.quetionList = quetionList;
	}

	public void answerQuetions() throws InterruptedException {
		synchronized (quetionList) {
			while (quetionList.isEmpty()) {
				System.out.println("No quetion to answer...waiting for producer to produce quetions");
				quetionList.wait();
			}
		}

		synchronized (quetionList) {
			Thread.sleep(5000);
			System.out.println("Answered Quetion: " + quetionList.remove(0));
			quetionList.notify();
		}
	}

	@Override
	public void run() {

		while (true) {
			try {
				answerQuetions();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}
