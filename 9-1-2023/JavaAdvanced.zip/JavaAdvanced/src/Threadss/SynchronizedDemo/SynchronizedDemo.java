package Threadss.SynchronizedDemo;

public class SynchronizedDemo {
	
	private int val=0;
	
	public synchronized int count()
	{
		val=val+1;
		return val;
	}

}
