package Threadss.SynchronizedDemo;

public class Application {

	public static void main(String[] args) {
		
		SynchronizedDemo obj= new SynchronizedDemo();
//		obj.count();
		
		Worker wor1=new Worker(obj);
		wor1.start();
		
		Worker wor2=new Worker(obj);
		wor2.start();
		
		
	}
}

class Worker extends Thread
{

	SynchronizedDemo obj=null;
	
	public Worker(SynchronizedDemo obj)
	{
		this.obj =obj;
	}
	public void run()
	{
		for(int i=0;i<10;i++)
		{
			System.out.println(Thread.currentThread().getName()+ " "+" value is: "+ obj.count() );
		}
		try {
			Thread.sleep(10);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
	}
}