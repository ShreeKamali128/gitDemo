package Threadss;

public class Demo1 {

	public static void main(String[] args) {

		Task task1 = new Task("Thread1");
		task1.start();
		
		Task task2 = new Task("Thread2");
		task2.start();
	}

}

class Task extends Thread {
	String name;
	public Task(String name) {
		this.name=name;
	}

	public void run() {
		Thread.currentThread().setName(this.name);
		for (int i = 0; i < 10; i++) {
			System.out.println(i+ " "+ Thread.currentThread().getName());
			try {
				Thread.sleep(10);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}