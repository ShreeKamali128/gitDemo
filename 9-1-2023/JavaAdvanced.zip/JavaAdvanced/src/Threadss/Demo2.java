package Threadss;

public class Demo2 {

	public static void main(String[] args) {

		
		/*
		 * //passing functionality as argument
		 * Runnable task1= new Runnable()
		 *  { public void run() {
		 * System.out.println("inside run of runnable using anonymous class"); }
		 *  };
		 */
		Task1 task1 = new Task1("Thread1");
		Thread t1 = new Thread(task1);		
		t1.start();
		
		Task1 task2 = new Task1("Thread2");
		Thread t2 = new Thread(task2);
		t2.start();
	}

}

class Task1 implements Runnable {
	String name;
	
	public Task1(String name) {
		this.name=name;
	}

	public void run() {
		Thread.currentThread().setName(this.name);
		for (int i = 0; i < 10; i++) {
			System.out.println(i+ " "+ Thread.currentThread().getName());
			try {
				Thread.sleep(10);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}