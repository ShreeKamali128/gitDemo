package AbstractionDemo.AbstractClass;

public class Student extends Person {
	
	private int id;
	
	public Student(String name, String gender, int id) {
	
		super(name, gender);
		this.id=id;
	}


	public void studying()
	{
		if(this.id==0)
			System.out.println("not studying");
		else
			System.out.println("pursuing mba");
	}
	
	public static void main(String[] args) {
		Person p= new Student("shri", "M", 202);
		Person p1= new Student("ram", "M", 203);
		Person p2= new Student("hari", "M", 232);
		p.studying(); p1.studying(); p2.studying();

	}
	
	
	

}
