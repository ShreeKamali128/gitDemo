package AbstractionDemo;

import Inheritance.Sinlge.bChildClass;

public abstract class Shapes {

	String color;

	abstract double area();

	public abstract String toString();

	public Shapes(String color) {
		System.out.println("Shape constructor called");
		this.color = color;
	}

	// this is a concrete method
	public String getColor() {
		return color;
	}

}
