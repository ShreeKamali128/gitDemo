package AbstractionDemo.Interface;

public class bRectangle implements aShapes {

	double length;
    double width;
 

	public bRectangle( double length, double width) {
		this.length = length;
		this.width = width;
	}

	@Override
	public double area() {
		return (double)(length*width);
	}

	@Override
	public void draw() {
	System.out.println("rectangle drawn");
	}

}
