package AbstractionDemo.Interface;


public interface aShapes {

	public void draw();
	public double area();

}
