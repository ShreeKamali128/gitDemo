package AbstractionDemo.Interface;

public class cCircle implements aShapes {

	double radius;
	

	public cCircle( double radius) {
		
		this.radius = radius;
	}

	@Override
	public double area() {
		return (Math.PI * Math.pow(radius, 2))/2;
	}

	@Override
	public void draw() {
		System.out.println("circle drawn");
	}
	
	

	

}
