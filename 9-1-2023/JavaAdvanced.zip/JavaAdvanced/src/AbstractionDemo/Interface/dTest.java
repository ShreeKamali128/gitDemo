package AbstractionDemo.Interface;

import AbstractionDemo.Interface.*;

public class dTest {

	public static void main(String[] args) {

		aShapes s1 = new cCircle(20);
		aShapes s2 = new bRectangle(20,30);

		s1.draw(); 
		double arCir=s1.area();
		System.out.println(arCir);
		s2.draw();
		double arRec=s2.area();
		System.out.println(arRec);
		

		/*
		 * one of the important concepts is:
		 * 
		 * It reduces the complexity of viewing things. Avoids code duplication and
		 * increases reusability. Helps to increase security of an application or
		 * program as only important details are provided to the user.
		 */

		/*
		 * Types of Abstraction: There are basically three types of abstraction
		 * 
		 * Procedural Abstraction
		 *  Data Abstraction 
		 *  Control Abstraction
		 */
	}

}
