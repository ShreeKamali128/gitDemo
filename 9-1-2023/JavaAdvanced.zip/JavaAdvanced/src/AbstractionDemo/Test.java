package AbstractionDemo;

public class Test {

	public static void main(String[] args) {

		Shapes s1 = new Circle("Red", 2.2);
		Shapes s2 = new Rectangle("Yellow", 2, 4);

		System.out.println(s1.color + " " + s1.area());
		System.out.println(s1.toString());
		System.out.println(s1); // s1 internally calls toString() method so only overridden it is helpful
		System.out.println(s2.toString());

		/*
		 * one of the important concepts is:
		 * 
		 * It reduces the complexity of viewing things. Avoids code duplication and
		 * increases reusability. Helps to increase security of an application or
		 * program as only important details are provided to the user.
		 */

		/*
		 * Types of Abstraction: There are basically three types of abstraction
		 * 
		 * Procedural Abstraction
		 *  Data Abstraction 
		 *  Control Abstraction
		 */
	}

}
