package Skin;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;


public class _SkinPOManager {
	
	//private WebDriver driver;
	private aFiltersPC f;
	private bProductListingPC pl;
	
	
	public _SkinPOManager(final WebDriver driver) {
	//	this.driver = driver;
		this.f = PageFactory.initElements(driver, aFiltersPC.class);
		this.pl = PageFactory.initElements(driver, bProductListingPC.class);
		
	}

	public aFiltersPC getFiltersPC() {
		return f;
	}

	public bProductListingPC getProductListingPC() {
		return pl;
	}

}
