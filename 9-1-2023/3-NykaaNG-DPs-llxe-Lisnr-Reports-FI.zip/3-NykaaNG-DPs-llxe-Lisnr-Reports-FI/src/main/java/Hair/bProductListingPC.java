package Hair;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import _common.AbstractComponent;
import _common.Functionalinterface;

public class bProductListingPC extends AbstractComponent{



	
	@FindBy(css = "[class*='productWrapper']:nth-child(1) a")
	WebElement product;
	
	
	public bProductListingPC(WebDriver driver) {
		super(driver);
	}

	
	public void productClick() throws Exception
	{
		product.click();
		switchWindow();
		sleepMethod();
	}
	
	public boolean isDisplayedFI() {
		Functionalinterface fi = () -> this.w.until( (d)-> product.isDisplayed() );
		return fi.isDisplayed();
	}
	
	

}
