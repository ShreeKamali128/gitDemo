package Hair;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import _common.AbstractComponent;
import _common.Functionalinterface;

public class cSingleProductPC extends AbstractComponent
{
	
	public static String topRatedProduct =null;
	
	
	@FindBy(css = ".css-1gc4x7i")
	WebElement prodh1;


	@FindBy(xpath = "(//span[@class='btn-text'])[1]")
	WebElement addToBag;
	
	//correct--"//*[@class='css-yp84h4']"
	//wrong--(//*[@class=' css-12z4fj0']/span[@class='btn-text'])[1]
	@FindBy(xpath = "//*[@class='css-yp84h4']")
	WebElement addedToBagText;
	
	
	@FindBy(xpath = "//*[@id='add-to-cart-prompt']//*[contains(text(),'Added')]")
	WebElement addedToBagPrompt;
	
	
	public cSingleProductPC(WebDriver driver) {
		super(driver);
	}
	
	
	public String topRatedProduct()
	{
		topRatedProduct = prodh1.getText().split(" ")[3];
		return topRatedProduct;
	}
	public void addToBagClick() throws Exception
	{
		deleteCookies();
		//https://www.nykaa.com/mcaffeine-complete-summer-coffee-pack/p/1374820?productId=1374820&pps=1
		addToBag.click();
		implicitWait();
		moveToHomeAction();
		
	}
	
	public boolean verifyProdAdded()
	{		
		explicitWait(addedToBagPrompt);
		String elem=this.addedToBagPrompt.getText();
		
		if(elem.matches(".*Added.*"))
				return true;
		else if( elem.matches(".*wrong.*")) 
				return false;
		return false;
	}
	
	public boolean isDisplayedFI() {
		Functionalinterface fi= () ->  this.w.until((d)-> prodh1.isDisplayed());
		return fi.isDisplayed();
	}
	
	

}
