package Hair;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import _common.AbstractComponent;
import _common.Functionalinterface;

public class aFiltersPC extends AbstractComponent {

	@FindBy(css = ".filters .sort-name")
	public WebElement sortByDropDown;

	@FindBy(xpath = "//li[contains(@class,'last-list')]")
	public WebElement hairCareTitle;

	@FindBy(css = "[for*='customer'] [class*=indicator]")
	public WebElement customerTopRated;

	public aFiltersPC(WebDriver driver) {
		super(driver);
	}

	public void sortByDropDowns() throws Exception {
		implicitWait();
		explicitWait(sortByDropDown);
		moveToElementAction(sortByDropDown);

		sleepMethod();
		moveToElement_ClickAction(sortByDropDown);
		// act.moveToElement(sortByDropDown).click().build().perform();
	}

	public void selectFilters() throws Exception {
		//alertDismiss();
		scrollWindow5();
		explicitWait(customerTopRated);
		customerTopRated.click();

		sleepMethod();
		scrollWindow8();
	}

	public boolean verifyFilterApplied() {
		return sortByDropDown.getText().toLowerCase().contains("customer top rated");
	}

	
	public boolean isDisplayedFI() {
		Functionalinterface fi = () -> this.w.until( (d) -> hairCareTitle.isDisplayed() );
		return fi.isDisplayed();
	}

}
