package Hair;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class _HairPOManager {

	private WebDriver driver;
	private aFiltersPC f;
	private bProductListingPC pl;
	private cSingleProductPC sp;
	private dCartProductsPC cp;

	public _HairPOManager(final WebDriver driver) {
		this.driver = driver;
		this.f = PageFactory.initElements(driver, aFiltersPC.class);
		this.pl = PageFactory.initElements(driver, bProductListingPC.class);
		this.sp = PageFactory.initElements(driver, cSingleProductPC.class);
		this.cp = PageFactory.initElements(driver, dCartProductsPC.class);
	}


	public aFiltersPC getFiltersPC() {
		return f;
	}

	public bProductListingPC getProductListingPC() {
		return pl;
	}

	public cSingleProductPC getSingleProductPC() {
		return sp;
	}

	public dCartProductsPC getCartProductsPC() {
		return cp;
	}

}
