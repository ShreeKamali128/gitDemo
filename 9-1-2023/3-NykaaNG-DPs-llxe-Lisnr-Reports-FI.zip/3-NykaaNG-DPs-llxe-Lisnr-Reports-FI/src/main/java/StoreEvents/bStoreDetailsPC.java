package StoreEvents;

import java.util.List;
import java.util.Map;
import java.util.TreeMap;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.FindBy;
import _common.AbstractComponent;
import _common.Functionalinterface;

public class bStoreDetailsPC extends AbstractComponent {

	public bStoreDetailsPC(WebDriver driver) {
		super(driver);
	}

	@FindBy(css = "[onclick*=\"window._nykaa.redirectToStoreDetailPage('N16')\"] [class*='time']")
	public WebElement storetiming;

	@FindBy(css = "[onclick*=\"window._nykaa.redirectToStoreDetailPage('N16')\"] [class*='address']")
	public WebElement storeAddress;
	
	@FindBy(css = "[onclick*='StoreDetailPage'] [class*='time']")
	public List<WebElement> storetimingList;

	@FindBy(css = "[onclick*='StoreDetailPage'] [class*='address']")
	public List<WebElement> storeAddressList;

	public boolean verifyPlace(String place) {
		return this.storeAddressList.get(0).toString().toLowerCase().contains(place);
	}

	public void printExcel() throws Throwable {
//		List<String[]> list = new ArrayList<String[]>();
//		list.add(new String[] { storeAddress.getText() });
//		list.add(new String[] { storetiming.getText() });
//		csvdata(list);
//		------------------------------------------------------------
//		String sa=storeAddress.getText();
//		String st=this.storetiming.getText();
//		String[] str= {sa,st};
//		String[] strArr= new String[str.length];
//		for(int i=0;i<str.length;i++)
//		{
//			strArr[i]=str[i];
//			System.out.println("String array elem" + i + " is " + strArr[i]);
//		}
//		List<String[]> list = new ArrayList<String[]>();
//		list.add(strArr);
		
//		for(int i=0;i<list.size();i++)
//			{
//			System.out.println("List elem "+ i + " is "+ list.get(i));
//			}
//		this.writeDataList(list);
//		List<String> a = this.readDataW();
//		for (int i = 0; i < a.size(); i++)
//			System.out.println(a.get(i));
//		------------------------------------------------------------
//		List<String> list = new ArrayList<String>();
//		for(WebElement w: this.storetimingList) {
//			list.add(w.getText());
//		}
		
//		for(int i=0;i<5;i++)
//			{
//			System.out.println("Time List elem "+ i + " is "+ list.get(i));
//			}
//		this.writeDataList(list);
//		List<String> a = this.readDataW();
//		System.out.println("read list is: ");
//		for (int i = 0; i < 5; i++)
//			System.out.println( a.get(i));
//		------------------------------------------------------------
		
		
		Map<String, Object[]> storeData = new TreeMap<String, Object[]>();
		for(int i=0;i<storeAddressList.size();i++)
			storeData.put(String.valueOf(i), new Object[] {this.storeAddressList.get(i).getText(),this.storetimingList.get(i).getText()});
			
		
		this.writeDataW(storeData);
		this.readDataW();
//		List<String> a = this.readDataW();
//		for (int j = 0; j < a.size(); j++)
//			System.out.println( a.get(j));
//		System.out.println("=================================");
		

	}
	

	public boolean isDisplayedFI() {
		Functionalinterface fi = () -> this.w.until((d) -> this.storetimingList.get(0).isDisplayed());
		return fi.isDisplayed();
	}

}