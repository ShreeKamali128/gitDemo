package StoreEvents;

import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.FindBy;
import _common.AbstractComponent;
import _common.Functionalinterface;

public class aFilterPC extends AbstractComponent {

	public aFilterPC(WebDriver driver) {
		super(driver);
	}

	@FindBy(xpath = "(//ol/li)[2]")
	public WebElement storesHeading;

	@FindBy(xpath = "(//input[@id='nw-store-search'])[1]")
	public WebElement searchCity;

	@FindBy(xpath="//*[contains(@class,'search-dropdown')]/a")
	public List<WebElement> searchCityDropdown;

	@FindBy(css = ".nw-store-list")
	public WebElement storeList;

	public boolean verifyStoreTitle(String s) {
		return storesHeading.getText().contains(s);
	}

	public void searchCity(String str) throws Exception {

		
		explicitWait(storeList);
		moveToElement_ClickAction(searchCity);
		explicitWait(storeList);
		explicitWait(searchCity);
		searchCity.sendKeys(str);
		
		//searchCityDropdown.stream().filter(d-> d.getText().equals(str)).forEach(s->s.click());

		for(WebElement opt: searchCityDropdown)
		{
			if(opt.getText().equals(str))
			{
				explicitWait(opt);
				opt.click();
				break;
			}
		}
	}
	

	public void clearSearch() throws InterruptedException{
		act.click(this.searchCity).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build().perform();
			} 

	public boolean isDisplayedFI() {
		Functionalinterface fi = () -> this.w.until((d) -> storesHeading.isDisplayed());
		return fi.isDisplayed();
	}

}