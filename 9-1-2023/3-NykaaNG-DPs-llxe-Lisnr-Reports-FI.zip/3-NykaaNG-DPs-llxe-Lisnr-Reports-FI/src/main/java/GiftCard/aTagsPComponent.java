package GiftCard;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import _common.AbstractComponent;
import _common.Functionalinterface;

public class aTagsPComponent extends AbstractComponent {

	@FindBy(xpath = "//div[@class='giftcard-container']//div[contains(@class,'tabs-container')]/ul")
	public WebElement giftCardsHeader;

	@FindBy(css = "#nykaaforCorporates span")
	public WebElement nykaforCorporates;

	@FindBy(xpath = "//h2[text()='Nykaa for Corporates']")
	public WebElement textNykaaForCorporates;

	@FindBy(css = "#tnc")
	public WebElement TandC;

	@FindBy(xpath = "//li[text()='Terms And Conditions']")
	public WebElement textTermsAndConditions;

	@FindBy(css = ".GC_MainContainer")
	public WebElement textParaTC;

	public aTagsPComponent(final WebDriver driver) {
		super(driver);
	}

	public void nykaaForCorporatesClick() {
		nykaforCorporates.click();
		implicitWait();
	}

	public void TandCClick() {
		TandC.click();
		implicitWait();
	}

	public boolean verifyNykaaForCorporates() {
		return this.textNykaaForCorporates.getText().toLowerCase().contains("nykaa for corporates");
	}

	public boolean verifyTandC() {
		System.out.println(this.textTermsAndConditions.getText().toLowerCase().contains("terms And Conditions"));
		explicitWait(textParaTC);
		return this.textParaTC.isDisplayed();
	}

	public boolean isDisplayedFI() {
		Functionalinterface fi = () -> this.w.until(d -> this.giftCardsHeader.isDisplayed());
		return fi.isDisplayed();
	}

}
