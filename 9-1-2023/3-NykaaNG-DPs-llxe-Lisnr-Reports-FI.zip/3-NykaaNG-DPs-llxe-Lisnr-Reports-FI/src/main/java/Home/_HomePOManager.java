package Home;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;



public class _HomePOManager {
	
	private WebDriver driver;
	
	private bHeaderBar hbar;
	private cSubHeaderBar shbar;
	private aOfferTopBar otbar;
	
	public _HomePOManager(final WebDriver driver)
	{
//		this.driver=driver;
		this.hbar = PageFactory.initElements(driver, bHeaderBar.class);
		this.shbar= PageFactory.initElements(driver, cSubHeaderBar.class);
		this.otbar = PageFactory.initElements(driver, aOfferTopBar.class);
	}
	
	public aOfferTopBar getOfferTopBar()
	{return otbar;}
	
	public bHeaderBar getHeaderBar()
	{return hbar;}
	
	public cSubHeaderBar getSubHeaderBar()
	{return shbar;}

}
