package Home;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import _common.AbstractComponent;
import _common.Functionalinterface;

public class cSubHeaderBar extends AbstractComponent {
	
	//public WebDriver driver;
	
	
	@FindBy(css="#category_navigation")
	public WebElement subHeaderMenu;
	
	@FindBy(xpath="(//div[@id='my-menu']//a[text()='hair'])[1]")
	public WebElement hairCategory;
	
	
	@FindBy(xpath="(//a[text()='hair care'])[1]")
	public WebElement hairCare;
	

	@FindBy(xpath="(//a[text()='skin'])[2]")
	public WebElement skinCategory;
	
	
	@FindBy(xpath="//a[text()='Cleansers']")
	WebElement cleansers;
	
	
	public cSubHeaderBar(WebDriver driver) {
		super(driver);
	}

	
	public void goToHairCategory()
	{
		moveToElementAction(hairCategory);
	}
	
	public void goToHairCare() throws Exception
	{
		explicitWait(hairCare);
		hairCare.click();
		switchWindow();
	}
	
	public void goToSkinCategory()
	{
		moveToHomeAction();
		explicitWait( skinCategory);
		moveToElementAction(skinCategory);
	}
	
	public void goToCleansers() throws Exception
	{
		cleansers.click();
		switchWindow();
	}
	
	
	public boolean isDisplayedFI() {
		 Functionalinterface fi = () -> this.w.until(d-> this.subHeaderMenu.isDisplayed());
		 return fi.isDisplayed();
	}

}
