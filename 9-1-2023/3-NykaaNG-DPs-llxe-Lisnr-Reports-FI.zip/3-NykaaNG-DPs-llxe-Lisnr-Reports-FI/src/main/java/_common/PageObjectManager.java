package _common;

import org.openqa.selenium.WebDriver;

//import Chatbot.Chatbot;
import GiftCard._GiftCardPOManager;
import Hair._HairPOManager;
import Home._HomePOManager;
//import Sanitizer.Sanitizer;
import Skin._SkinPOManager;
import StoreEvents._StoreEventsPOManager;


public class PageObjectManager {
	
	public _HomePOManager homePOM;
	public _GiftCardPOManager gcPOM;
	public _HairPOManager hrPOM; 
	public _SkinPOManager skPOM;
	public _StoreEventsPOManager se;
	
	
//	public Sanitizer sr;
//	public Chatbot chatbot;
	
	public WebDriver driver;
	
	public PageObjectManager(WebDriver driver)
	{
		this.driver=driver;		
	}
	
	public _HomePOManager homePOM()
	{
		homePOM=new _HomePOManager(driver);
		return homePOM;
	}
	
	public  _GiftCardPOManager gcPOM()
	{
		gcPOM=new _GiftCardPOManager(driver);
		return gcPOM;
	}
	
	public _HairPOManager hairPOM()
	{
		hrPOM=new _HairPOManager(driver);
		return hrPOM;
	}
	
	public _SkinPOManager skinPOM()
	{
		skPOM=new _SkinPOManager(driver);
		return skPOM;
	}
	
	
	public _StoreEventsPOManager storeEventsPOM()
	{
		se = new _StoreEventsPOManager(driver);
		return se;
	}
	
//	public Sanitizer sanitizer()
//	{
//		sr= new Sanitizer(driver);
//		return sr;
//		
//	}
//
//	public Chatbot chatbot()
//	{
//		chatbot =  new Chatbot(driver);
//		return chatbot;
//	}
	
}
