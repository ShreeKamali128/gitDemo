package _common;

public interface Functionalinterface {

	public abstract boolean isDisplayed();
}
