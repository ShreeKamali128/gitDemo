package Tests;

import org.junit.Assert;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import GiftCard._GiftCardPOManager;
import GiftCard.aTagsPComponent;
import GiftCard.bMailPComponent;
import Home._HomePOManager;
import utils.BaseTest2;
import utils.testContextSetUp;

public class GiftCardsTest extends BaseTest2 {


	private _HomePOManager home;
	private _GiftCardPOManager gc;
	
	private SoftAssert ass;
	private testContextSetUp tcs;
	
	private aTagsPComponent tg;
	private bMailPComponent ml;

		
	@BeforeClass
	public void initAllPOM()
	{
		tcs= new testContextSetUp(driver);
		ass = tcs.ass;
		tcs.deltcookies();
		
		gc = tcs.pom.gcPOM();
		home = tcs.pom.homePOM();
		
		tg = gc.getgiftCardContainerPC();
		ml = gc.getMailPC();
	}
	

	@Test(priority=1)
	public void GoToGiftCards() throws Exception {
		ass.assertTrue(home.getOfferTopBar().isDisplayedFI());
		home.getOfferTopBar().goToGiftCards();
	}

	@Test(priority=2, dependsOnMethods= {"GoToGiftCards"})
	public void GoToTags() throws Exception
	{
		ass.assertTrue(tg.isDisplayedFI());
		tg.nykaaForCorporatesClick();
		Assert.assertTrue(tg.verifyNykaaForCorporates());
	}

	@Test(priority=3, dependsOnMethods= {"GoToTags"})
	public void GoToMail() throws Exception {
		ass.assertTrue(ml.isDisplayedFI());
		ml.goToFooterTitle();
		ml.inputMailClick();
		ml.sendMailClick();
		ass.assertTrue(ml.validateResponse());
	}
	
	@AfterClass
	public void goToHomeLogo()
	{
		home.getHeaderBar().goToLogoo();
		ass.assertTrue(home.getHeaderBar().verifyUrl());
	}

}
