package Tests;



import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import Home._HomePOManager;
import Skin._SkinPOManager;
import Skin.aFiltersPC;
import Skin.bProductListingPC;
import _common.PageObjectManager;
import utils.BaseTest;
import utils.BaseTest2;
import utils.testContextSetUp;

public class SkinTest extends BaseTest {

	private testContextSetUp tcs;
	private PageObjectManager pom;
	private _SkinPOManager skin;
	private _HomePOManager home;
	
	private aFiltersPC f;
	private bProductListingPC pl;
	
	private SoftAssert ass;
	

	
	@BeforeClass
	public void setUpPages() {
		tcs= new testContextSetUp(driver);
		
		ass = tcs.ass;
		tcs.deltcookies();
		
		skin = tcs.pom.skinPOM();
		home = tcs.pom.homePOM();
		
		f = skin.getFiltersPC();
		pl = skin.getProductListingPC();
	}
	
//	public void isDisplayed()
//	{
//		
//	}
	@Test(priority=1)
	public void GoToSkinCategory() throws Exception
	{
		ass.assertTrue(home.getSubHeaderBar().isDisplayedFI()); //
		home.getSubHeaderBar().goToSkinCategory();
		home.getSubHeaderBar().goToCleansers();
	}

	@Test(priority=2, dependsOnMethods= {"GoToSkinCategory"})
	public void ApplyFilters() throws Exception

	{
		ass.assertTrue(f.isDisplayedFI());//
		f.customerRatingClick();
		f.discountClick();
		ass.assertTrue(f.verifyFilterApplied());
	}
	
	@Parameters({"Label"})
	@Test(priority=3, dependsOnMethods= {"ApplyFilters"})
	public void AddToWishlist(String label) throws Exception

	{	
		ass.assertTrue(pl.isDisplayedFI());//
		pl.heartIconClicked();
		ass.assertTrue(pl.verify(label));
		pl.closeSignIn();
		
	}
	
	
	
	@AfterClass
	public void goToHomeLogo()
	{
		home.getHeaderBar().goToLogo();
		ass.assertTrue(home.getHeaderBar().verifyUrl());
	}
	
	
}
