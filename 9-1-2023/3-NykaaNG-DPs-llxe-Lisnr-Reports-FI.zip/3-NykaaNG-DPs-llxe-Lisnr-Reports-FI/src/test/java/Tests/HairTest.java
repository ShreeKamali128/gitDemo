package Tests;


import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import Hair._HairPOManager;
import Hair.aFiltersPC;
import Hair.bProductListingPC;
import Hair.cSingleProductPC;
import Hair.dCartProductsPC;
import Home._HomePOManager;
import _common.PageObjectManager;
import utils.BaseTest;
import utils.BaseTest2;
import utils.Retry;
import utils.testContextSetUp;

public class HairTest extends BaseTest2 {

	private PageObjectManager pom;
	private _HomePOManager home;
	private _HairPOManager hr;
	
	private aFiltersPC f;
	private bProductListingPC pl;
	private cSingleProductPC sp;
	private dCartProductsPC cp;
	 
	private testContextSetUp tcs;
	private SoftAssert ass;
	private String s1;
	
	
	@BeforeClass
	public void initAllPOM() {
		tcs= new testContextSetUp(driver);
		ass = tcs.ass;
		tcs.deltcookies();
		
		home = tcs.pom.homePOM();
		hr = tcs.pom.hairPOM();
	
		f=hr.getFiltersPC();
		pl=hr.getProductListingPC();
		sp=hr.getSingleProductPC();
		cp=hr.getCartProductsPC();
	}
	
	@Test(priority=4)
	public void GoToHairCare() throws Exception
	{
	ass.assertTrue(home.getSubHeaderBar().isDisplayedFI());
	home.getSubHeaderBar().goToHairCategory();
	home.getSubHeaderBar().goToHairCare();
	}
	
	@Test(priority=5, dependsOnMethods= {"GoToHairCare"})
	public void GetFiltersApplied() throws Exception

	{		
		ass.assertTrue(f.isDisplayedFI());
		f.sortByDropDowns();
		f.selectFilters();
		ass.assertTrue(f.verifyFilterApplied());
	}
	
	@Test(priority=6, dependsOnMethods= {"GetFiltersApplied"}, retryAnalyzer=Retry.class)
	public void WorkOnSingleProd() throws Exception

	{		
		ass.assertTrue(pl.isDisplayedFI());
		pl.productClick();
		
		ass.assertTrue(sp.isDisplayedFI());
		s1 =sp.topRatedProduct();
		sp.addToBagClick();
		ass.assertFalse(sp.verifyProdAdded());
	}
	
	
	@Test(priority=7, dependsOnMethods= {"WorkOnSingleProd"})
	public void goToCart() throws Exception
	{
		home.getHeaderBar().viewBagClick();
		
		cp.switchFrame();		
		String s2=cp.cartProduct();
		ass.assertEquals(s1,s2);
		cp.chargeFees();
		cp.closeFrame();	
	}
	
	@AfterClass
	public void goToHomeLogo()
	{
		home.getHeaderBar().goToLogo();
		ass.assertTrue(home.getHeaderBar().verifyUrl());
	}
	
}
