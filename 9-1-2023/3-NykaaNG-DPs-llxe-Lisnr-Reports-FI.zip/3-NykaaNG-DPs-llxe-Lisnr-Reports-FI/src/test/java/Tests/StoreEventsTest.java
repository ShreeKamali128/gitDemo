package Tests;


import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import Home._HomePOManager;

import StoreEvents._StoreEventsPOManager;
import StoreEvents.aFilterPC;
import StoreEvents.bStoreDetailsPC;
import _common.PageObjectManager;
import utils.BaseTest;
import utils.BaseTest2;
import utils.testContextSetUp;

public class StoreEventsTest extends BaseTest{

	private PageObjectManager pom;
	private _StoreEventsPOManager se;
	private _HomePOManager home;

	private aFilterPC f;
	private bStoreDetailsPC sd;
	
	private SoftAssert ass;
	private testContextSetUp tcs;


	@BeforeClass
	public void initAllPOM()
	{
		tcs= new testContextSetUp(driver);
		ass = tcs.ass;
		tcs.deltcookies();
		
		se =tcs.pom.storeEventsPOM();
		home =tcs.pom.homePOM();
		
		f=se.getFiltersPC();
		sd=se.getStoreDetailsPC();
	}
	
	/*
	 * @Parameters({ "browser" })
	 * 
	 * @BeforeTest public void initBrowser(String browser) throws Exception {
	 * initBrowserDriver(browser);
	 * 
	 * }
	 * 
	 * @AfterTest public void tearDown( ) throws Exception { this.stopDriver(); }
	 */
	
	@Test(priority=4)
	public void GoToStoreEvents() throws Exception {
		ass.assertTrue(home.getOfferTopBar().isDisplayedFI());
		home.getOfferTopBar().goToStoresEvents();
	}

	
	@Test (priority=5, dataProvider="GetData", dependsOnMethods= {"GoToStoreEvents"})
	public void SearchCity(String place) throws Throwable

	{
		ass.assertTrue(f.isDisplayedFI());
		f.searchCity(place);
		
		ass.assertTrue(sd.isDisplayedFI());
		ass.assertTrue(sd.verifyPlace(place));
		sd.printExcel();
		
		f.clearSearch();
	}
	
	@DataProvider
	public Object GetData()
	{
		Object[][] o=new Object[2][1];
		o[0][0]="Bangalore";
		o[1][0]="Chennai";
		
		return o;
	}
	
	@AfterClass
	public void goToHomeLogo()
	{
		home.getHeaderBar().goToLogoo();
		ass.assertTrue(home.getHeaderBar().verifyUrl());
	}
	

}
