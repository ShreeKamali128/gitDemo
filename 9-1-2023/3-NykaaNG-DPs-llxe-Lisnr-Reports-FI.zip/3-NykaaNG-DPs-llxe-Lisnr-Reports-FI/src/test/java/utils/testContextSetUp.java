package utils;


import org.openqa.selenium.WebDriver;
import org.testng.asserts.SoftAssert;

import _common.PageObjectManager;

public class testContextSetUp  {
	
	
	public PageObjectManager pom;
	public SoftAssert ass;
	private WebDriver driver;
	
	public testContextSetUp(WebDriver driver)
	{
	 pom=new PageObjectManager(driver);
	 ass = new SoftAssert();
	this.driver=driver;
	 //setDriver(driver);
	}
	
//	public void setDriver(WebDriver driver)
//	{
//		this.driver=driver;
//	}
	
	public void deltcookies()
	{
		this.driver.manage().deleteAllCookies();
	}
	

}
