package utils;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.ITestContext;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.google.common.util.concurrent.Uninterruptibles;
import _common.AbstractComponent;
import _common.Functionalinterface;

public class BaseTest extends AbstractComponent {

	protected static WebDriver driver = null; // important static member else driver not shared among all tests. only
												// first class in first test will run. from the second there will be an
												// error
	protected Properties prop;

	@Parameters({ "browser" })
	@BeforeTest
	public WebDriver initBrowserDriver(String browser) throws Exception {
		if (driver == null) 
		{
			if (browser.equalsIgnoreCase("edge")) {				//here browser==edge do not work.
				System.setProperty("webdriver.edge.driver",System.getProperty("user.dir") + "\\src\\test\\java\\Drivers\\msedgedriverN");
				driver = new EdgeDriver();
				
			}
			else if(browser.equalsIgnoreCase("chrome")){
				System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir") + "\\src\\test\\java\\Drivers\\chromedriver");
				driver = new ChromeDriver();
			}

			this.windowMaximize(driver);
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));

			prop = propInit(prop);
			String url = System.getProperty("url")!=null ? System.getProperty("url") :  prop.getProperty("url");		//useful for maven
			//String url = prop.getProperty("url");
			driver.get(url);
		}
		
		return driver;
	}
	
	@AfterTest
	public void stopDriver() {
		Uninterruptibles.sleepUninterruptibly(Duration.ofSeconds(3));
		driver.quit();
	}
	
	@BeforeClass
	public void setDriverContext(ITestContext context)
	{
		context.setAttribute("WebDriver", this.driver); 
	}
	
	public String getScreenShot(WebDriver driver, String tcName) throws IOException
	{
		TakesScreenshot ts=(TakesScreenshot)driver;
		File source=ts.getScreenshotAs(OutputType.FILE);
		File f = new File(System.getProperty("user.dir")+"//report//" + tcName+".png");
		FileUtils.copyFile(source, f);
		return System.getProperty("user.dir")+"//report//" + tcName+".png";
		
	}

	public boolean isDisplayedFI() {
		Functionalinterface fi =() -> false;
		return fi.isDisplayed();
	}

}
