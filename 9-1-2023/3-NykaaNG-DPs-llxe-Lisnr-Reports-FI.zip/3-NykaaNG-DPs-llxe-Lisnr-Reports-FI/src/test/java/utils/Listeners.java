package utils;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import Resources.ExtentReportsNG;

public class Listeners extends BaseTest implements ITestListener {

	ExtentTest test;
	ExtentReports extent = ExtentReportsNG.getReportObject();		//this is where actual extent report creation done and imported from
	ThreadLocal<ExtentTest> extentTest= new ThreadLocal<ExtentTest>();
	
	public WebDriver driver=null;

	@Override
	public void onTestStart(ITestResult result) {
		test = extent.createTest(result.getMethod().getMethodName());
		extentTest.set(test);			//push test into the threadlocal along with its thread id and forms a mapping 1--> test, 2-> test...
		extentTest.get().log(Status.INFO, "Test Started");
		System.out.println("TestCase " + result.getMethod().getMethodName() + " started");

	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {

	}

	@Override
	public void onTestSkipped(ITestResult result) {

	}

	@Override
	public void onTestSuccess(ITestResult result) {
		System.out.println("TestCase " + result.getMethod().getMethodName() + " completed");
		this.extentTest.get().log(Status.PASS, "Test Passed");
	}

	@Override
	public void onTestFailure(ITestResult result) {
		System.out.println("TestCase " + result.getName() + " failed");
		this.extentTest.get().log(Status.FAIL, "Test failed");
		this.extentTest.get().fail(result.getThrowable());			//this prints the complete error detail in the dashboard
		String filePath = null;

		try {
			//this.driver = (WebDriver) result.getTestClass().getRealClass().getField("driver").get(result.getInstance());
			this.driver= (WebDriver)result.getTestContext().getAttribute("WebDriver");
			//if(this.driver!=null) System.out.println("the driver is set");
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Driver is null");
		}

		try {
			filePath = this.getScreenShot(this.driver, result.getMethod().getMethodName());
		} catch (IOException e) {

			e.printStackTrace();
			System.out.println("Could not take the screenshot of TC failed");
		}
		this.extentTest.get().addScreenCaptureFromPath(filePath);
	}

	public void onFinish(ITestContext context) {
		extent.flush();
	}

}
