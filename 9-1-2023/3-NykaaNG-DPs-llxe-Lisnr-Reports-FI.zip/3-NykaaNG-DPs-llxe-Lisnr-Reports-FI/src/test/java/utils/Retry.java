package utils;

import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

public class Retry implements IRetryAnalyzer{

	int count=0;
	int maxTry=1;
	@Override
	public boolean retry(ITestResult result) {
		if(count<maxTry)
		{
			count++;
			return true;		//this method should return true if the test need to run again//the test run for maxTry count given here
		}
		return false;
	}

}


//to reach this class file , the tests must insert attribute in its parameter near annotation
//(retryAnalyzer=Retry.class)  //interface_name=class_name